import { IslamicEvent } from '../types';

export const islamicEvents: IslamicEvent[] = [
    { name: "Awal Muharram (Maal Hijrah)", date: "2024-07-07" },
    { name: "Maulidur Rasul", date: "2024-09-16" },
    { name: "Israk dan Mikraj", date: "2025-01-27" },
    { name: "Nisfu Sya'ban", date: "2025-02-15" },
    { name: "Awal Ramadan", date: "2025-03-01" },
    { name: "Nuzul Al-Quran", date: "2025-03-17" },
    { name: "Hari Raya Aidilfitri", date: "2025-03-31" },
    { name: "Hari Raya Aidiladha", date: "2025-06-07" },
    { name: "Awal Muharram (Maal Hijrah)", date: "2025-06-26" },
    { name: "Maulidur Rasul", date: "2025-09-05" },
    { name: "Israk dan Mikraj", date: "2026-01-16" },
    { name: "Awal Ramadan", date: "2026-02-19" },
];
