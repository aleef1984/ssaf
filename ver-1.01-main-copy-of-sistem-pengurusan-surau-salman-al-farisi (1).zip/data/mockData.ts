import { Member, Transaction, Duty, Announcement, SurauInfo, FinanceCategories, DutyPersonnel, Album, CommitteeMember, ElectionSession, Nomination, Asset, Facility, Booking, KhairatTask, QurbanSession, QurbanParticipant, NotificationTemplate, Speaker, ClassSession, AdminCredentials } from '../types';

export const mockMembers: Member[] = [
  {
    id: 1,
    name: 'Ahmad bin Abdullah',
    icNumber: '800101-06-1234',
    address: 'No. 1, Jalan Makmur 1, 25150 Kuantan',
    phone: '012-3456789',
    joinDate: '2023-01-15',
    dependents: [
      { id: 1, name: 'Siti binti Ahmad', relationship: 'Anak', status: 'Hidup' },
      { id: 2, name: 'Ali bin Ahmad', relationship: 'Anak', status: 'Hidup' },
    ],
    khairatPayments: [
      { id: 1, year: 2023, amount: 50, paymentDate: '2023-02-01', status: 'Lunas' },
      { id: 2, year: 2024, amount: 50, paymentDate: '2024-02-10', status: 'Lunas' },
    ],
    status: 'Aktif',
  },
  {
    id: 2,
    name: 'Ismail bin Kassim',
    icNumber: '750520-03-5678',
    address: 'No. 5, Jalan Makmur 2, 25150 Kuantan',
    phone: '019-8765432',
    joinDate: '2023-03-20',
    dependents: [],
    khairatPayments: [
      { id: 1, year: 2023, amount: 50, paymentDate: '2023-03-22', status: 'Lunas' },
      { id: 2, year: 2024, amount: 50, paymentDate: '2024-01-15', status: 'Lunas' },
    ],
    status: 'Aktif',
  },
  {
    id: 3,
    name: 'Zainab binti Husin',
    icNumber: '821111-06-1122',
    address: 'No. 10, Jalan Makmur 1, 25150 Kuantan',
    phone: '017-1234567',
    joinDate: '2023-05-10',
    dependents: [
        {id: 1, name: "Farah binti Omar", relationship: "Anak", status: 'Hidup' }
    ],
    khairatPayments: [
      { id: 1, year: 2023, amount: 50, paymentDate: '2023-05-11', status: 'Lunas' },
      { id: 2, year: 2024, amount: 50, paymentDate: '2024-08-01', status: 'Tertunggak' },
    ],
    status: 'Aktif',
  },
  {
    id: 4,
    name: 'Muhammad Ali (Pemohon)',
    icNumber: '900101-01-9999',
    address: 'No. 20, Jalan Harapan, 25150 Kuantan',
    phone: '011-1112222',
    joinDate: new Date().toISOString().split('T')[0],
    dependents: [],
    khairatPayments: [],
    status: 'Menunggu Pengesahan',
  },
  {
    id: 5,
    name: 'Arwah Jamaluddin bin Kiram',
    icNumber: '650101-01-5555',
    address: 'No. 15, Jalan Kenangan, 25150 Kuantan',
    phone: '018-1234567',
    joinDate: '2023-01-20',
    dependents: [],
    khairatPayments: [ { id: 1, year: 2023, amount: 50, paymentDate: '2023-02-01', status: 'Lunas' } ],
    status: 'Meninggal Dunia',
  },
   { id: 101, name: 'Haji Sulaiman bin Ahmad', icNumber: '600101-01-1010', address: 'Alamat AJK 1', phone: '011-1010101', joinDate: '2022-01-01', dependents: [], khairatPayments: [], status: 'Aktif' },
   { id: 102, name: 'Dr. Fauziah binti Idris', icNumber: '650202-02-2020', address: 'Alamat AJK 2', phone: '011-2020202', joinDate: '2022-01-01', dependents: [], khairatPayments: [], status: 'Aktif' },
   { id: 103, name: 'En. Khairul Anuar bin Ishak', icNumber: '700303-03-3030', address: 'Alamat AJK 3', phone: '011-3030303', joinDate: '2022-01-01', dependents: [], khairatPayments: [], status: 'Aktif' },
   { id: 104, name: 'Pn. Aishah binti Omar', icNumber: '750404-04-4040', address: 'Alamat AJK 4', phone: '011-4040404', joinDate: '2022-01-01', dependents: [], khairatPayments: [], status: 'Aktif' },
   { id: 105, name: 'En. Farid bin Hamzah', icNumber: '800505-05-5050', address: 'Alamat AJK 5', phone: '011-5050505', joinDate: '2022-01-01', dependents: [], khairatPayments: [], status: 'Aktif' },
];

export const mockTransactions: Transaction[] = [
    { id: 'TXN001', date: '2024-07-28', description: 'Derma Jumaat', type: 'Derma', amount: 350.50, category: 'Derma Jumaat', payerName: 'Penderma Awam' },
    { id: 'TXN002', date: '2024-07-27', description: 'Bayaran bil elektrik', type: 'Perbelanjaan', amount: -120.00, category: 'Bil Utiliti' },
    { id: 'TXN003', date: '2024-07-26', description: 'Derma QR Pay', type: 'Derma', amount: 150.00, category: 'Sumbangan Online', memberId: 1, payerName: 'Ahmad bin Abdullah' },
    { id: 'TXN004', date: '2024-07-25', description: 'Pembelian karpet baru', type: 'Perbelanjaan', amount: -800.00, category: 'Penyelenggaraan' },
    { id: 'TXN005', date: '2024-07-21', description: 'Derma Jumaat', type: 'Derma', amount: 420.00, category: 'Derma Jumaat', payerName: 'Penderma Awam' },
    { id: 'TXN006', date: '2024-06-30', description: 'Sumbangan Hari Raya Aidiladha', type: 'Derma', amount: 1200.00, category: 'Sumbangan Khas', memberId: 2, payerName: 'Ismail bin Kassim' },
    { id: 'TXN007', date: '2024-06-28', description: 'Bayaran bil air', type: 'Perbelanjaan', amount: -85.00, category: 'Bil Utiliti' },
    { id: 'TXN008', date: '2024-06-15', description: 'Belian barang jamuan', type: 'Perbelanjaan', amount: -250.00, category: 'Program & Aktiviti' },
    { id: 'TXN009', date: '2024-01-15', description: 'Sumbangan Awal Tahun', type: 'Derma', amount: 100.00, category: 'Sumbangan Khas', memberId: 1, payerName: 'Ahmad bin Abdullah' },
];

export const mockKhairatTasks: KhairatTask[] = [
    { id: 1, memberId: 5, memberName: 'Arwah Jamaluddin bin Kiram', deathDate: '2024-07-15', status: 'Selesai', processedDate: '2024-07-17', type: 'Ahli', amount: 100 }
];

export const mockSchedule: Duty[] = [
    { day: 'Isnin', subuh: { imam: 'Ustaz Kamal', bilal: 'En. Farid' }, zohor: { imam: 'En. Rahman', bilal: 'En. Sani' }, asar: { imam: 'En. Rahman', bilal: 'En. Sani' }, maghrib: { imam: 'Ustaz Kamal', bilal: 'En. Hadi' }, isyak: { imam: 'Ustaz Kamal', bilal: 'En. Hadi' }},
    { day: 'Selasa', subuh: { imam: 'Ustaz Firdaus', bilal: 'En. Hadi' }, zohor: { imam: 'En. Jamil', bilal: 'En. Ali' }, asar: { imam: 'En. Jamil', bilal: 'En. Ali' }, maghrib: { imam: 'Ustaz Firdaus', bilal: 'En. Farid' }, isyak: { imam: 'Ustaz Firdaus', bilal: 'En. Farid' }},
    { day: 'Rabu', subuh: { imam: 'Ustaz Kamal', bilal: 'En. Sani' }, zohor: { imam: 'En. Rahman', bilal: 'En. Farid' }, asar: { imam: 'En. Rahman', bilal: 'En. Farid' }, maghrib: { imam: 'Ustaz Kamal', bilal: 'En. Hadi' }, isyak: { imam: 'Ustaz Kamal', bilal: 'En. Hadi' }},
    { day: 'Khamis', subuh: { imam: 'Ustaz Firdaus', bilal: 'En. Farid' }, zohor: { imam: 'En. Jamil', bilal: 'En. Sani' }, asar: { imam: 'En. Jamil', bilal: 'En. Sani' }, maghrib: { imam: 'Ustaz Firdaus', bilal: 'En. Ali' }, isyak: { imam: 'Ustaz Firdaus', bilal: 'En. Ali' }},
    { day: 'Jumaat', subuh: { imam: 'Ustaz Kamal', bilal: 'En. Ali' }, zohor: { imam: 'Imam Jemputan', bilal: 'En. Hadi' }, asar: { imam: 'En. Rahman', bilal: 'En. Hadi' }, maghrib: { imam: 'Ustaz Kamal', bilal: 'En. Farid' }, isyak: { imam: 'Ustaz Kamal', bilal: 'En. Farid' }},
    { day: 'Sabtu', subuh: { imam: 'Ustaz Firdaus', bilal: 'En. Hadi' }, zohor: { imam: 'En. Rahman', bilal: 'En. Ali' }, asar: { imam: 'En. Rahman', bilal: 'En. Ali' }, maghrib: { imam: 'Ustaz Firdaus', bilal: 'En. Sani' }, isyak: { imam: 'Ustaz Firdaus', bilal: 'En. Sani' }},
    { day: 'Ahad', subuh: { imam: 'Ustaz Kamal', bilal: 'En. Sani' }, zohor: { imam: 'En. Jamil', bilal: 'En. Farid' }, asar: { imam: 'En. Jamil', bilal: 'En. Farid' }, maghrib: { imam: 'Ustaz Kamal', bilal: 'En. Ali' }, isyak: { imam: 'Ustaz Kamal', bilal: 'En. Ali' }},
];


export const mockAnnouncements: Announcement[] = [
    { id: 1, title: 'Kuliah Maghrib Perdana', content: 'Semua dijemput hadir ke Kuliah Maghrib Perdana oleh Al-Fadhil Ustaz Don Daniyal pada hari Sabtu ini selepas solat Maghrib. Jamuan ringan disediakan.', date: '2024-08-03', imageUrl: 'https://picsum.photos/400/200?random=1' },
    { id: 2, title: 'Gotong-Royong Membersihkan Surau', content: 'Aktiviti gotong-royong akan diadakan pada hari Ahad, 9 pagi. Sarapan disediakan untuk semua peserta. Bawa peralatan sendiri jika ada.', date: '2024-08-04', imageUrl: 'https://picsum.photos/400/200?random=2' },
    { id: 3, title: 'Kutipan Khas Bantuan Palestin', content: 'Tabung khas untuk saudara kita di Palestin akan diedarkan selepas solat Jumaat. Sumbangan anda amat dihargai.', date: '2024-08-02' },
];

export const mockAlbums: Album[] = [
    {
        id: 1,
        title: "Gotong-Royong Perdana 2024",
        date: "2024-07-20",
        coverImageUrl: "https://picsum.photos/400/300?random=10",
        photos: [
            { id: "p1", url: "https://picsum.photos/800/600?random=11", caption: "Peserta sedang membersihkan kawasan luar surau." },
            { id: "p2", url: "https://picsum.photos/800/600?random=12", caption: "Jamuan makan selepas gotong-royong." },
            { id: "p3", url: "https://picsum.photos/800/600?random=13", caption: "Sesi bergambar bersama AJK dan peserta." },
            { id: "p4", url: "https://picsum.photos/800/600?random=14" },
        ]
    },
    {
        id: 2,
        title: "Majlis Iftar Jamaie",
        date: "2024-04-05",
        coverImageUrl: "https://picsum.photos/400/300?random=20",
        photos: [
            { id: "p5", url: "https://picsum.photos/800/600?random=21", caption: "Suasana sementara menunggu waktu berbuka." },
            { id: "p6", url: "https://picsum.photos/800/600?random=22" },
            { id: "p7", url: "https://picsum.photos/800/600?random=23", caption: "Jemaah sedang menikmati juadah berbuka." },
        ]
    }
];

export const mockCommitteeMembers: CommitteeMember[] = [
    { id: 1, name: 'Haji Sulaiman bin Ahmad', position: 'Pengerusi', session: '2024-2026', phone: '012-1112222', email: 'pengerusi@surau.my', imageUrl: 'https://picsum.photos/100/100?random=c1' },
    { id: 2, name: 'Dr. Fauziah binti Idris', position: 'Setiausaha', session: '2024-2026', phone: '013-3334444', email: 'setiausaha@surau.my', imageUrl: 'https://picsum.photos/100/100?random=c2' },
    { id: 3, name: 'En. Khairul Anuar bin Ishak', position: 'Bendahari', session: '2024-2026', phone: '019-5556666', email: 'bendahari@surau.my', imageUrl: 'https://picsum.photos/100/100?random=c3' },
    { id: 4, name: 'Pn. Aishah binti Omar', position: 'AJK Muslimat', session: '2024-2026', phone: '017-7778888', email: 'ajk1@surau.my', imageUrl: 'https://picsum.photos/100/100?random=c4' },
    { id: 5, name: 'En. Farid bin Hamzah', position: 'AJK Belia', session: '2024-2026', phone: '016-9990000', email: 'ajk2@surau.my', imageUrl: 'https://picsum.photos/100/100?random=c5' }
];

const getTodayAtMidnight = (daysToAdd = 0) => {
    const date = new Date();
    date.setDate(date.getDate() + daysToAdd);
    date.setHours(0, 0, 0, 0);
    return date.toISOString().split('T')[0];
};

export const mockElectionSessions: ElectionSession[] = [
    {
        id: 1,
        title: 'Sesi Pemilihan AJK 2025-2027',
        nominationStartDate: getTodayAtMidnight(-10),
        nominationEndDate: getTodayAtMidnight(-1),
        votingStartDate: getTodayAtMidnight(0),
        votingEndDate: getTodayAtMidnight(10),
        status: 'Pengundian', // This will be calculated dynamically
        contestedPositions: [
            { position: 'Pengerusi', vacancies: 1 },
            { position: 'Setiausaha', vacancies: 1 },
            { position: 'Bendahari', vacancies: 1 },
            { position: 'AJK Biasa', vacancies: 4 },
        ],
        candidates: [
            // Pengerusi
            { id: 1, name: 'Ahmad bin Abdullah', position: 'Pengerusi', imageUrl: 'https://i.pravatar.cc/100?u=1' },
            { id: 101, name: 'Haji Sulaiman bin Ahmad', position: 'Pengerusi', imageUrl: 'https://i.pravatar.cc/100?u=101' },
            // Setiausaha
            { id: 102, name: 'Dr. Fauziah binti Idris', position: 'Setiausaha', imageUrl: 'https://i.pravatar.cc/100?u=102' },
            // Bendahari
            { id: 103, name: 'En. Khairul Anuar bin Ishak', position: 'Bendahari', imageUrl: 'https://i.pravatar.cc/100?u=103' },
            // AJK Biasa
            { id: 2, name: 'Ismail bin Kassim', position: 'AJK Biasa', imageUrl: 'https://i.pravatar.cc/100?u=2' },
            { id: 3, name: 'Zainab binti Husin', position: 'AJK Biasa', imageUrl: 'https://i.pravatar.cc/100?u=3' },
            { id: 104, name: 'Pn. Aishah binti Omar', position: 'AJK Biasa', imageUrl: 'https://i.pravatar.cc/100?u=104' },
            { id: 105, name: 'En. Farid bin Hamzah', position: 'AJK Biasa', imageUrl: 'https://i.pravatar.cc/100?u=105' },
        ],
        votes: [
            { voterMemberId: 1, sessionId: 1, selections: [
                { position: 'Pengerusi', candidateIds: [1] },
                { position: 'Setiausaha', candidateIds: [102] },
                { position: 'Bendahari', candidateIds: [103] },
                { position: 'AJK Biasa', candidateIds: [2, 3, 104, 105] },
            ], voteDate: getTodayAtMidnight(1) },
             { voterMemberId: 2, sessionId: 1, selections: [
                { position: 'Pengerusi', candidateIds: [101] },
                { position: 'Setiausaha', candidateIds: [102] },
                { position: 'Bendahari', candidateIds: [103] },
                { position: 'AJK Biasa', candidateIds: [2, 104] },
            ], voteDate: getTodayAtMidnight(2) },
        ],
    },
    {
        id: 2,
        title: 'Sesi Pemilihan AJK 2023-2025 (Selesai)',
        nominationStartDate: '2023-01-01',
        nominationEndDate: '2023-01-10',
        votingStartDate: '2023-01-11',
        votingEndDate: '2023-01-20',
        status: 'Selesai',
        contestedPositions: [],
        candidates: [],
        votes: [],
    },
];

export const mockNominations: Nomination[] = [
    { id: 1, sessionId: 1, nominatedMemberId: 1, nominatorMemberId: 2, position: 'Pengerusi', status: 'Diterima', nominationDate: getTodayAtMidnight(-8) },
    { id: 2, sessionId: 1, nominatedMemberId: 102, nominatorMemberId: 1, position: 'Setiausaha', status: 'Diterima', nominationDate: getTodayAtMidnight(-7) },
    { id: 3, sessionId: 1, nominatedMemberId: 2, nominatorMemberId: 3, position: 'AJK Biasa', status: 'Diterima', nominationDate: getTodayAtMidnight(-6) },
    { id: 4, sessionId: 1, nominatedMemberId: 4, nominatorMemberId: 2, position: 'AJK Biasa', status: 'Menunggu', nominationDate: getTodayAtMidnight(-5) },
];

export const mockAssets: Asset[] = [
    { id: 1, name: 'Sistem PA & Pembesar Suara', category: 'Elektronik', location: 'Dewan Solat Utama', purchaseDate: '2023-01-20', purchaseValue: 4500, condition: 'Baik', imageUrl: 'https://picsum.photos/200/200?random=a1' },
    { id: 2, name: 'Unit Penghawa Dingin 2.5HP (York)', category: 'Elektronik', location: 'Dewan Solat Utama', purchaseDate: '2023-05-15', purchaseValue: 3200, condition: 'Perlu Penyelenggaraan', imageUrl: 'https://picsum.photos/200/200?random=a2' },
    { id: 3, name: 'Penyedut Hampagas (Karcher)', category: 'Peralatan Kebersihan', location: 'Stor', purchaseDate: '2022-11-10', purchaseValue: 800, condition: 'Baik', imageUrl: 'https://picsum.photos/200/200?random=a3' }
];

export const mockFacilities: Facility[] = [
    { id: 1, name: 'Dewan Serbaguna', description: 'Dewan berhawa dingin yang luas, sesuai untuk majlis kenduri, ceramah, dan aktiviti kemasyarakatan. Kapasiti sehingga 150 orang.', rentalRate: 200, imageUrl: 'https://picsum.photos/400/300?random=f1' },
    { id: 2, name: 'Bilik Mesyuarat', description: 'Bilik mesyuarat selesa dengan kemudahan asas seperti papan putih dan projektor. Sesuai untuk perbincangan AJK atau kelas mengaji.', rentalRate: 50, imageUrl: 'https://picsum.photos/400/300?random=f2' },
    { id: 3, name: 'Sistem PA Mudah Alih', description: 'Satu set lengkap sistem PA mudah alih (portable) untuk kegunaan di luar dewan atau untuk acara kecil-kecilan.', rentalRate: 80, imageUrl: 'https://picsum.photos/400/300?random=f3' },
];

export const mockBookings: Booking[] = [
    { id: 1, facilityId: 1, facilityName: 'Dewan Serbaguna', userName: 'Ismail bin Kassim', userContact: '019-8765432', eventDetails: 'Majlis Aqiqah anak', bookingDate: '2024-09-15', status: 'Diluluskan'},
    { id: 2, facilityId: 2, facilityName: 'Bilik Mesyuarat', userName: 'Zainab binti Husin', userContact: '017-1234567', eventDetails: 'Kelas tambahan mengaji', bookingDate: '2024-09-10', status: 'Menunggu Pengesahan'},
    { id: 3, facilityId: 1, facilityName: 'Dewan Serbaguna', userName: 'Syarikat ABC Sdn Bhd', userContact: '09-5551234', eventDetails: 'Taklimat produk', bookingDate: '2024-08-30', status: 'Ditolak'},
];

export const mockQurbanSessions: QurbanSession[] = [
    { id: 1, year: 2024, title: 'Program Korban & Aqiqah 1445H', pricePerPart: 850, totalParts: 21, status: 'Buka' }
];

export const mockQurbanParticipants: QurbanParticipant[] = [
    { id: 1, sessionId: 1, name: 'Ahmad bin Abdullah', phone: '012-3456789', email: 'ahmad@email.com', parts: 1, totalAmount: 850, paymentStatus: 'Lunas', registrationDate: '2024-05-10' },
    { id: 2, sessionId: 1, name: 'Ismail bin Kassim', phone: '019-8765432', email: 'ismail@email.com', parts: 2, totalAmount: 1700, paymentStatus: 'Lunas', registrationDate: '2024-05-12' },
];

export const mockNotificationTemplates: NotificationTemplate[] = [
    {
        id: 1,
        name: 'Selamat Datang Ahli Baru',
        type: 'Email',
        subject: 'Selamat Datang ke Surau Salman Al-Farisi',
        content: 'Assalamualaikum [Nama Ahli],\n\nSelamat datang dan terima kasih kerana mendaftar sebagai ahli kariah Surau Salman Al-Farisi. Kami mengalu-alukan kehadiran anda ke program-program kami.\n\nYang benar,\nAJK Surau Salman Al-Farisi'
    },
    {
        id: 2,
        name: 'Peringatan Yuran Khairat',
        type: 'WhatsApp',
        content: 'Peringatan mesra dari Surau Salman Al-Farisi. Yuran khairat kematian tahunan anda masih belum dijelaskan. Sila buat pembayaran di surau atau melalui pembayaran online. Terima kasih.'
    },
    {
        id: 3,
        name: 'Pengesahan Tempahan Fasiliti',
        type: 'Email',
        subject: 'Pengesahan Tempahan Fasiliti Surau',
        content: 'Assalamualaikum [Nama Pemohon],\n\nSukacita dimaklumkan, permohonan tempahan anda untuk [Nama Fasiliti] pada [Tarikh Tempahan] telah diluluskan.\n\nSila hubungi AJK untuk urusan selanjutnya. Terima kasih.'
    },
];

export const mockSpeakers: Speaker[] = [
    { id: 1, name: 'Al-Fadhil Ustaz Kamal bin Razali', phone: '011-1111111', expertise: 'Tafsir Al-Quran' },
    { id: 2, name: 'Al-Fadhil Ustaz Firdaus bin Yahya', phone: '012-2222222', expertise: 'Hadis & Fiqh' },
    { id: 3, name: 'Al-Fadhil Ustaz Don Daniyal Don Biyajid', phone: '013-3333333', expertise: 'Motivasi & Sejarah Islam' },
];

export const mockClassSessions: ClassSession[] = [
    { id: 1, title: 'Kuliah Tafsir Surah Al-Kahfi', description: 'Mendalami makna dan pengajaran dari surah Al-Kahfi, pelindung dari fitnah Dajjal.', speakerId: 1, isRecurring: true, day: 'Rabu', time: 'Selepas Maghrib', honorarium: 150, paymentStatus: 'Belum Dibayar' },
    { id: 2, title: 'Syarah Hadis 40 Imam Nawawi', description: 'Kajian mendalam hadis-hadis pilihan himpunan Imam Nawawi yang menjadi teras kehidupan seorang Muslim.', speakerId: 2, isRecurring: true, day: 'Isnin', time: 'Selepas Maghrib', honorarium: 150, paymentStatus: 'Belum Dibayar' },
    { id: 3, title: 'Ceramah Khas Maulidur Rasul', description: 'Mengenang dan meneladani keperibadian agung Rasulullah SAW sempena bulan kelahiran Baginda.', speakerId: 3, isRecurring: false, date: '2024-09-15', time: '20:00', honorarium: 500, paymentStatus: 'Sudah Dibayar' },
];

export const mockSurauInfo: SurauInfo = {
    name: "Surau Salman Al-Farisi",
    address: "Jalan Makmur 1, 25150 Kuantan, Pahang",
    logoUrl: undefined,
    khairatAmountMember: 100.00,
    khairatAmountDependent: 50.00,
    paymentGateway: {
        categoryCode: 'xyz123',
        secretKey: 'toyyibpay-secret-key-123',
    },
    infoScreenSettings: {
        backgroundVideoUrls: ['/video/background.mp4', '/video/background2.mp4'],
        azanSubuhVideoUrl: '/video/azan_subuh.mp4',
        azanVideoUrl: '/video/azan.mp4',
    }
};

export const mockFinanceCategories: FinanceCategories = {
    income: [
        'Derma Jumaat',
        'Sumbangan Online',
        'Sumbangan Khas',
        'Program & Aktiviti',
        'Korban & Aqiqah',
    ],
    expense: [
        'Bil Utiliti',
        'Penyelenggaraan',
        'Program & Aktiviti',
        'Sumbangan Luar',
        'Honorarium Penceramah',
        'Lain-lain',
    ],
};

export const mockDutyPersonnel: DutyPersonnel = {
    imams: ['Ustaz Kamal', 'Ustaz Firdaus', 'En. Rahman', 'En. Jamil', 'Imam Jemputan'],
    bilals: ['En. Farid', 'En. Sani', 'En. Hadi', 'En. Ali'],
};

export const mockAdminCredentials: AdminCredentials = {
    username: 'admin@surau.my',
    password_plaintext: 'password123',
};