import { Member, Announcement, Duty, Transaction, SurauInfo, FinanceCategories, DutyPersonnel, Album, CommitteeMember, ElectionSession, Nomination, Asset, Facility, Booking, KhairatTask, QurbanSession, QurbanParticipant, NotificationTemplate, Speaker, ClassSession, AdminCredentials } from '../types';
import { 
    mockMembers, 
    mockAnnouncements,
    mockSchedule,
    mockTransactions,
    mockAlbums,
    mockCommitteeMembers,
    mockElectionSessions,
    mockNominations,
    mockAssets,
    mockFacilities,
    mockBookings,
    mockKhairatTasks,
    mockQurbanSessions,
    mockQurbanParticipants,
    mockNotificationTemplates,
    mockSpeakers,
    mockClassSessions,
    mockSurauInfo,
    mockFinanceCategories,
    mockDutyPersonnel,
    mockAdminCredentials,
} from '../data/mockData';

const MOCK_API_LATENCY = 500; // ms

const KEYS = {
    MEMBERS: 'surau_members',
    ANNOUNCEMENTS: 'surau_announcements',
    SCHEDULE: 'surau_schedule',
    TRANSACTIONS: 'surau_transactions',
    ALBUMS: 'surau_albums',
    COMMITTEE: 'surau_committee',
    ELECTION_SESSIONS: 'surau_election_sessions',
    NOMINATIONS: 'surau_nominations',
    ASSETS: 'surau_assets',
    FACILITIES: 'surau_facilities',
    BOOKINGS: 'surau_bookings',
    KHAIRAT_TASKS: 'surau_khairat_tasks',
    QURBAN_SESSIONS: 'surau_qurban_sessions',
    QURBAN_PARTICIPANTS: 'surau_qurban_participants',
    NOTIFICATION_TEMPLATES: 'surau_notification_templates',
    SPEAKERS: 'surau_speakers',
    CLASS_SESSIONS: 'surau_class_sessions',
    SURAU_INFO: 'surau_info',
    FINANCE_CATEGORIES: 'surau_finance_categories',
    DUTY_PERSONNEL: 'surau_duty_personnel',
    ADMIN_CREDENTIALS: 'surau_admin_credentials',
};

// Generic storage functions simulating API calls
const apiCall = <T>(key: string, mockData: T, dataToWrite?: T): Promise<T> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                if (dataToWrite !== undefined) {
                    // Write operation
                    window.localStorage.setItem(key, JSON.stringify(dataToWrite));
                    resolve(dataToWrite);
                } else {
                    // Read operation
                    const item = window.localStorage.getItem(key);
                    if (item) {
                        resolve(JSON.parse(item));
                    } else {
                        // Seed storage with mock data if it's the first time
                        window.localStorage.setItem(key, JSON.stringify(mockData));
                        resolve(mockData);
                    }
                }
            } catch (error) {
                console.error(`API Error for key “${key}”:`, error);
                reject(new Error(`Failed to process data for ${key}`));
            }
        }, MOCK_API_LATENCY);
    });
};

// Member functions
export const apiGetMembers = (): Promise<Member[]> => apiCall(KEYS.MEMBERS, mockMembers);
export const apiSaveMembers = (members: Member[]): Promise<Member[]> => apiCall(KEYS.MEMBERS, mockMembers, members);

// Announcement functions
export const apiGetAnnouncements = (): Promise<Announcement[]> => apiCall(KEYS.ANNOUNCEMENTS, mockAnnouncements);
export const apiSaveAnnouncements = (announcements: Announcement[]): Promise<Announcement[]> => apiCall(KEYS.ANNOUNCEMENTS, mockAnnouncements, announcements);

// Schedule functions
export const apiGetSchedule = (): Promise<Duty[]> => apiCall(KEYS.SCHEDULE, mockSchedule);
export const apiSaveSchedule = (schedule: Duty[]): Promise<Duty[]> => apiCall(KEYS.SCHEDULE, mockSchedule, schedule);

// Transaction functions
export const apiGetTransactions = (): Promise<Transaction[]> => apiCall(KEYS.TRANSACTIONS, mockTransactions);
export const apiSaveTransactions = (transactions: Transaction[]): Promise<Transaction[]> => apiCall(KEYS.TRANSACTIONS, mockTransactions, transactions);

// Photo Album functions
export const apiGetAlbums = (): Promise<Album[]> => apiCall(KEYS.ALBUMS, mockAlbums);
export const apiSaveAlbums = (albums: Album[]): Promise<Album[]> => apiCall(KEYS.ALBUMS, mockAlbums, albums);

// Committee functions
export const apiGetCommittee = (): Promise<CommitteeMember[]> => apiCall(KEYS.COMMITTEE, mockCommitteeMembers);
export const apiSaveCommittee = (committee: CommitteeMember[]): Promise<CommitteeMember[]> => apiCall(KEYS.COMMITTEE, mockCommitteeMembers, committee);

// Election functions
export const apiGetElectionSessions = (): Promise<ElectionSession[]> => apiCall(KEYS.ELECTION_SESSIONS, mockElectionSessions);
export const apiSaveElectionSessions = (sessions: ElectionSession[]): Promise<ElectionSession[]> => apiCall(KEYS.ELECTION_SESSIONS, mockElectionSessions, sessions);

export const apiGetNominations = (): Promise<Nomination[]> => apiCall(KEYS.NOMINATIONS, mockNominations);
export const apiSaveNominations = (nominations: Nomination[]): Promise<Nomination[]> => apiCall(KEYS.NOMINATIONS, mockNominations, nominations);

// Asset functions
export const apiGetAssets = (): Promise<Asset[]> => apiCall(KEYS.ASSETS, mockAssets);
export const apiSaveAssets = (assets: Asset[]): Promise<Asset[]> => apiCall(KEYS.ASSETS, mockAssets, assets);

// Facility & Booking functions
export const apiGetFacilities = (): Promise<Facility[]> => apiCall(KEYS.FACILITIES, mockFacilities);
export const apiSaveFacilities = (facilities: Facility[]): Promise<Facility[]> => apiCall(KEYS.FACILITIES, mockFacilities, facilities);
export const apiGetBookings = (): Promise<Booking[]> => apiCall(KEYS.BOOKINGS, mockBookings);
export const apiSaveBookings = (bookings: Booking[]): Promise<Booking[]> => apiCall(KEYS.BOOKINGS, mockBookings, bookings);

// Khairat Task Functions
export const apiGetKhairatTasks = (): Promise<KhairatTask[]> => apiCall(KEYS.KHAIRAT_TASKS, mockKhairatTasks);
export const apiSaveKhairatTasks = (tasks: KhairatTask[]): Promise<KhairatTask[]> => apiCall(KEYS.KHAIRAT_TASKS, mockKhairatTasks, tasks);

// Qurban & Aqiqah Functions
export const apiGetQurbanSessions = (): Promise<QurbanSession[]> => apiCall(KEYS.QURBAN_SESSIONS, mockQurbanSessions);
export const apiSaveQurbanSessions = (sessions: QurbanSession[]): Promise<QurbanSession[]> => apiCall(KEYS.QURBAN_SESSIONS, mockQurbanSessions, sessions);
export const apiGetQurbanParticipants = (): Promise<QurbanParticipant[]> => apiCall(KEYS.QURBAN_PARTICIPANTS, mockQurbanParticipants);
export const apiSaveQurbanParticipants = (participants: QurbanParticipant[]): Promise<QurbanParticipant[]> => apiCall(KEYS.QURBAN_PARTICIPANTS, mockQurbanParticipants, participants);

// Notification Template Functions
export const apiGetNotificationTemplates = (): Promise<NotificationTemplate[]> => apiCall(KEYS.NOTIFICATION_TEMPLATES, mockNotificationTemplates);
export const apiSaveNotificationTemplates = (templates: NotificationTemplate[]): Promise<NotificationTemplate[]> => apiCall(KEYS.NOTIFICATION_TEMPLATES, mockNotificationTemplates, templates);

// Speaker functions
export const apiGetSpeakers = (): Promise<Speaker[]> => apiCall(KEYS.SPEAKERS, mockSpeakers);
export const apiSaveSpeakers = (speakers: Speaker[]): Promise<Speaker[]> => apiCall(KEYS.SPEAKERS, mockSpeakers, speakers);

// Class Session functions
export const apiGetClassSessions = (): Promise<ClassSession[]> => apiCall(KEYS.CLASS_SESSIONS, mockClassSessions);
export const apiSaveClassSessions = (sessions: ClassSession[]): Promise<ClassSession[]> => apiCall(KEYS.CLASS_SESSIONS, mockClassSessions, sessions);

// --- Settings Functions ---
export const apiGetSurauInfo = (): Promise<SurauInfo> => apiCall(KEYS.SURAU_INFO, mockSurauInfo);
export const apiSaveSurauInfo = (info: SurauInfo): Promise<SurauInfo> => apiCall(KEYS.SURAU_INFO, mockSurauInfo, info);

export const apiGetFinanceCategories = (): Promise<FinanceCategories> => apiCall(KEYS.FINANCE_CATEGORIES, mockFinanceCategories);
export const apiSaveFinanceCategories = (categories: FinanceCategories): Promise<FinanceCategories> => apiCall(KEYS.FINANCE_CATEGORIES, mockFinanceCategories, categories);

export const apiGetDutyPersonnel = (): Promise<DutyPersonnel> => apiCall(KEYS.DUTY_PERSONNEL, mockDutyPersonnel);
export const apiSaveDutyPersonnel = (personnel: DutyPersonnel): Promise<DutyPersonnel> => apiCall(KEYS.DUTY_PERSONNEL, mockDutyPersonnel, personnel);

// Admin Credentials
export const apiGetAdminCredentials = (): Promise<AdminCredentials> => apiCall(KEYS.ADMIN_CREDENTIALS, mockAdminCredentials);
export const apiSaveAdminCredentials = (creds: AdminCredentials): Promise<AdminCredentials> => apiCall(KEYS.ADMIN_CREDENTIALS, mockAdminCredentials, creds);


// Backup and Restore
export const apiGetAllData = (): Promise<Record<string, any>> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            const allData: Record<string, any> = {};
            for (const key of Object.values(KEYS)) {
                const item = window.localStorage.getItem(key);
                if (item) {
                    allData[key] = JSON.parse(item);
                }
            }
            resolve(allData);
        }, MOCK_API_LATENCY);
    });
};

export const apiRestoreAllData = (data: Record<string, any>): Promise<void> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            for (const key in data) {
                if (Object.values(KEYS).includes(key)) {
                    window.localStorage.setItem(key, JSON.stringify(data[key]));
                }
            }
            resolve();
        }, MOCK_API_LATENCY);
    });
};


// --- Payment Gateway Function ---
export const apiCreateToyyibpayBill = (details: {
    userName: string;
    userEmail: string;
    userPhone: string;
    billAmount: number;
    billDescription: string;
}): Promise<{ billCode: string; billpaymentUrl: string }> => {
    return new Promise((resolve, reject) => {
        apiGetSurauInfo().then(info => {
             if (!info.paymentGateway?.categoryCode || !info.paymentGateway?.secretKey) {
                return reject(new Error("ToyyibPay Category Code atau Secret Key belum ditetapkan di bahagian Tetapan."));
            }
            setTimeout(() => {
                const billCode = `tp-${Date.now()}`;
                // In a real scenario, this would be a real URL from ToyyibPay
                // For demo, we can use a placeholder
                const mockPaymentUrl = `https://toyyibpay.com/${billCode}`;
                console.log("Mock ToyyibPay Bill Created:", { ...details, billCode, category: info.paymentGateway.categoryCode });
                resolve({ billCode, billpaymentUrl: mockPaymentUrl });
            }, MOCK_API_LATENCY);
        }).catch(reject);
    });
};

// Member login function
export const apiLoginMember = (icNumber: string, password_unused: string): Promise<Member | null> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const item = window.localStorage.getItem(KEYS.MEMBERS);
                const members: Member[] = item ? JSON.parse(item) : mockMembers;

                if (password_unused !== 'password123') {
                    resolve(null);
                    return;
                }

                const icWithoutHyphens = icNumber.replace(/-/g, '');
                const member = members.find(m => m.icNumber.replace(/-/g, '') === icWithoutHyphens);
                
                if (member) {
                    if (member.status === 'Aktif') {
                        resolve(member);
                    } else if (member.status === 'Menunggu Pengesahan') {
                        reject(new Error("Akaun anda masih menunggu pengesahan daripada pihak surau."));
                    } else {
                        // Any other status like 'Meninggal Dunia' will result in login failure
                        resolve(null);
                    }
                } else {
                    resolve(null);
                }
            } catch (error) {
                console.error(`API Error for login:`, error);
                reject(new Error(`Gagal memproses log masuk untuk ${icNumber}`));
            }
        }, MOCK_API_LATENCY);
    });
};