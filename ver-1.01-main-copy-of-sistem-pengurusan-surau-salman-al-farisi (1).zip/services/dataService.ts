import { Member, Announcement, Duty, Transaction, SurauInfo, FinanceCategories, DutyPersonnel, Album, CommitteeMember, ElectionSession, Nomination, Asset, Facility, Booking, KhairatTask, QurbanSession, QurbanParticipant, NotificationTemplate, Speaker, ClassSession, AdminCredentials } from '../types';
import { 
    apiGetMembers, 
    apiSaveMembers, 
    apiGetAnnouncements,
    apiSaveAnnouncements,
    apiGetSchedule,
    apiSaveSchedule,
    apiGetTransactions,
    apiSaveTransactions,
    apiGetAlbums,
    apiSaveAlbums,
    apiGetCommittee,
    apiSaveCommittee,
    apiGetElectionSessions,
    apiSaveElectionSessions,
    apiGetNominations,
    apiSaveNominations,
    apiGetAssets,
    apiSaveAssets,
    apiGetFacilities,
    apiSaveFacilities,
    apiGetBookings,
    apiSaveBookings,
    apiGetKhairatTasks,
    apiSaveKhairatTasks,
    apiGetQurbanSessions,
    apiSaveQurbanSessions,
    apiGetQurbanParticipants,
    apiSaveQurbanParticipants,
    apiGetNotificationTemplates,
    apiSaveNotificationTemplates,
    apiGetSpeakers,
    apiSaveSpeakers,
    apiGetClassSessions,
    apiSaveClassSessions,
    apiGetSurauInfo,
    apiSaveSurauInfo,
    apiGetFinanceCategories,
    apiSaveFinanceCategories,
    apiGetDutyPersonnel,
    apiSaveDutyPersonnel,
    apiCreateToyyibpayBill,
    apiLoginMember,
    apiGetAdminCredentials,
    apiSaveAdminCredentials,
    apiGetAllData,
    apiRestoreAllData
} from './api';

// Member functions
export const getMembers = async (): Promise<Member[]> => apiGetMembers();
export const saveMembers = async (members: Member[]): Promise<void> => {
    await apiSaveMembers(members);
};

export const loginMember = (icNumber: string, password_unused: string): Promise<Member | null> => apiLoginMember(icNumber, password_unused);

// Announcement functions
export const getAnnouncements = async (): Promise<Announcement[]> => apiGetAnnouncements();
export const saveAnnouncements = async (announcements: Announcement[]): Promise<void> => {
    await apiSaveAnnouncements(announcements);
};

// Schedule functions
export const getSchedule = async (): Promise<Duty[]> => apiGetSchedule();
export const saveSchedule = async (schedule: Duty[]): Promise<void> => {
    await apiSaveSchedule(schedule);
};

// Transaction functions
export const getTransactions = async (): Promise<Transaction[]> => apiGetTransactions();
export const saveTransactions = async (transactions: Transaction[]): Promise<void> => {
    await apiSaveTransactions(transactions);
};

// Photo Album functions
export const getAlbums = async (): Promise<Album[]> => apiGetAlbums();
export const saveAlbums = async (albums: Album[]): Promise<void> => {
    await apiSaveAlbums(albums);
};

// Committee functions
export const getCommittee = async (): Promise<CommitteeMember[]> => apiGetCommittee();
export const saveCommittee = async (committee: CommitteeMember[]): Promise<void> => {
    await apiSaveCommittee(committee);
};

// Election functions
export const getElectionSessions = async (): Promise<ElectionSession[]> => apiGetElectionSessions();
export const saveElectionSessions = async (sessions: ElectionSession[]): Promise<void> => {
    await apiSaveElectionSessions(sessions);
};

export const getNominations = async (): Promise<Nomination[]> => apiGetNominations();
export const saveNominations = async (nominations: Nomination[]): Promise<void> => {
    await apiSaveNominations(nominations);
};

// Asset functions
export const getAssets = async (): Promise<Asset[]> => apiGetAssets();
export const saveAssets = async (assets: Asset[]): Promise<void> => {
    await apiSaveAssets(assets);
};

// Facility & Booking Functions
export const getFacilities = async (): Promise<Facility[]> => apiGetFacilities();
export const saveFacilities = async (facilities: Facility[]): Promise<void> => {
    await apiSaveFacilities(facilities);
};
export const getBookings = async (): Promise<Booking[]> => apiGetBookings();
export const saveBookings = async (bookings: Booking[]): Promise<void> => {
    await apiSaveBookings(bookings);
};

// Khairat Task Functions
export const getKhairatTasks = async (): Promise<KhairatTask[]> => apiGetKhairatTasks();
export const saveKhairatTasks = async (tasks: KhairatTask[]): Promise<void> => {
    await apiSaveKhairatTasks(tasks);
};

// Qurban & Aqiqah Functions
export const getQurbanSessions = async (): Promise<QurbanSession[]> => apiGetQurbanSessions();
export const saveQurbanSessions = async (sessions: QurbanSession[]): Promise<void> => {
    await apiSaveQurbanSessions(sessions);
};
export const getQurbanParticipants = async (): Promise<QurbanParticipant[]> => apiGetQurbanParticipants();
export const saveQurbanParticipants = async (participants: QurbanParticipant[]): Promise<void> => {
    await apiSaveQurbanParticipants(participants);
};

// Notification Template Functions
export const getNotificationTemplates = async (): Promise<NotificationTemplate[]> => apiGetNotificationTemplates();
export const saveNotificationTemplates = async (templates: NotificationTemplate[]): Promise<void> => {
    await apiSaveNotificationTemplates(templates);
};

// Speaker & Class Functions
export const getSpeakers = async (): Promise<Speaker[]> => apiGetSpeakers();
export const saveSpeakers = async (speakers: Speaker[]): Promise<void> => {
    await apiSaveSpeakers(speakers);
};

export const getClassSessions = async (): Promise<ClassSession[]> => apiGetClassSessions();
export const saveClassSessions = async (sessions: ClassSession[]): Promise<void> => {
    await apiSaveClassSessions(sessions);
};


// --- Settings Functions ---
export const getSurauInfo = async (): Promise<SurauInfo> => apiGetSurauInfo();
export const saveSurauInfo = async (info: SurauInfo): Promise<void> => {
    await apiSaveSurauInfo(info);
};

export const getFinanceCategories = async (): Promise<FinanceCategories> => apiGetFinanceCategories();
export const saveFinanceCategories = async (categories: FinanceCategories): Promise<void> => {
    await apiSaveFinanceCategories(categories);
};

export const getDutyPersonnel = async (): Promise<DutyPersonnel> => apiGetDutyPersonnel();
export const saveDutyPersonnel = async (personnel: DutyPersonnel): Promise<void> => {
    await apiSaveDutyPersonnel(personnel);
};

export const getAdminCredentials = async (): Promise<AdminCredentials> => apiGetAdminCredentials();
export const saveAdminCredentials = async (creds: AdminCredentials): Promise<void> => {
    await apiSaveAdminCredentials(creds);
};

export const getAllDataForBackup = async (): Promise<Record<string, any>> => apiGetAllData();
export const restoreDataFromBackup = async (data: Record<string, any>): Promise<void> => {
    await apiRestoreAllData(data);
};


// --- Payment Gateway Function ---
export const createToyyibpayBill = async (details: {
    userName: string;
    userEmail: string;
    userPhone: string;
    billAmount: number;
    billDescription: string;
}): Promise<{ billCode: string; billpaymentUrl: string }> => apiCreateToyyibpayBill(details);