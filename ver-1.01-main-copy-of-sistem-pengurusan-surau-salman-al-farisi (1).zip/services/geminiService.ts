import { GoogleGenAI } from "@google/genai";
import type { ActivityPlan, FeedbackAnalysis, AIInsight, DailyInspiration } from '../types';

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini API features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "DISABLED" });

export const generateAnnouncement = async (topic: string): Promise<string> => {
  if (!process.env.API_KEY) {
    return Promise.resolve("Ciri AI tidak tersedia. Sila tetapkan API_KEY anda.");
  }

  try {
    const prompt = `Anda adalah setiausaha sebuah surau di Malaysia bernama Surau Salman Al-Farisi. Tulis satu pengumuman ringkas dan padat dalam Bahasa Melayu mengenai topik ini: "${topic}". Pengumuman harus mesra, jelas, dan menjemput ahli kariah untuk turut serta jika berkaitan.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-04-17',
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 1,
        topK: 1,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Error generating announcement:", error);
    return "Maaf, berlaku ralat semasa menjana pengumuman. Sila cuba lagi.";
  }
};

export const generateActivityPlan = async (topic: string): Promise<ActivityPlan | string> => {
  if (!process.env.API_KEY) {
    return "Ciri AI tidak tersedia. Sila tetapkan API_KEY anda.";
  }

  try {
    const prompt = `Anda adalah pembantu perancangan aktiviti yang sangat cekap untuk sebuah surau di Malaysia. Berdasarkan idea ini: "${topic}", jana satu pelan tindakan yang lengkap dalam format JSON. Sila patuhi struktur JSON berikut:
{
  "announcementTitle": "string",
  "announcementContent": "string",
  "checklist": ["string"],
  "budgetEstimate": [{"item": "string", "cost": number}],
  "schedule": [{"time": "string", "activity": "string"}]
}

Pastikan semua teks dalam Bahasa Melayu yang sesuai untuk komuniti surau. Jadikan 'announcementContent' sebagai draf hebahan yang lengkap dan mesra. Jadikan 'checklist' sebagai senarai tindakan yang praktikal dari A hingga Z. Untuk 'budgetEstimate', berikan anggaran yang munasabah. Untuk 'schedule', sediakan aturcara majlis yang logik.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.8,
      },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    const parsedData = JSON.parse(jsonStr);
    const plan = Array.isArray(parsedData) ? parsedData[0] : parsedData;
    
    // Basic validation
    if (plan.announcementTitle && plan.announcementContent && plan.checklist && plan.budgetEstimate && plan.schedule) {
      return plan as ActivityPlan;
    } else {
        console.error("Invalid JSON structure received from API:", plan);
        throw new Error("Struktur JSON yang diterima dari API tidak sah.");
    }

  } catch (error) {
    console.error("Error generating activity plan:", error);
    return `Maaf, berlaku ralat semasa menjana pelan aktiviti. Sila cuba lagi. Ralat: ${error instanceof Error ? error.message : String(error)}`;
  }
};

export const analyzeFeedback = async (feedbackText: string): Promise<FeedbackAnalysis | string> => {
  if (!process.env.API_KEY) {
    return "Ciri AI tidak tersedia. Sila tetapkan API_KEY anda.";
  }

  try {
    const prompt = `Anda adalah penganalisis maklum balas sistem yang bijak. Berdasarkan teks maklum balas berikut daripada pengguna sebuah sistem pengurusan surau, ringkaskan dan kategorikan isu-isu utama.
    Teks Maklum Balas: "${feedbackText}"
    
    Sediakan output dalam format JSON yang sah dengan struktur berikut:
    {
      "summary": "string (Ringkasan keseluruhan maklum balas dalam satu atau dua ayat)",
      "suggestions": [
        {
          "category": "Bug Report" | "Feature Request" | "UI/UX Improvement" | "Other",
          "details": "string (Huraian terperinci bagi cadangan ini)"
        }
      ]
    }
    
    Pastikan 'category' adalah salah satu daripada empat pilihan yang diberikan. Sediakan beberapa cadangan jika ada beberapa perkara yang dibangkitkan. Pastikan semua teks dalam Bahasa Melayu.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.5,
      },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    const parsedData = JSON.parse(jsonStr);
    const feedback = Array.isArray(parsedData) ? parsedData[0] : parsedData;

    // Basic validation
    if (feedback.summary && Array.isArray(feedback.suggestions)) {
      return feedback as FeedbackAnalysis;
    } else {
        console.error("Invalid JSON structure received from API for feedback:", feedback);
        throw new Error("Struktur JSON yang diterima dari API tidak sah.");
    }

  } catch (error) {
    console.error("Error analyzing feedback:", error);
    return `Maaf, berlaku ralat semasa menganalisis maklum balas. Sila cuba lagi. Ralat: ${error instanceof Error ? error.message : String(error)}`;
  }
};

export const generateDashboardInsight = async (dataSummary: string): Promise<AIInsight | string> => {
    if (!process.env.API_KEY) {
        return "Ciri AI tidak tersedia. Sila tetapkan API_KEY anda.";
    }

    try {
        const prompt = `Anda adalah seorang penasihat pengurusan surau yang berpengalaman. Berdasarkan ringkasan data berikut, berikan SATU pandangan (insight) atau cadangan yang paling penting dan boleh diambil tindakan oleh AJK surau.
        
        Ringkasan Data: "${dataSummary}"
        
        Sediakan output dalam format JSON yang sah dengan struktur berikut. Pastikan cadangan itu kreatif, proaktif dan ringkas.
        {
          "title": "string (Tajuk pendek untuk cadangan anda, cth: 'Tingkatkan Kutipan Derma')",
          "suggestion": "string (Huraian cadangan anda dalam satu ayat yang jelas dan boleh diambil tindakan.)",
          "category": "Kewangan" | "Aktiviti" | "Kariah" | "Lain-lain"
        }
        
        Fokus pada satu perkara yang paling memberi impak. Pastikan semua teks dalam Bahasa Melayu.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                temperature: 0.9,
                topK: 1,
            },
        });
        
        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }

        const parsedData = JSON.parse(jsonStr);
        const insight = Array.isArray(parsedData) ? parsedData[0] : parsedData;
        
        if (insight.title && insight.suggestion && insight.category) {
            return insight as AIInsight;
        } else {
            console.error("Invalid JSON structure received from API for insight:", insight);
            throw new Error("Struktur JSON yang diterima dari API tidak sah.");
        }

    } catch (error) {
        console.error("Error generating dashboard insight:", error);
        return `Maaf, berlaku ralat semasa menjana pandangan. Sila cuba lagi.`;
    }
};

export const generateDailyInspiration = async (): Promise<DailyInspiration | string> => {
    if (!process.env.API_KEY) {
        return "Ciri AI tidak tersedia.";
    }

    try {
        const prompt = `Anda adalah seorang kurator kandungan Islamik. Jana SATU mutiara kata atau hadis pendek yang ringkas, sahih, dan memberi inspirasi untuk paparan skrin digital di sebuah surau.
        
        Sediakan output dalam format JSON yang sah dengan struktur berikut. Pastikan ia ringkas dan padat.
        {
          "quote": "string (Petikan mutiara kata atau terjemahan hadis. Maksimum 20 perkataan.)",
          "source": "string (Sumber petikan, cth: 'Hadis Riwayat Bukhari' atau 'Kata-kata Hikmah')"
        }
        
        Fokus pada tema seperti kesabaran, kesyukuran, kebaikan, atau zikir. Pastikan semua teks dalam Bahasa Melayu.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                temperature: 1.0,
                topK: 1,
            },
        });
        
        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }

        const parsedData = JSON.parse(jsonStr);
        const inspiration = Array.isArray(parsedData) ? parsedData[0] : parsedData;
        
        if (inspiration.quote && inspiration.source) {
            return inspiration as DailyInspiration;
        } else {
            console.error("Invalid JSON structure received from API for inspiration:", inspiration);
            throw new Error("Struktur JSON yang diterima dari API tidak sah.");
        }

    } catch (error) {
        console.error("Error generating daily inspiration:", error);
        return `Maaf, berlaku ralat semasa menjana inspirasi harian.`;
    }
};