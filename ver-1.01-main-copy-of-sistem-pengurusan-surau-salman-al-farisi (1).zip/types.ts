export enum Page {
  Dashboard = 'Papan Pemuka',
  Kariah = 'Ahli Kariah',
  Jawatankuasa = 'Jawatankuasa',
  Pemilihan = 'Pemilihan AJK',
  Kewangan = 'Kewangan',
  Laporan = 'Laporan Kewangan',
  Aset = 'Aset & Inventori',
  Tempahan = 'Tempahan Fasiliti',
  Korban = 'Korban & Aqiqah',
  Jadual = 'Jadual Bertugas',
  Aktiviti = 'Aktiviti & Galeri',
  Notifikasi = 'Notifikasi',
  UpdateSistem = 'Update Sistem',
  Tetapan = 'Tetapan',
  Public = 'Laman Web Awam',
  Kelas = 'Kelas & Kuliah',
  InfoScreen = 'InfoScreen',
}

export interface Dependent {
  id: number;
  name: string;
  relationship: string;
  status: 'Hidup' | 'Meninggal Dunia';
}

export interface Payment {
  id: number;
  year: number;
  amount: number;
  paymentDate: string;
  status: 'Lunas' | 'Tertunggak' | 'Menunggu Pembayaran';
  billCode?: string;
}

export interface Member {
  id: number;
  name: string;
  icNumber: string;
  address: string;
  phone: string;
  joinDate: string;
  dependents: Dependent[];
  khairatPayments: Payment[];
  status: 'Aktif' | 'Menunggu Pengesahan' | 'Meninggal Dunia';
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  type: 'Derma' | 'Perbelanjaan';
  amount: number;
  category?: string;
  memberId?: number;
  payerName?: string;
}

export interface Duty {
  day: 'Isnin' | 'Selasa' | 'Rabu' | 'Khamis' | 'Jumaat' | 'Sabtu' | 'Ahad';
  subuh: { imam: string; bilal: string; };
  zohor: { imam: string; bilal: string; };
  asar: { imam: string; bilal: string; };
  maghrib: { imam: string; bilal: string; };
  isyak: { imam: string; bilal: string; };
}

export interface Announcement {
  id: number;
  title: string;
  content: string;
  date: string;
  imageUrl?: string;
}

export interface Photo {
  id: string;
  url: string; 
  caption?: string;
}

export interface Album {
  id: number;
  title: string;
  date: string;
  coverImageUrl: string;
  photos: Photo[];
}

export interface CommitteeMember {
    id: number;
    name: string;
    position: string;
    session: string;
    phone: string;
    email: string;
    imageUrl?: string;
}

export interface ContestedPosition {
    position: string;
    vacancies: number;
}

export interface ElectionSession {
    id: number;
    title: string;
    nominationStartDate: string;
    nominationEndDate: string;
    votingStartDate: string;
    votingEndDate: string;
    status: 'Akan Datang' | 'Pencalonan' | 'Pengundian' | 'Selesai';
    contestedPositions: ContestedPosition[];
    candidates: Candidate[];
    votes: Vote[];
}

export interface Nomination {
    id: number;
    sessionId: number;
    nominatedMemberId: number;
    nominatorMemberId: number;
    position: string;
    status: 'Menunggu' | 'Diterima' | 'Ditolak';
    nominationDate: string;
}

export interface Candidate {
    id: number; // Member ID
    name: string;
    position: string;
    imageUrl?: string;
}

export interface Vote {
    voterMemberId: number;
    sessionId: number;
    selections: {
        position: string;
        candidateIds: number[];
    }[];
    voteDate: string;
}

export interface Asset {
    id: number;
    name: string;
    category: string;
    location: string;
    purchaseDate: string;
    purchaseValue: number;
    condition: 'Baik' | 'Perlu Penyelenggaraan' | 'Rosak';
    imageUrl?: string;
}

export interface Facility {
    id: number;
    name: string;
    description: string;
    rentalRate: number; // 0 if free
    imageUrl?: string;
}

export interface Booking {
    id: number;
    facilityId: number;
    facilityName: string;
    userName: string;
    userContact: string;
    eventDetails: string;
    bookingDate: string;
    status: 'Menunggu Pengesahan' | 'Diluluskan' | 'Ditolak';
}

export interface KhairatTask {
    id: number;
    memberId: number;
    memberName: string;
    dependentId?: number;
    dependentName?: string;
    type: 'Ahli' | 'Tanggungan';
    amount: number;
    deathDate: string;
    status: 'Menunggu Tindakan' | 'Selesai';
    processedDate?: string;
}

export interface QurbanSession {
    id: number;
    year: number;
    title: string;
    pricePerPart: number;
    totalParts: number;
    status: 'Buka' | 'Tutup';
}

export interface QurbanParticipant {
    id: number;
    sessionId: number;
    name: string;
    phone: string;
    email?: string;
    parts: number;
    totalAmount: number;
    paymentStatus: 'Lunas' | 'Belum Bayar';
    registrationDate: string;
    billCode?: string;
}

export interface NotificationTemplate {
    id: number;
    name: string;
    type: 'Email' | 'WhatsApp';
    subject?: string; // For Email
    content: string; // Supports variables like [Nama Ahli]
}

export interface Speaker {
    id: number;
    name: string;
    phone?: string;
    expertise?: string;
}

export interface ClassSession {
    id: number;
    title: string;
    description?: string;
    speakerId: number;
    isRecurring: boolean;
    day?: 'Isnin' | 'Selasa' | 'Rabu' | 'Khamis' | 'Jumaat' | 'Sabtu' | 'Ahad';
    date?: string; // For one-off class
    time: string;
    honorarium: number;
    paymentStatus: 'Belum Dibayar' | 'Sudah Dibayar';
}

export interface ActivityPlan {
  announcementTitle: string;
  announcementContent: string;
  checklist: string[];
  budgetEstimate: { item: string; cost: number; }[];
  schedule: { time: string; activity: string; }[];
}

export interface InfoScreenSettings {
  backgroundVideoUrls: string[];
  azanSubuhVideoUrl: string;
  azanVideoUrl: string;
}

// --- Types for Settings ---
export interface SurauInfo {
    name: string;
    address: string;
    logoUrl?: string;
    khairatAmountMember: number;
    khairatAmountDependent: number;
    paymentGateway: {
        categoryCode: string;
        secretKey: string;
    };
    infoScreenSettings: InfoScreenSettings;
}

export interface FinanceCategories {
    income: string[];
    expense: string[];
}

export interface DutyPersonnel {
    imams: string[];
    bilals: string[];
}

export interface AdminCredentials {
    username: string;
    password_plaintext: string;
}

// --- Types for Toast Notifications ---
export type ToastType = 'success' | 'error' | 'info';

export interface ToastNotification {
  id: number;
  message: string;
  type: ToastType;
}

export interface ToastContextType {
  addToast: (message: string, type?: ToastType) => void;
}

// --- Type for App View Mode ---
export type ViewMode = 'Admin' | 'Public' | 'Login' | 'MemberDashboard' | 'MemberLogin';

// --- Type for Print Context ---
export interface PrintContextType {
    isPrinting: boolean;
    handlePrint: () => void;
}

// --- Types for Prayer Times ---
export interface PrayerTime {
    hijri: string;
    date: string;
    imsak: string;
    subuh: string;
    syuruk: string;
    zohor: string;
    asar: string;
    maghrib: string;
    isyak: string;
}

export interface PrayerData {
    prayerTime: PrayerTime[];
    status: string;
    zone: string;
}

// --- Types for System Update ---
export interface FeedbackAnalysis {
  summary: string;
  suggestions: {
    category: 'Bug Report' | 'Feature Request' | 'UI/UX Improvement' | 'Other';
    details: string;
  }[];
}

// --- Types for AI Insights ---
export interface AIInsight {
  title: string;
  suggestion: string;
  category: 'Kewangan' | 'Aktiviti' | 'Kariah' | 'Lain-lain';
}
// --- Type for Settings Tabs ---
export type SettingsTab = 'Umum' | 'Kewangan' | 'Data Sistem' | 'Keselamatan' | 'InfoScreen';

// --- Type for InfoScreen Daily Inspiration ---
export interface DailyInspiration {
    quote: string;
    source: string;
}

// --- Types for Islamic Events ---
export interface IslamicEvent {
    name: string;
    date: string; // YYYY-MM-DD
}

// --- Types for InfoScreen Slides ---
export type IdleSlide = 'main' | 'community' | 'event';