

import React, { useState, createContext, useContext, useCallback, useEffect } from 'react';
import { Page, ToastNotification, ToastType, ToastContextType, ViewMode, PrintContextType, Member } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Kariah from './components/Kariah';
import Kewangan from './components/Kewangan';
import LaporanKewangan from './components/LaporanKewangan';
import Jadual from './components/Jadual';
import Aktiviti from './components/Aktiviti';
import Settings from './components/Settings';
import PublicWebsite from './components/PublicWebsite';
import LoginPage from './components/LoginPage';
import MemberPortal from './components/MemberPortal';
import LoginPageAhli from './components/LoginPageAhli';
import Jawatankuasa from './components/Jawatankuasa';
import Pemilihan from './components/Pemilihan';
import Aset from './components/Aset';
import Tempahan from './components/Tempahan';
import Korban from './components/Korban';
import Notifikasi from './components/Notifikasi';
import Kelas from './components/Kelas';
import UpdateSistem from './components/UpdateSistem';
import InfoScreen from './components/InfoScreen';
import { CheckCircleIcon, XCircleIcon, InfoIcon, CloseIcon } from './components/icons';

// --- Toast Context ---
const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const useToast = () => {
    const context = useContext(ToastContext);
    if (!context) {
        throw new Error('useToast must be used within a ToastProvider');
    }
    return context;
};

// --- Print Context ---
const PrintContext = createContext<PrintContextType | undefined>(undefined);
export const usePrint = () => {
    const context = useContext(PrintContext);
    if (!context) throw new Error("usePrint must be used within a PrintProvider");
    return context;
};

const Toast: React.FC<{ notification: ToastNotification; onDismiss: (id: number) => void }> = ({ notification, onDismiss }) => {
    const { id, message, type } = notification;

    const ICONS = {
        success: <CheckCircleIcon className="w-6 h-6 text-green-500" />,
        error: <XCircleIcon className="w-6 h-6 text-red-500" />,
        info: <InfoIcon className="w-6 h-6 text-blue-500" />,
    };

    const BORDER_COLORS = {
        success: 'border-green-500',
        error: 'border-red-500',
        info: 'border-blue-500',
    };

    React.useEffect(() => {
        const timer = setTimeout(() => {
            onDismiss(id);
        }, 5000);
        return () => clearTimeout(timer);
    }, [id, onDismiss]);

    return (
        <div className={`bg-white shadow-lg rounded-lg flex items-start p-4 border-l-4 ${BORDER_COLORS[type]} animate-fade-in`}>
            <div className="flex-shrink-0">{ICONS[type]}</div>
            <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">{message}</p>
            </div>
            <div className="ml-4 flex-shrink-0 flex">
                <button onClick={() => onDismiss(id)} className="inline-flex text-gray-400 hover:text-gray-500">
                    <CloseIcon className="h-5 w-5" />
                </button>
            </div>
        </div>
    );
};

const ToastContainer: React.FC<{ notifications: ToastNotification[]; onDismiss: (id: number) => void }> = ({ notifications, onDismiss }) => {
    return (
        <div className="fixed top-0 right-0 p-4 w-full max-w-sm z-[100]">
            <div className="space-y-4">
                {notifications.map((n) => (
                    <Toast key={n.id} notification={n} onDismiss={onDismiss} />
                ))}
            </div>
        </div>
    );
};


const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.Dashboard);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const [isPrinting, setIsPrinting] = useState(false);
  
  // Auth state management
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => sessionStorage.getItem('isAuthenticated') === 'true');
  const [currentMember, setCurrentMember] = useState<Member | null>(() => {
    const memberData = sessionStorage.getItem('currentMember');
    return memberData ? JSON.parse(memberData) : null;
  });

  const getInitialViewMode = (): ViewMode => {
    if (sessionStorage.getItem('currentMember')) return 'MemberDashboard';
    if (sessionStorage.getItem('isAuthenticated') === 'true') return 'Admin';
    return 'Public';
  }
  
  const [viewMode, setViewMode] = useState<ViewMode>(getInitialViewMode());
  
  const [kariahInitialTab, setKariahInitialTab] = useState<'aktif' | 'pengesahan'>('aktif');


  const addToast = useCallback((message: string, type: ToastType = 'success') => {
    const id = Date.now();
    setToasts((prevToasts) => [...prevToasts, { id, message, type }]);
  }, []);

  const removeToast = (id: number) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
  };
  
  const handlePrint = () => {
        setIsPrinting(true);
        setTimeout(() => {
            window.print();
            setIsPrinting(false);
        }, 50); // Short delay to allow UI to update
    };
  
  const handleLogin = (success: boolean) => {
    if (success) {
        sessionStorage.setItem('isAuthenticated', 'true');
        setIsAuthenticated(true);
        setViewMode('Admin');
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('isAuthenticated');
    setIsAuthenticated(false);
    setViewMode('Login');
  };

  const handleMemberLogin = (member: Member) => {
    sessionStorage.setItem('currentMember', JSON.stringify(member));
    setCurrentMember(member);
    setViewMode('MemberDashboard');
  };

  const handleMemberLogout = () => {
    sessionStorage.removeItem('currentMember');
    setCurrentMember(null);
    setViewMode('Public');
  };

  useEffect(() => {
    if (!isAuthenticated && viewMode === 'Admin') {
        setViewMode('Login');
    }
  }, [isAuthenticated, viewMode]);

  const handleSetPage = (page: Page) => {
    setKariahInitialTab('aktif');
    setCurrentPage(page);
  };
  
  const handleViewPending = () => {
    setKariahInitialTab('pengesahan');
    setCurrentPage(Page.Kariah);
  };
  
  const renderPage = () => {
    switch (currentPage) {
      case Page.Kariah:
        return <Kariah initialTab={kariahInitialTab} setActivePage={setCurrentPage} />;
      case Page.Jawatankuasa:
        return <Jawatankuasa />;
      case Page.Pemilihan:
        return <Pemilihan setActivePage={setCurrentPage} />;
      case Page.Kewangan:
        return <Kewangan />;
      case Page.Laporan:
        return <LaporanKewangan />;
      case Page.Aset:
        return <Aset />;
      case Page.Tempahan:
        return <Tempahan />;
      case Page.Korban:
        return <Korban />;
      case Page.Kelas:
        return <Kelas />;
      case Page.Jadual:
        return <Jadual />;
      case Page.Aktiviti:
        return <Aktiviti />;
      case Page.Notifikasi:
        return <Notifikasi />;
      case Page.UpdateSistem:
        return <UpdateSistem />;
      case Page.Tetapan:
        return <Settings />;
      case Page.Dashboard:
      default:
        return <Dashboard setActivePage={setCurrentPage} viewPending={handleViewPending} />;
    }
  };
  
  if (currentPage === Page.InfoScreen) {
    return <InfoScreen />;
  }
  
  if (viewMode === 'Login') {
      return (
          <ToastContext.Provider value={{ addToast }}>
              <LoginPage onLogin={handleLogin} setViewMode={setViewMode} />
              <ToastContainer notifications={toasts} onDismiss={removeToast} />
          </ToastContext.Provider>
      );
  }

  if (viewMode === 'MemberLogin') {
      return (
           <ToastContext.Provider value={{ addToast }}>
              <LoginPageAhli onLogin={handleMemberLogin} setViewMode={setViewMode} />
              <ToastContainer notifications={toasts} onDismiss={removeToast} />
          </ToastContext.Provider>
      );
  }
  
   if (viewMode === 'MemberDashboard' && currentMember) {
      return (
         <ToastContext.Provider value={{ addToast }}>
             <PrintContext.Provider value={{ isPrinting, handlePrint }}>
                <MemberPortal member={currentMember} onLogout={handleMemberLogout} />
                <ToastContainer notifications={toasts} onDismiss={removeToast} />
             </PrintContext.Provider>
          </ToastContext.Provider>
      );
  }

  if (viewMode === 'Public') {
      return (
          <ToastContext.Provider value={{ addToast }}>
            <PublicWebsite setViewMode={setViewMode} />
            <ToastContainer notifications={toasts} onDismiss={removeToast} />
          </ToastContext.Provider>
      )
  }
  
  // Admin View
  const pageTitle = currentPage;
  
  return (
    <ToastContext.Provider value={{ addToast }}>
     <PrintContext.Provider value={{ isPrinting, handlePrint }}>
      <div className="flex h-screen bg-background font-sans">
        {!isPrinting && <Sidebar activePage={currentPage} setActivePage={handleSetPage} setViewMode={setViewMode} />}
        <div className="flex-1 flex flex-col overflow-hidden">
          {!isPrinting && <Header pageTitle={pageTitle} onLogout={handleLogout} />}
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-4 md:p-8">
            {renderPage()}
          </main>
        </div>
      </div>
      <ToastContainer notifications={toasts} onDismiss={removeToast} />
     </PrintContext.Provider>
    </ToastContext.Provider>
  );
};

export default App;