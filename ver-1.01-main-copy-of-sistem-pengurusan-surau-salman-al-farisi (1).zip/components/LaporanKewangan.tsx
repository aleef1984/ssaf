import React, { useState, useMemo, useEffect } from 'react';
import { getTransactions, getSurauInfo } from '../services/dataService';
import { Transaction, SurauInfo } from '../types';
import DynamicLogo from './DynamicLogo';
import { DownloadIcon } from './icons';
import { useToast, usePrint } from '../App';
import Spinner from './Spinner';

// Helper to format date to 'YYYY-MM-DD'
const toISODateString = (date: Date) => date.toISOString().split('T')[0];

const LaporanKewangan: React.FC = () => {
    const [allTransactions, setAllTransactions] = useState<Transaction[]>([]);
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { addToast } = useToast();
    const { handlePrint } = usePrint();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [transactionsData, infoData] = await Promise.all([
                    getTransactions(),
                    getSurauInfo(),
                ]);
                setAllTransactions(transactionsData);
                setSurauInfo(infoData);
            } catch(err) {
                setError("Gagal memuatkan data laporan. Sila cuba lagi.");
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    
    const [startDate, setStartDate] = useState<string>(toISODateString(startOfMonth));
    const [endDate, setEndDate] = useState<string>(toISODateString(today));

    const setDateRange = (start: Date, end: Date) => {
        setStartDate(toISODateString(start));
        setEndDate(toISODateString(end));
    };
    
    const setThisWeek = () => {
        const end = new Date();
        const start = new Date();
        start.setDate(end.getDate() - end.getDay()); // Start of week (Sunday)
        setDateRange(start, end);
    };

    const setThisMonth = () => {
        const end = new Date();
        const start = new Date(end.getFullYear(), end.getMonth(), 1);
        setDateRange(start, end);
    };

    const setThisYear = () => {
        const end = new Date();
        const start = new Date(end.getFullYear(), 0, 1);
        setDateRange(start, end);
    };

    const { reportData, periodTransactions } = useMemo(() => {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);

        // --- Data for the selected period ---
        const filteredTransactions = allTransactions.filter(t => {
            const tDate = new Date(t.date);
            return tDate >= start && tDate <= end;
        });

        const periodIncome = filteredTransactions.filter(t => t.type === 'Derma').reduce((sum, t) => sum + t.amount, 0);
        const periodExpense = filteredTransactions.filter(t => t.type === 'Perbelanjaan').reduce((sum, t) => sum + t.amount, 0);
        const periodSurplus = periodIncome + periodExpense;

        const aggregateByCategory = (type: 'Derma' | 'Perbelanjaan') => {
            return filteredTransactions
                .filter(t => t.type === type)
                .reduce((acc, t) => {
                    const category = t.category || 'Tidak Dikategorikan';
                    acc[category] = (acc[category] || 0) + t.amount;
                    return acc;
                }, {} as Record<string, number>);
        };
        const incomeByCategory = aggregateByCategory('Derma');
        const expenseByCategory = aggregateByCategory('Perbelanjaan');
        
        // --- Data for Statement of Financial Position ---
        const allTransactionsUpToDate = allTransactions.filter(t => new Date(t.date) <= end);
        const closingBalance = allTransactionsUpToDate.reduce((sum, t) => sum + t.amount, 0);

        return {
            reportData: {
                periodIncome,
                periodExpense,
                periodSurplus,
                incomeByCategory,
                expenseByCategory,
                closingBalance,
            },
            periodTransactions: filteredTransactions,
        };

    }, [startDate, endDate, allTransactions]);
    
    const handleExport = () => {
        if (periodTransactions.length === 0) {
            addToast('Tiada data untuk dieksport bagi tempoh yang dipilih.', 'info');
            return;
        }

        const dataToExport = periodTransactions.map(t => ({
            ID_Transaksi: t.id,
            Tarikh: new Date(t.date).toLocaleDateString('ms-MY'),
            Keterangan: t.description,
            Jenis: t.type,
            Kategori: t.category || 'N/A',
            Penderma: t.payerName || 'N/A',
            Jumlah: t.amount,
        }));

        const headers = Object.keys(dataToExport[0]);
        const csvContent = [
            headers.join(','),
            ...dataToExport.map(row => headers.map(header => JSON.stringify(row[header as keyof typeof row])).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `laporan_kewangan_${startDate}_hingga_${endDate}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        addToast('Laporan sedang dimuat turun.', 'success');
    };

    const FilterButton: React.FC<{ label: string; onClick: () => void }> = ({ label, onClick }) => (
        <button onClick={onClick} className="px-3 py-1.5 text-sm text-gray-700 bg-white rounded-md border border-gray-300 hover:bg-gray-50 transition-colors">
            {label}
        </button>
    );
    
    if (isLoading) return <Spinner />;
    if (error || !surauInfo) return <div className="text-center p-10 text-red-600">{error || "Data penting tidak dapat dimuatkan."}</div>;

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-md print-hidden">
                <h2 className="text-xl font-bold text-dark mb-4">Penapis Laporan Kewangan</h2>
                <div className="flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-2">
                        <label className="text-sm font-medium">Dari:</label>
                        <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="p-2 border border-gray-300 rounded-md" />
                    </div>
                    <div className="flex items-center gap-2">
                        <label className="text-sm font-medium">Hingga:</label>
                        <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="p-2 border border-gray-300 rounded-md" />
                    </div>
                     <div className="flex items-center gap-2 border-l pl-4">
                        <FilterButton label="Minggu Ini" onClick={setThisWeek} />
                        <FilterButton label="Bulan Ini" onClick={setThisMonth} />
                        <FilterButton label="Tahun Ini" onClick={setThisYear} />
                    </div>
                    <div className="flex-grow text-right flex justify-end gap-2">
                         <button onClick={handleExport} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2">
                            <DownloadIcon className="w-5 h-5"/>
                            Eksport ke CSV
                         </button>
                         <button onClick={handlePrint} className="bg-primary text-white px-5 py-2 rounded-lg hover:bg-dark transition-colors">Cetak Laporan</button>
                    </div>
                </div>
            </div>

            <div id="report-content" className="bg-white p-8 rounded-xl shadow-md">
                 {/* Header */}
                 <div className="text-center mb-8 pb-4 border-b-2 border-dashed print-no-break">
                    <DynamicLogo className="w-20 h-20 text-primary mx-auto object-contain" />
                    <h1 className="text-3xl font-bold text-dark mt-2">{surauInfo.name}</h1>
                    <p className="text-gray-600">{surauInfo.address}</p>
                    <h2 className="text-2xl font-semibold text-gray-800 mt-6">Laporan Kewangan</h2>
                    <p className="text-sm text-gray-500">
                        Untuk Tempoh: {new Date(startDate).toLocaleDateString('ms-MY')} hingga {new Date(endDate).toLocaleDateString('ms-MY')}
                    </p>
                </div>

                {/* Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8 print-no-break">
                    <div className="bg-green-50 p-4 rounded-lg text-center border-l-4 border-green-500">
                        <p className="text-sm font-medium text-green-700">Jumlah Pendapatan</p>
                        <p className="text-2xl font-bold text-green-800">RM {reportData.periodIncome.toFixed(2)}</p>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg text-center border-l-4 border-red-500">
                        <p className="text-sm font-medium text-red-700">Jumlah Perbelanjaan</p>
                        <p className="text-2xl font-bold text-red-800">RM {Math.abs(reportData.periodExpense).toFixed(2)}</p>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg text-center border-l-4 border-blue-500">
                        <p className="text-sm font-medium text-blue-700">Lebihan / (Kurangan)</p>
                        <p className={`text-2xl font-bold ${reportData.periodSurplus >= 0 ? 'text-blue-800' : 'text-red-800'}`}>RM {reportData.periodSurplus.toFixed(2)}</p>
                    </div>
                </div>

                <div className="space-y-8">
                    {/* Income and Expense Statement */}
                    <div className="print-no-break">
                        <h3 className="text-xl font-bold text-dark mb-4 border-b-2 pb-2">Penyata Pendapatan & Perbelanjaan</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                           <div>
                                <h4 className="font-semibold text-lg text-green-700 mb-2">Pendapatan</h4>
                                <table className="w-full text-sm"><tbody>
                                    {Object.entries(reportData.incomeByCategory).map(([cat, total]) => (
                                        <tr key={cat} className="border-b"><td className="py-2 pr-2">{cat}</td><td className="py-2 text-right font-medium">{total.toFixed(2)}</td></tr>
                                    ))}
                                    <tr className="border-t-2 border-gray-400 font-bold"><td className="py-2">Jumlah Pendapatan</td><td className="py-2 text-right">{reportData.periodIncome.toFixed(2)}</td></tr>
                                </tbody></table>
                           </div>
                           <div>
                                <h4 className="font-semibold text-lg text-red-700 mb-2">Perbelanjaan</h4>
                                <table className="w-full text-sm"><tbody>
                                    {Object.entries(reportData.expenseByCategory).map(([cat, total]) => (
                                        <tr key={cat} className="border-b"><td className="py-2 pr-2">{cat}</td><td className="py-2 text-right font-medium">({Math.abs(total).toFixed(2)})</td></tr>
                                    ))}
                                    <tr className="border-t-2 border-gray-400 font-bold"><td className="py-2">Jumlah Perbelanjaan</td><td className="py-2 text-right">({Math.abs(reportData.periodExpense).toFixed(2)})</td></tr>
                                </tbody></table>
                           </div>
                        </div>
                        <div className="mt-4 text-right font-bold text-lg border-t-4 border-double pt-2">
                            <span>Lebihan / (Kurangan) Pendapatan: </span>
                            <span className={reportData.periodSurplus >= 0 ? 'text-primary' : 'text-red-600'}>RM {reportData.periodSurplus.toFixed(2)}</span>
                        </div>
                    </div>
                    
                    {/* Other Statements */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 print-no-break">
                         {/* Statement of Financial Position */}
                        <div>
                            <h3 className="text-xl font-bold text-dark mb-4 border-b-2 pb-2">Penyata Kedudukan Kewangan</h3>
                            <table className="w-full text-sm">
                                <thead>
                                    <tr><th className="py-2 text-left font-semibold">Aset</th><th className="py-2 text-right font-semibold">Jumlah (RM)</th></tr>
                                </thead>
                                <tbody>
                                    <tr className="border-b"><td className="py-2 pr-2">Dana Terkumpul / Baki di Bank</td><td className="py-2 text-right font-medium">{reportData.closingBalance.toFixed(2)}</td></tr>
                                    <tr className="border-t-2 border-gray-400 font-bold"><td className="py-2">Jumlah Aset</td><td className="py-2 text-right">{reportData.closingBalance.toFixed(2)}</td></tr>
                                </tbody>
                            </table>
                        </div>

                         {/* Trial Balance */}
                        <div>
                             <h3 className="text-xl font-bold text-dark mb-4 border-b-2 pb-2">Imbangan Duga (Dipermudahkan)</h3>
                             <table className="w-full text-sm">
                                <thead>
                                    <tr>
                                        <th className="py-2 text-left font-semibold">Butiran</th>
                                        <th className="py-2 text-right font-semibold">Debit (RM)</th>
                                        <th className="py-2 text-right font-semibold">Kredit (RM)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr className="border-b"><td className="py-2 pr-2">Jumlah Perbelanjaan</td><td className="py-2 text-right font-medium">{Math.abs(reportData.periodExpense).toFixed(2)}</td><td className="py-2 text-right"></td></tr>
                                    <tr className="border-b"><td className="py-2 pr-2">Jumlah Pendapatan</td><td className="py-2 text-right"></td><td className="py-2 text-right font-medium">{reportData.periodIncome.toFixed(2)}</td></tr>
                                    {reportData.periodSurplus < 0 && <tr className="border-b"><td className="py-2 pr-2 italic">Akaun Kurangan</td><td className="py-2 text-right"></td><td className="py-2 text-right font-medium">{Math.abs(reportData.periodSurplus).toFixed(2)}</td></tr>}
                                    {reportData.periodSurplus > 0 && <tr className="border-b"><td className="py-2 pr-2 italic">Akaun Lebihan</td><td className="py-2 text-right font-medium">{reportData.periodSurplus.toFixed(2)}</td><td className="py-2 text-right"></td></tr>}
                                </tbody>
                                <tfoot className="border-t-2 border-gray-400 font-bold">
                                    <tr>
                                        <td className="py-2">Jumlah</td>
                                        <td className="py-2 text-right">{Math.max(reportData.periodIncome, Math.abs(reportData.periodExpense)).toFixed(2)}</td>
                                        <td className="py-2 text-right">{Math.max(reportData.periodIncome, Math.abs(reportData.periodExpense)).toFixed(2)}</td>
                                    </tr>
                                </tfoot>
                             </table>
                        </div>
                    </div>
                </div>

                <div className="text-center text-xs text-gray-500 mt-10 print-no-break">
                    <p>*** Laporan ini dijana secara automatik oleh Sistem Pengurusan Surau Salman Al-Farisi dan sah tanpa tandatangan. ***</p>
                </div>
            </div>
        </div>
    );
};

export default LaporanKewangan;