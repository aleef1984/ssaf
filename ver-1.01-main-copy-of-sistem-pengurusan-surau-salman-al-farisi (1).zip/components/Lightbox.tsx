import React, { useState, useEffect } from 'react';
import { Photo } from '../types';
import { CloseIcon, ArrowLeftIcon, ArrowRightIcon } from './icons';

interface LightboxProps {
    photos: Photo[];
    startIndex: number;
    onClose: () => void;
}

const Lightbox: React.FC<LightboxProps> = ({ photos, startIndex, onClose }) => {
    const [currentIndex, setCurrentIndex] = useState(startIndex);

    const goToPrevious = () => setCurrentIndex(prev => (prev > 0 ? prev - 1 : photos.length - 1));
    const goToNext = () => setCurrentIndex(prev => (prev < photos.length - 1 ? prev + 1 : 0));

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'ArrowLeft') goToPrevious();
            if (e.key === 'ArrowRight') goToNext();
            if (e.key === 'Escape') onClose();
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [goToPrevious, goToNext, onClose]);

    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[60] animate-fade-in" onClick={onClose}>
            <button onClick={onClose} className="absolute top-4 right-4 text-white p-2 bg-black/50 rounded-full hover:bg-black/70 print-hidden"><CloseIcon className="w-8 h-8" /></button>
            <button onClick={(e) => { e.stopPropagation(); goToPrevious(); }} className="absolute left-4 text-white p-3 bg-black/50 rounded-full hover:bg-black/70 print-hidden"><ArrowLeftIcon className="w-8 h-8" /></button>
            <button onClick={(e) => { e.stopPropagation(); goToNext(); }} className="absolute right-4 text-white p-3 bg-black/50 rounded-full hover:bg-black/70 print-hidden"><ArrowRightIcon className="w-8 h-8" /></button>
            
            <div className="relative" onClick={e => e.stopPropagation()}>
                <img src={photos[currentIndex].url} alt={photos[currentIndex].caption || `Photo ${currentIndex + 1}`} className="max-h-[85vh] max-w-[90vw] object-contain rounded-lg" />
                {photos[currentIndex].caption && <p className="text-center text-white mt-2 p-2 bg-black/50 rounded-b-lg">{photos[currentIndex].caption}</p>}
            </div>
        </div>
    );
};

export default Lightbox;
