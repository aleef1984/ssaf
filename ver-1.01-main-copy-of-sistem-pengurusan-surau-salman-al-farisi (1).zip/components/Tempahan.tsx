import React, { useState, useEffect, useRef } from 'react';
import { Facility, Booking } from '../types';
import { getFacilities, saveFacilities, getBookings, saveBookings } from '../services/dataService';
import { CloseIcon, PencilIcon, TrashIcon, PlusIcon, ImageIcon, KeyIcon, CheckIcon } from './icons';
import { useToast } from '../App';
import Spinner from './Spinner';

// Reusable Confirmation Modal
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan" }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{title}</h2></div>
            <div className="p-6"><p className="text-gray-700">{message}</p></div>
            <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Padam</button>
            </div>
        </div>
    </div>
);

// Facility Form Modal
const FacilityFormModal: React.FC<{
    onClose: () => void;
    onSave: (facilityData: Omit<Facility, 'id'>) => void;
    facilityToEdit: Facility | null;
}> = ({ onClose, onSave, facilityToEdit }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [rentalRate, setRentalRate] = useState<number | ''>('');
    const [imageUrl, setImageUrl] = useState<string | undefined>();
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (facilityToEdit) {
            setName(facilityToEdit.name);
            setDescription(facilityToEdit.description);
            setRentalRate(facilityToEdit.rentalRate);
            setImageUrl(facilityToEdit.imageUrl);
        }
    }, [facilityToEdit]);

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 512 * 1024) { // 512KB limit
                addToast("Saiz gambar tidak boleh melebihi 512KB.", "error"); return;
            }
            const reader = new FileReader();
            reader.onloadend = () => setImageUrl(reader.result as string);
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !description || rentalRate === '') {
            addToast('Sila isi semua medan yang diperlukan.', 'error'); return;
        }
        onSave({ name, description, rentalRate: Number(rentalRate), imageUrl });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <form onSubmit={handleSubmit} className="flex flex-col h-full">
                    <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{facilityToEdit ? 'Kemaskini Fasiliti' : 'Tambah Fasiliti Baru'}</h2></div>
                    <div className="p-6 overflow-y-auto space-y-4">
                        <div className="flex items-center space-x-6">
                            <div className="w-24 h-24 rounded-lg bg-gray-100 flex items-center justify-center overflow-hidden border">
                                {imageUrl ? <img src={imageUrl} className="w-full h-full object-cover" /> : <KeyIcon className="w-12 h-12 text-gray-400" />}
                            </div>
                            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageUpload} className="hidden"/>
                            <button type="button" onClick={() => fileInputRef.current?.click()} className="bg-secondary text-white px-4 py-2 rounded-lg text-sm hover:bg-yellow-800">Tukar Gambar</button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><label>Nama Fasiliti*</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" required /></div>
                            <div><label>Kadar Sewaan (RM/jam)*</label><input type="number" step="1" value={rentalRate} onChange={e => setRentalRate(e.target.value === '' ? '' : parseFloat(e.target.value))} className="mt-1 block w-full p-2 border rounded-md" required /></div>
                        </div>
                        <div><label>Keterangan*</label><textarea value={description} onChange={e => setDescription(e.target.value)} rows={4} className="mt-1 block w-full p-2 border rounded-md" required /></div>
                    </div>
                    <div className="p-6 bg-gray-50 flex justify-end space-x-3 mt-auto">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">{facilityToEdit ? 'Simpan Perubahan' : 'Tambah Fasiliti'}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


// Main Component
const Tempahan: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'facilities' | 'bookings'>('bookings');
    const [facilities, setFacilities] = useState<Facility[]>([]);
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [facilityToEdit, setFacilityToEdit] = useState<Facility | null>(null);
    const [facilityToDelete, setFacilityToDelete] = useState<Facility | null>(null);
    
    const { addToast } = useToast();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [facilitiesData, bookingsData] = await Promise.all([getFacilities(), getBookings()]);
                setFacilities(facilitiesData);
                setBookings(bookingsData);
            } catch (err) {
                setError("Gagal memuatkan data tempahan.");
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleSaveFacility = async (facilityData: Omit<Facility, 'id'>) => {
        let updatedFacilities: Facility[];
        if (facilityToEdit) {
            updatedFacilities = facilities.map(f => f.id === facilityToEdit.id ? { ...facilityToEdit, ...facilityData } : f);
        } else {
            updatedFacilities = [{ id: Date.now(), ...facilityData }, ...facilities];
        }
        try {
            await saveFacilities(updatedFacilities);
            setFacilities(updatedFacilities);
            addToast(`Fasiliti "${facilityData.name}" telah disimpan.`);
        } catch (err) {
            addToast("Gagal menyimpan data fasiliti.", "error");
        } finally {
            setIsFormModalOpen(false);
        }
    };
    
    const handleConfirmDelete = async () => {
        if (!facilityToDelete) return;
        const updatedFacilities = facilities.filter(f => f.id !== facilityToDelete.id);
        try {
            await saveFacilities(updatedFacilities);
            setFacilities(updatedFacilities);
            addToast(`Fasiliti "${facilityToDelete.name}" telah dipadam.`);
        } catch (err) {
            addToast("Gagal memadam fasiliti.", "error");
        } finally {
            setFacilityToDelete(null);
        }
    };

    const handleBookingStatusChange = async (bookingId: number, newStatus: 'Diluluskan' | 'Ditolak') => {
        const updatedBookings = bookings.map(b => b.id === bookingId ? {...b, status: newStatus} : b);
        try {
            await saveBookings(updatedBookings);
            setBookings(updatedBookings);
            addToast(`Status tempahan telah dikemaskini kepada "${newStatus}".`);
        } catch (err) {
            addToast("Gagal mengemaskini status tempahan.", "error");
        }
    };

    const getStatusClass = (status: Booking['status']) => {
        switch (status) {
            case 'Diluluskan': return 'bg-green-100 text-green-800';
            case 'Menunggu Pengesahan': return 'bg-yellow-100 text-yellow-800';
            case 'Ditolak': return 'bg-red-100 text-red-800';
        }
    };

    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    const TabButton: React.FC<{ name: string; count: number; current: string; target: string; onClick: () => void }> = ({ name, count, current, target, onClick }) => (
         <button onClick={onClick} className={`whitespace-nowrap py-4 px-3 border-b-2 font-medium text-sm flex items-center gap-2 ${current === target ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
            {name}
            {count > 0 && <span className={`text-xs font-bold rounded-full px-2 py-0.5 ${current === target ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700'}`}>{count}</span>}
        </button>
    );

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-dark">Pengurusan Tempahan Fasiliti</h2>
                 {activeTab === 'facilities' && (
                    <button onClick={() => { setFacilityToEdit(null); setIsFormModalOpen(true); }} className="flex items-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">
                        <PlusIcon className="w-5 h-5 mr-2" /> Tambah Fasiliti
                    </button>
                 )}
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                 <div className="border-b border-gray-200 mb-6">
                    <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                        <TabButton name="Urus Tempahan" count={bookings.filter(b => b.status === 'Menunggu Pengesahan').length} current={activeTab} target="bookings" onClick={() => setActiveTab('bookings')} />
                        <TabButton name="Urus Fasiliti" count={facilities.length} current={activeTab} target="facilities" onClick={() => setActiveTab('facilities')} />
                    </nav>
                </div>

                {activeTab === 'bookings' && (
                    <div className="overflow-x-auto">
                         <table className="w-full text-sm text-left">
                            <thead className="bg-gray-100"><tr>
                                <th className="p-3">Fasiliti</th><th className="p-3">Pemohon</th><th className="p-3">Tarikh Tempahan</th>
                                <th className="p-3">Status</th><th className="p-3 text-center">Tindakan</th></tr></thead>
                            <tbody>
                                {bookings.sort((a, b) => new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime()).map(booking => (
                                    <tr key={booking.id} className="border-b hover:bg-gray-50">
                                        <td className="p-3 font-semibold text-dark">{booking.facilityName}</td>
                                        <td className="p-3"><div>{booking.userName}</div><div className="text-xs text-gray-500">{booking.userContact}</div></td>
                                        <td className="p-3">{new Date(booking.bookingDate).toLocaleString('ms-MY')}</td>
                                        <td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusClass(booking.status)}`}>{booking.status}</span></td>
                                        <td className="p-3">
                                             {booking.status === 'Menunggu Pengesahan' && (
                                                <div className="flex items-center justify-center space-x-2">
                                                    <button onClick={() => handleBookingStatusChange(booking.id, 'Diluluskan')} className="flex items-center gap-1 text-xs bg-green-500 text-white px-3 py-1 rounded-md hover:bg-green-600"><CheckIcon className="w-4 h-4"/>Luluskan</button>
                                                    <button onClick={() => handleBookingStatusChange(booking.id, 'Ditolak')} className="flex items-center gap-1 text-xs bg-red-600 text-white px-3 py-1 rounded-md hover:bg-red-700"><CloseIcon className="w-4 h-4"/>Tolak</button>
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                         </table>
                         {bookings.length === 0 && <div className="text-center py-10 text-gray-500"><p>Tiada permohonan tempahan.</p></div>}
                    </div>
                )}

                {activeTab === 'facilities' && (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {facilities.map(facility => (
                            <div key={facility.id} className="bg-white rounded-xl shadow-md border flex flex-col">
                                <img src={facility.imageUrl || 'https://via.placeholder.com/400x300'} alt={facility.name} className="w-full h-40 object-cover rounded-t-xl"/>
                                <div className="p-4 flex-grow flex flex-col">
                                    <h3 className="font-bold text-lg text-dark">{facility.name}</h3>
                                    <p className="text-secondary font-semibold">RM {facility.rentalRate.toFixed(2)} / jam</p>
                                    <p className="text-sm text-gray-600 mt-2 flex-grow">{facility.description}</p>
                                    <div className="flex items-center justify-end space-x-2 mt-4 pt-4 border-t">
                                        <button onClick={() => setFacilityToEdit(facility)} className="p-2 text-secondary hover:bg-yellow-100 rounded-full" title="Kemaskini"><PencilIcon className="w-5 h-5"/></button>
                                        <button onClick={() => setFacilityToDelete(facility)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="Padam"><TrashIcon className="w-5 h-5"/></button>
                                    </div>
                                </div>
                            </div>
                        ))}
                        {facilities.length === 0 && <div className="col-span-full text-center py-10 text-gray-500"><p>Tiada fasiliti direkodkan.</p></div>}
                    </div>
                )}
            </div>
             {isFormModalOpen && <FacilityFormModal onClose={() => setIsFormModalOpen(false)} onSave={handleSaveFacility} facilityToEdit={facilityToEdit} />}
             {facilityToDelete && <ConfirmationModal onClose={() => setFacilityToDelete(null)} onConfirm={handleConfirmDelete} message={`Anda pasti ingin memadam fasiliti "${facilityToDelete.name}"?`} />}
        </div>
    );
};

export default Tempahan;
