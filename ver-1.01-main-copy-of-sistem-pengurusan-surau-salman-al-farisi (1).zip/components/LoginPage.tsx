import React, { useState, useEffect } from 'react';
import DynamicLogo from './DynamicLogo';
import { useToast } from '../App';
import { ViewMode, AdminCredentials } from '../types';
import { getAdminCredentials } from '../services/dataService';
import Spinner from './Spinner';

interface LoginPageProps {
    onLogin: (success: boolean) => void;
    setViewMode: (mode: ViewMode) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin, setViewMode }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [credentials, setCredentials] = useState<AdminCredentials | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const { addToast } = useToast();

    useEffect(() => {
        getAdminCredentials().then(creds => {
            setCredentials(creds);
            setIsLoading(false);
        }).catch(() => {
            addToast("Gagal memuatkan data log masuk.", "error");
            setIsLoading(false);
        });
    }, []);

    const handleLoginAttempt = (e: React.FormEvent) => {
        e.preventDefault();
        if (!credentials) {
            addToast("Sistem belum sedia, sila cuba lagi.", "error");
            return;
        }

        if (email === credentials.username && password === credentials.password_plaintext) {
            addToast('Log masuk berjaya!', 'success');
            onLogin(true);
        } else {
            addToast('Emel atau kata laluan tidak sah.', 'error');
            onLogin(false);
        }
    };
    
    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100 font-sans">
            <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-lg animate-fade-in">
                <div className="text-center">
                    <DynamicLogo className="w-20 h-20 mx-auto text-primary" />
                    <h2 className="mt-6 text-3xl font-extrabold text-dark">
                        Log Masuk Panel Admin
                    </h2>
                    <p className="mt-2 text-sm text-gray-600">
                        Sistem Pengurusan Surau Salman Al-Farisi
                    </p>
                </div>
                {isLoading ? <Spinner /> : (
                    <form className="mt-8 space-y-6" onSubmit={handleLoginAttempt}>
                        <div className="rounded-md shadow-sm -space-y-px">
                            <div>
                                <label htmlFor="email-address" className="sr-only">Alamat Emel</label>
                                <input
                                    id="email-address"
                                    name="email"
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                    className="appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                                    placeholder="Alamat Emel"
                                />
                            </div>
                            <div>
                                <label htmlFor="password" className="sr-only">Kata Laluan</label>
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    className="appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                                    placeholder="Kata Laluan"
                                />
                            </div>
                        </div>

                        <div>
                            <button
                                type="submit"
                                className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-hover"
                            >
                                Log Masuk
                            </button>
                        </div>
                    </form>
                )}
                <div className="text-center">
                    <button 
                        onClick={() => setViewMode('Public')}
                        className="font-medium text-sm text-primary hover:text-primary-hover"
                    >
                        &larr; Kembali ke Laman Web Awam
                    </button>
                </div>
                 <div className="text-center text-xs text-gray-500 p-3 bg-yellow-50 rounded-md border border-yellow-200">
                    <p>Untuk tujuan demo, kata laluan asal ialah: <strong>password123</strong></p>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;