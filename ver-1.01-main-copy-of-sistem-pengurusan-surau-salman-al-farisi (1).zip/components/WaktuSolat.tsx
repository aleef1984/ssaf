import React, { useState, useEffect } from 'react';
import { PrayerData, PrayerTime } from '../types';
import Spinner from './Spinner';
import { ClockIcon, CalendarIcon } from './icons';

const PRAYER_NAMES: { [key in keyof Omit<PrayerTime, 'hijri'|'date'>]: string } = {
    imsak: 'Imsak',
    subuh: 'Subuh',
    syuruk: 'Syuruk',
    zohor: 'Zohor',
    asar: 'Asar',
    maghrib: 'Maghrib',
    isyak: 'Isyak',
};

// A more robust date parser for DD-Mon-YYYY format that is more cross-browser compatible.
const parseJakimDate = (dateStr: string): Date | null => {
    // Replacing hyphens with spaces (e.g., "06-Jul-2024" -> "06 Jul 2024") 
    // is a more widely supported format for the Date constructor.
    const formattedDateStr = dateStr.replace(/-/g, ' ');
    const date = new Date(formattedDateStr);
    
    // Check if the parsed date is valid
    if (isNaN(date.getTime())) {
        return null; // Return null if date is invalid
    }
    return date;
};

// Helper function to convert 24-hour time string to 12-hour AM/PM format
const formatTo12Hour = (timeStr: string): string => {
    if (!timeStr || !timeStr.includes(':')) {
        return '-:--';
    }
    const [hours, minutes] = timeStr.split(':').map(Number);
    if (isNaN(hours) || isNaN(minutes)) {
        return '-:--';
    }
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const hours12 = hours % 12 || 12; // Convert 0 to 12 for midnight
    return `${hours12}:${String(minutes).padStart(2, '0')} ${ampm}`;
};

const formatHijriDate = (hijriStr: string): string => {
    if (!hijriStr || !/^\d{4}-\d{2}-\d{2}$/.test(hijriStr)) {
        return hijriStr; // Return original string if format is invalid
    }

    const [year, month, day] = hijriStr.split('-').map(Number);

    const hijriMonths = [
        'Muharram', 'Safar', 'Rabiulawal', 'Rabiulakhir',
        'Jamadilawal', 'Jamadilakhir', 'Rejab', 'Syaaban',
        'Ramadan', 'Syawal', 'Zulkaedah', 'Zulhijah'
    ];

    if (month < 1 || month > 12) {
        return hijriStr; // Invalid month
    }

    const monthName = hijriMonths[month - 1];

    return `${day} ${monthName} ${year}H`;
};


const WaktuSolat: React.FC = () => {
    const [prayerData, setPrayerData] = useState<PrayerData | null>(null);
    const [nextPrayer, setNextPrayer] = useState<{ name: string; time: string } | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchPrayerTimes = async () => {
            try {
                const today = new Date();
                const year = today.getFullYear();
                const month = today.getMonth() + 1; // JS months are 0-indexed
                const day = today.getDate().toString().padStart(2, '0');

                // New monthly API endpoint
                const response = await fetch(`https://api.waktusolat.app/solat/PHG02?year=${year}&month=${month}`);
                if (!response.ok) {
                    throw new Error(`Gagal menghubungi server WaktuSolat: ${response.statusText}`);
                }
                
                // Define the structure of the new monthly API response
                interface NewApiPrayerTime {
                    hijri: string;
                    date: string;
                    day: string;
                    imsak: string;
                    fajr: string;   // Note the different key from JAKIM API
                    syuruk: string;
                    dhuhr: string;  // Note the different key
                    asr: string;    // Note the different key
                    maghrib: string;
                    isha: string;   // Note the different key
                }

                interface WaktuSolatMonthlyResponse {
                    prayerTime: NewApiPrayerTime[];
                    status: string;
                    zone: string;
                }

                const data: WaktuSolatMonthlyResponse = await response.json();
                
                if (!data || !data.zone || !Array.isArray(data.prayerTime) || data.prayerTime.length === 0) {
                    throw new Error('Respon tidak sah atau data waktu solat tidak lengkap dari API.');
                }

                // Find today's prayer times from the monthly list
                // Date format from new API is "DD-Mon-YYYY"
                const todayDateString = `${day}-${today.toLocaleString('en-GB', { month: 'short' })}-${year}`;
                const todayRawPrayerInfo = data.prayerTime.find(p => p.date === todayDateString);

                if (!todayRawPrayerInfo) {
                    throw new Error("Tidak dapat mencari waktu solat untuk hari ini dalam data bulanan.");
                }

                // Map the new API fields to the existing PrayerTime interface used by the app
                const todayPrayerInfo: PrayerTime = {
                    hijri: todayRawPrayerInfo.hijri,
                    date: todayRawPrayerInfo.date,
                    imsak: todayRawPrayerInfo.imsak,
                    subuh: todayRawPrayerInfo.fajr,     // Map 'fajr' to 'subuh'
                    syuruk: todayRawPrayerInfo.syuruk,
                    zohor: todayRawPrayerInfo.dhuhr,    // Map 'dhuhr' to 'zohor'
                    asar: todayRawPrayerInfo.asr,       // Map 'asr' to 'asar'
                    maghrib: todayRawPrayerInfo.maghrib,
                    isyak: todayRawPrayerInfo.isha,     // Map 'isha' to 'isyak'
                };

                // Fallback for Imsak: if imsak is missing or invalid, calculate it from Subuh.
                // Regex now accepts HH:MM or HH:MM:SS
                const isValidTime = (time: string) => time && /^\d{2}:\d{2}(:\d{2})?$/.test(time);
                if (!isValidTime(todayPrayerInfo.imsak) && isValidTime(todayPrayerInfo.subuh)) {
                    const [hours, minutes] = todayPrayerInfo.subuh.split(':').map(Number);
                    const subuhDate = new Date();
                    subuhDate.setHours(hours, minutes, 0, 0);
                    
                    const imsakDate = new Date(subuhDate.getTime() - 10 * 60 * 1000); // Subtract 10 minutes
                    
                    const imsakHours = String(imsakDate.getHours()).padStart(2, '0');
                    const imsakMinutes = String(imsakDate.getMinutes()).padStart(2, '0');
                    
                    todayPrayerInfo.imsak = `${imsakHours}:${imsakMinutes}`;
                }

                // The component expects the data in the PrayerData structure with an array
                const transformedData: PrayerData = {
                    prayerTime: [todayPrayerInfo],
                    status: data.status,
                    zone: data.zone,
                };
                
                setPrayerData(transformedData);
            } catch (e) {
                console.error("Error fetching prayer times:", e);
                setError("Gagal memuatkan waktu solat. Sila cuba lagi sebentar lagi.");
            } finally {
                setIsLoading(false);
            }
        };

        fetchPrayerTimes();
    }, []);
    
    useEffect(() => {
        if (!prayerData?.prayerTime[0]) return;

        const calculateNextPrayer = () => {
            const now = new Date();
            const todayPrayerTimes = prayerData.prayerTime[0];

            // Only consider actual prayers for highlighting, not Imsak or Syuruk
            const PRAYER_ORDER: (keyof typeof PRAYER_NAMES)[] = ['subuh', 'zohor', 'asar', 'maghrib', 'isyak'];

            for (const prayerKey of PRAYER_ORDER) {
                const timeStr = todayPrayerTimes[prayerKey];

                if (timeStr && typeof timeStr === 'string') {
                    const timeParts = timeStr.split(':');
                    if (timeParts.length >= 2) { // Allow for seconds
                        const [hours, minutes] = timeParts.map(Number);
                        const prayerDateTime = new Date();
                        prayerDateTime.setHours(hours, minutes, 0, 0);

                        if (prayerDateTime > now) {
                            setNextPrayer({ name: PRAYER_NAMES[prayerKey], time: timeStr });
                            return;
                        }
                    }
                }
            }
             // If loop completes, all prayers for today are done. Clear highlight.
            setNextPrayer(null);
        };

        calculateNextPrayer();
        const interval = setInterval(calculateNextPrayer, 15000); // Check every 15 seconds

        return () => clearInterval(interval);
    }, [prayerData]);

    const renderContent = () => {
        if (isLoading) {
            return <div className="flex justify-center items-center h-48"><Spinner /></div>;
        }
        if (error || !prayerData?.prayerTime[0]) {
            return <div className="text-center text-red-600 p-4">{error || "Data waktu solat tidak tersedia."}</div>;
        }

        const todayTimes = prayerData.prayerTime[0];
        const todayDate = todayTimes.date ? parseJakimDate(todayTimes.date) : null;
        const hijriYear = todayTimes.hijri.split('-')[0];

        return (
            <>
                <div className="text-center mb-4">
                    <h3 className="font-bold text-lg text-dark">Waktu Solat Hari Ini</h3>
                    <p className="text-sm text-gray-500">Kuantan (PHG02)</p>
                     <p className="text-sm font-semibold text-primary mt-1">
                        {todayDate ? todayDate.toLocaleDateString('ms-MY', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'}) : todayTimes.date}
                        <br/>
                        {formatHijriDate(todayTimes.hijri)}
                    </p>
                </div>
                <ul className="text-sm space-y-1">
                    {Object.entries(PRAYER_NAMES).map(([key, name]) => {
                        const time = todayTimes[key as keyof typeof PRAYER_NAMES];
                        const isNext = nextPrayer?.name === name || (nextPrayer?.name === 'Subuh' && name === 'Imsak');
                        return (
                             <li key={key} className={`flex justify-between items-center capitalize p-2 rounded-md transition-colors ${isNext ? 'bg-primary/10' : ''}`}>
                                <span className={`font-semibold ${isNext ? 'text-primary' : ''}`}>{name}</span>
                                <span className={`font-bold text-lg ${isNext ? 'text-primary' : 'text-dark'}`}>{formatTo12Hour(time)}</span>
                            </li>
                        );
                    })}
                </ul>
                <div className="mt-4 pt-4 border-t">
                     <h4 className="font-semibold text-dark text-center mb-2">Tarikh Penting Islam {hijriYear}H</h4>
                      <ul className="text-xs space-y-1 text-gray-600">
                        <li className="flex justify-between"><span>Awal Muharram</span> <span>27 Jun 2025</span></li>
                        <li className="flex justify-between"><span>Maulidur Rasul</span> <span>5 Sep 2025</span></li>
                        <li className="flex justify-between"><span>Israk & Mikraj</span> <span>16 Jan 2026</span></li>
                        <li className="flex justify-between"><span>Awal Ramadan</span> <span>20 Feb 2026</span></li>
                      </ul>
                </div>
            </>
        );
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-lg">
            {renderContent()}
        </div>
    );
};

export default WaktuSolat;