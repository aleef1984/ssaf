import React, { useState, useEffect } from 'react';
import { Announcement, Album, Photo, SurauInfo, ActivityPlan } from '../types';
import { getAnnouncements, saveAnnouncements, getSurauInfo, getAlbums, saveAlbums } from '../services/dataService';
import { generateAnnouncement, generateActivityPlan } from '../services/geminiService';
import { SparklesIcon, CloseIcon, ShareIcon, CopyIcon, TrashIcon, ImageIcon, PlusIcon, ClipboardListIcon, CheckIcon, DollarSignIcon, CalendarIcon } from './icons';
import { useToast } from '../App';
import Lightbox from './Lightbox';
import DynamicLogo from './DynamicLogo';
import Spinner from './Spinner';

type ActiveTab = 'announcements' | 'gallery';

// --- Reusable Confirmation Modal ---
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
    confirmText?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan", confirmText = "Padam" }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md animate-fade-in">
                <div className="p-6 border-b">
                    <h2 className="text-xl font-bold text-dark">{title}</h2>
                </div>
                <div className="p-6">
                    <p className="text-gray-700">{message}</p>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors">Batal</button>
                    <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">{confirmText}</button>
                </div>
            </div>
        </div>
    );
};

// --- ANNOUNCEMENT COMPONENTS ---

const InvitationModal: React.FC<{
    onClose: () => void;
    announcement: Announcement;
    surauInfo: SurauInfo;
}> = ({ onClose, announcement, surauInfo }) => {
    const { addToast } = useToast();
    const shareUrl = window.location.href; 

    const handleCopyLink = () => {
        navigator.clipboard.writeText(shareUrl).then(() => addToast("Pautan jemputan telah disalin!"), () => addToast("Gagal menyalin pautan.", "error"));
    };

    const handleShare = async () => {
        try {
            await navigator.share({ title: `Jemputan ke ${announcement.title}`, text: `${announcement.content}\n\nAnjuran: ${surauInfo.name}`, url: shareUrl });
        } catch (err) { console.error("Error sharing:", err); }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg animate-fade-in">
                <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-dark">E-Jemputan</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-red-500"><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-6">
                    <div className="bg-light p-8 rounded-lg border-2 border-primary border-dashed text-center">
                        <DynamicLogo className="w-16 h-16 text-primary mx-auto mb-4 object-contain" />
                        <p className="text-sm font-semibold text-gray-600">JEMPUTAN KE</p>
                        <h3 className="text-2xl font-bold text-dark my-2">{announcement.title}</h3>
                        <p className="text-sm text-gray-500 mb-4">{new Date(announcement.date).toLocaleDateString('ms-MY', { dateStyle: 'full' })}</p>
                        <p className="text-gray-700 whitespace-pre-wrap">{announcement.content}</p>
                        <p className="text-xs text-gray-500 mt-6">Anjuran: {surauInfo.name}</p>
                    </div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-center rounded-b-lg border-t space-x-3">
                    <button onClick={handleCopyLink} className="flex items-center bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">
                        <CopyIcon className="w-5 h-5 mr-2" /> Salin Pautan
                    </button>
                    {navigator.share && (
                        <button onClick={handleShare} className="flex items-center bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                            <ShareIcon className="w-5 h-5 mr-2" /> Kongsi
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

const AnnouncementCard: React.FC<{ announcement: Announcement, onInviteClick: () => void, onDeleteClick: () => void }> = ({ announcement, onInviteClick, onDeleteClick }) => (
    <div className="bg-white rounded-xl shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 flex flex-col">
        {announcement.imageUrl && <img className="w-full h-40 object-cover" src={announcement.imageUrl} alt={announcement.title} />}
        <div className="p-6 flex-grow flex flex-col">
            <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-bold text-dark flex-1 pr-2">{announcement.title}</h3>
                <button onClick={onDeleteClick} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-100 rounded-full" title="Padam Pengumuman">
                    <TrashIcon className="w-5 h-5"/>
                </button>
            </div>
            <p className="text-gray-600 text-sm mb-4 flex-grow">{announcement.content}</p>
            <div className="flex justify-between items-center mt-auto">
                <p className="text-xs text-gray-500">Diterbitkan pada: {new Date(announcement.date).toLocaleDateString('ms-MY')}</p>
                <button onClick={onInviteClick} className="bg-primary text-white px-3 py-1 rounded-md text-sm hover:bg-dark">E-Jemputan</button>
            </div>
        </div>
    </div>
);

const AIGeneratorModal: React.FC<{ 
    onClose: () => void;
    onAddAnnouncement: (title: string, content: string) => void;
}> = ({ onClose, onAddAnnouncement }) => {
    const { addToast } = useToast();
    const [topic, setTopic] = useState('');
    const [title, setTitle] = useState('');
    const [generatedContent, setGeneratedContent] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleGenerate = async () => {
        if (!topic.trim()) {
            addToast("Sila masukkan topik.", "error");
            return;
        }
        setIsLoading(true);
        const content = await generateAnnouncement(topic);
        setGeneratedContent(content);
        setIsLoading(false);
        addToast("Kandungan berjaya dijana.", "success");
    };

    const handleSave = () => {
        if (!title.trim() || !generatedContent.trim()) {
            addToast("Sila isi tajuk dan jana kandungan.", "error");
            return;
        }
        onAddAnnouncement(title, generatedContent);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl animate-fade-in">
                <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-dark flex items-center">
                        <SparklesIcon className="w-6 h-6 mr-2 text-secondary" /> Jana Teks Pengumuman (AI)
                    </h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-red-500"><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-6 space-y-4">
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Tajuk Pengumuman (cth: Kuliah Maghrib Khas)" className="w-full p-2 border border-gray-300 rounded-md" />
                    <input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Topik untuk AI (cth: Kuliah maghrib oleh Ustaz Azhar Idrus)" className="w-full p-2 border border-gray-300 rounded-md" />
                    <button onClick={handleGenerate} disabled={isLoading || !topic.trim()} className="w-full flex justify-center items-center bg-secondary text-white px-4 py-2 rounded-lg hover:bg-yellow-800 disabled:bg-gray-400">
                        {isLoading ? 'Menjana...' : 'Jana Kandungan'}
                    </button>
                    <textarea value={generatedContent} onChange={(e) => setGeneratedContent(e.target.value)} rows={6} className="w-full p-2 border border-gray-300 rounded-md bg-gray-50" placeholder="Kandungan akan dipaparkan di sini..."></textarea>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end space-x-3 rounded-b-lg">
                    <button onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">Batal</button>
                    <button onClick={handleSave} disabled={!title.trim() || !generatedContent.trim()} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark disabled:bg-gray-400">Tambah Pengumuman</button>
                </div>
            </div>
        </div>
    );
};

// --- PHOTO GALLERY COMPONENTS ---
const AlbumFormModal: React.FC<{ onClose: () => void; onSave: (albumData: Omit<Album, 'id'>) => void; }> = ({ onClose, onSave }) => {
    const { addToast } = useToast();
    const [title, setTitle] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [photos, setPhotos] = useState<Photo[]>([]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const files = Array.from(e.target.files);
            files.forEach(file => {
                const reader = new FileReader();
                reader.onloadend = () => {
                    const newPhoto: Photo = { id: `local-${Date.now()}-${Math.random()}`, url: reader.result as string };
                    setPhotos(prev => [...prev, newPhoto]);
                };
                reader.readAsDataURL(file);
            });
        }
    };
    
    const handleRemovePhoto = (id: string) => setPhotos(prev => prev.filter(p => p.id !== id));

    const handleSubmit = () => {
        if (!title.trim() || photos.length === 0) {
            addToast("Sila masukkan tajuk dan muat naik sekurang-kurangnya satu gambar.", "error");
            return;
        }
        const newAlbum: Omit<Album, 'id'> = { title, date, photos, coverImageUrl: photos[0].url };
        onSave(newAlbum);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col animate-fade-in">
                <div className="p-6 border-b flex justify-between items-center"><h2 className="text-xl font-bold text-dark">Tambah Album Baru</h2><button onClick={onClose}><CloseIcon/></button></div>
                <div className="p-6 overflow-y-auto space-y-4">
                    <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Tajuk Album" className="w-full p-2 border rounded"/>
                    <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full p-2 border rounded"/>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Gambar</label>
                        <div className="mt-2 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
                            {photos.map(p => (
                                <div key={p.id} className="relative group">
                                    <img src={p.url} className="w-full h-24 object-cover rounded-md"/>
                                    <button onClick={() => handleRemovePhoto(p.id)} className="absolute top-0 right-0 m-1 bg-red-600/80 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"><CloseIcon className="w-3 h-3"/></button>
                                </div>
                            ))}
                            <label className="w-full h-24 flex items-center justify-center border-2 border-dashed rounded-md cursor-pointer hover:bg-gray-100">
                                <PlusIcon className="w-8 h-8 text-gray-400"/>
                                <input type="file" multiple accept="image/*" onChange={handleFileChange} className="hidden"/>
                            </label>
                        </div>
                    </div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end space-x-3 mt-auto"><button onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">Batal</button><button onClick={handleSubmit} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Simpan Album</button></div>
            </div>
        </div>
    );
}

// --- AI PLANNER MODAL ---
const AIPlannerModal: React.FC<{
    onClose: () => void;
    onAddAnnouncement: (title: string, content: string) => void;
}> = ({ onClose, onAddAnnouncement }) => {
    const { addToast } = useToast();
    const [idea, setIdea] = useState('');
    const [plan, setPlan] = useState<ActivityPlan | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleGeneratePlan = async () => {
        if (!idea.trim()) {
            addToast("Sila masukkan idea aktiviti anda.", "error");
            return;
        }
        setIsLoading(true);
        setPlan(null);
        const result = await generateActivityPlan(idea);
        setIsLoading(false);
        if (typeof result === 'string') {
            addToast(result, 'error');
        } else {
            setPlan(result);
            addToast("Pelan aktiviti berjaya dijana!", "success");
        }
    };
    
    const handleSaveDraft = () => {
        if (plan) {
            onAddAnnouncement(plan.announcementTitle, plan.announcementContent);
            onClose();
        }
    };
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl h-[95vh] flex flex-col animate-fade-in">
                <div className="p-6 border-b flex justify-between items-center flex-shrink-0">
                    <h2 className="text-xl font-bold text-dark flex items-center">
                        <ClipboardListIcon className="w-6 h-6 mr-3 text-primary" /> Perancang Aktiviti (AI)
                    </h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-red-500"><CloseIcon className="w-6 h-6" /></button>
                </div>
                
                <div className="flex-grow flex overflow-hidden">
                    {/* Input Panel */}
                    <div className="w-1/3 border-r p-6 space-y-4 overflow-y-auto bg-gray-50">
                        <h3 className="font-semibold text-lg text-dark">1. Masukkan Idea Anda</h3>
                        <p className="text-sm text-gray-600">Terangkan secara ringkas aktiviti yang ingin anda rancang. AI akan membantu anda menyusun butirannya.</p>
                        <textarea 
                            value={idea}
                            onChange={(e) => setIdea(e.target.value)}
                            rows={8}
                            className="w-full p-2 border border-gray-300 rounded-md shadow-sm"
                            placeholder="Contoh: Saya nak anjurkan majlis gotong-royong perdana untuk membersihkan kawasan surau bulan depan."
                        />
                        <button onClick={handleGeneratePlan} disabled={isLoading || !idea.trim()} className="w-full flex justify-center items-center bg-primary text-white px-4 py-3 rounded-lg hover:bg-dark disabled:bg-gray-400 transition-colors">
                            {isLoading ? <Spinner /> : <><SparklesIcon className="w-5 h-5 mr-2" /> Jana Pelan</>}
                        </button>
                    </div>

                    {/* Output Panel */}
                    <div className="w-2/3 p-6 space-y-6 overflow-y-auto">
                        <h3 className="font-semibold text-lg text-dark">2. Hasil Perancangan</h3>
                        {isLoading && <div className="text-center py-10"><Spinner /></div>}
                        {!isLoading && !plan && <div className="text-center py-10 text-gray-500">Pelan tindakan akan dipaparkan di sini.</div>}
                        {plan && (
                            <div className="space-y-6 animate-fade-in">
                                <div>
                                    <h4 className="font-bold text-primary text-lg mb-2">Draf Pengumuman</h4>
                                    <div className="p-4 bg-light rounded-lg border">
                                        <h5 className="font-bold">{plan.announcementTitle}</h5>
                                        <p className="text-sm mt-1 whitespace-pre-wrap">{plan.announcementContent}</p>
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <h4 className="font-bold text-primary text-lg mb-2">Senarai Semak (Checklist)</h4>
                                        <ul className="space-y-2">
                                            {plan.checklist.map((item, i) => (
                                                <li key={i} className="flex items-start text-sm"><CheckIcon className="w-4 h-4 mr-2 mt-0.5 text-green-600 flex-shrink-0"/>{item}</li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-primary text-lg mb-2">Anggaran Belanjawan</h4>
                                        <ul className="space-y-2">
                                            {plan.budgetEstimate.map((item, i) => (
                                                <li key={i} className="flex justify-between text-sm"><DollarSignIcon className="w-4 h-4 mr-2 mt-0.5 text-yellow-600 flex-shrink-0"/><span>{item.item}</span> <span className="font-medium">RM{item.cost.toFixed(2)}</span></li>
                                            ))}
                                        </ul>
                                    </div>
                                </div>
                                <div>
                                    <h4 className="font-bold text-primary text-lg mb-2">Cadangan Aturcara Majlis</h4>
                                    <ul className="space-y-2">
                                        {plan.schedule.map((item, i) => (
                                            <li key={i} className="flex items-start text-sm"><CalendarIcon className="w-4 h-4 mr-2 mt-0.5 text-blue-600 flex-shrink-0"/><span className="font-semibold w-24">{item.time}</span> <span>{item.activity}</span></li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                <div className="p-6 bg-gray-50 flex justify-end space-x-3 border-t flex-shrink-0">
                    <button onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 transition-colors">Tutup</button>
                    <button onClick={handleSaveDraft} disabled={!plan} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 disabled:bg-gray-400 transition-colors">
                        Simpan Draf Pengumuman
                    </button>
                </div>
            </div>
        </div>
    );
};


// --- MAIN COMPONENT ---
const Aktiviti: React.FC = () => {
    const { addToast } = useToast();
    const [activeTab, setActiveTab] = useState<ActiveTab>('announcements');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    // Data state
    const [announcements, setAnnouncements] = useState<Announcement[]>([]);
    const [albums, setAlbums] = useState<Album[]>([]);
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);

    // Modal & Action state
    const [isAIGenModalOpen, setIsAIGenModalOpen] = useState(false);
    const [isPlannerModalOpen, setIsPlannerModalOpen] = useState(false);
    const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
    const [isAnnounceDeleteConfirmOpen, setAnnounceDeleteConfirmOpen] = useState(false);
    const [deletingAnnounceId, setDeletingAnnounceId] = useState<number | null>(null);
    const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
    const [isAlbumFormOpen, setIsAlbumFormOpen] = useState(false);
    const [isAlbumDeleteConfirmOpen, setIsAlbumDeleteConfirmOpen] = useState(false);
    const [deletingAlbumId, setDeletingAlbumId] = useState<number | null>(null);
    const [lightboxOpen, setLightboxOpen] = useState<{ photos: Photo[], startIndex: number } | null>(null);

    const fetchData = async () => {
        try {
            setIsLoading(true);
            const [announcementsData, albumsData, infoData] = await Promise.all([
                getAnnouncements(),
                getAlbums(),
                getSurauInfo()
            ]);
            setAnnouncements(announcementsData);
            setAlbums(albumsData);
            setSurauInfo(infoData);
        } catch(err) {
            setError("Gagal memuatkan data. Sila cuba lagi.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    // Handlers for Announcements
    const handleAddAnnouncement = async (title: string, content: string) => {
        const newAnn: Announcement = { id: Date.now(), title, content, date: new Date().toISOString(), imageUrl: `https://picsum.photos/400/200?random=${Date.now()}`};
        const updated = [newAnn, ...announcements];
        try {
            await saveAnnouncements(updated);
            setAnnouncements(updated);
            addToast("Pengumuman baru telah ditambah.");
        } catch (err) {
            addToast("Gagal menyimpan pengumuman.", "error");
        } finally {
            setIsAIGenModalOpen(false);
        }
    };
    const handleDeleteAnnounceClick = (id: number) => { setDeletingAnnounceId(id); setAnnounceDeleteConfirmOpen(true); };
    const handleConfirmDeleteAnnounce = async () => {
        if (!deletingAnnounceId) return;
        const updated = announcements.filter(a => a.id !== deletingAnnounceId);
        try {
            await saveAnnouncements(updated);
            setAnnouncements(updated);
            addToast("Pengumuman telah dipadam.");
        } catch(err) {
            addToast("Gagal memadam pengumuman.", "error");
        } finally {
            setAnnounceDeleteConfirmOpen(false);
        }
    };
    const handleInviteClick = (ann: Announcement) => { setSelectedAnnouncement(ann); setIsInviteModalOpen(true); };

    // Handlers for Gallery
    const handleSaveAlbum = async (albumData: Omit<Album, 'id'>) => {
        const newAlbum: Album = { id: Date.now(), ...albumData };
        const updated = [newAlbum, ...albums];
        try {
            await saveAlbums(updated);
            setAlbums(updated);
            addToast(`Album "${newAlbum.title}" telah dicipta.`);
        } catch(err) {
            addToast("Gagal menyimpan album.", "error");
        } finally {
            setIsAlbumFormOpen(false);
        }
    };
    const handleDeleteAlbumClick = (id: number) => { setDeletingAlbumId(id); setIsAlbumDeleteConfirmOpen(true); };
    const handleConfirmDeleteAlbum = async () => {
        if (!deletingAlbumId) return;
        const updated = albums.filter(a => a.id !== deletingAlbumId);
        try {
            await saveAlbums(updated);
            setAlbums(updated);
            addToast("Album telah dipadam.");
        } catch (err) {
            addToast("Gagal memadam album.", "error");
        } finally {
            setIsAlbumDeleteConfirmOpen(false);
        }
    };

    if (isLoading) return <Spinner />;
    if (error || !surauInfo) return <div className="text-center p-10 text-red-600">{error || "Data penting tidak dapat dimuatkan."}</div>;

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-2xl font-bold text-dark">Aktiviti & Galeri</h2>
                {activeTab === 'announcements' ? (
                     <div className="flex flex-col sm:flex-row gap-2">
                        <button onClick={() => setIsAIGenModalOpen(true)} className="flex items-center justify-center bg-secondary text-white px-4 py-2 rounded-lg hover:bg-yellow-800 transition-colors">
                            <SparklesIcon className="w-5 h-5 mr-2" /> Buat Teks Pengumuman
                        </button>
                        <button onClick={() => setIsPlannerModalOpen(true)} className="flex items-center justify-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark transition-colors">
                            <ClipboardListIcon className="w-5 h-5 mr-2" /> Rancang Aktiviti Penuh (AI)
                        </button>
                    </div>
                ) : (
                    <button onClick={() => setIsAlbumFormOpen(true)} className="flex items-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">
                        <PlusIcon className="w-5 h-5 mr-2" /> Tambah Album Baru
                    </button>
                )}
            </div>
            
            {/* Tab Navigation */}
            <div className="border-b border-gray-200">
                <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                    <button onClick={() => setActiveTab('announcements')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'announcements' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                        Pengumuman
                    </button>
                    <button onClick={() => setActiveTab('gallery')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'gallery' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                        Galeri Foto
                    </button>
                </nav>
            </div>
            
            {/* Conditional Content */}
            {activeTab === 'announcements' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-fade-in">
                    {announcements.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(ann => (
                        <AnnouncementCard key={ann.id} announcement={ann} onInviteClick={() => handleInviteClick(ann)} onDeleteClick={() => handleDeleteAnnounceClick(ann.id)}/>
                    ))}
                    {announcements.length === 0 && <p className="col-span-full text-center text-gray-500 py-10">Tiada pengumuman.</p>}
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 animate-fade-in">
                    {albums.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(album => (
                        <div key={album.id} className="group relative rounded-xl overflow-hidden shadow-md cursor-pointer" onClick={() => setLightboxOpen({ photos: album.photos, startIndex: 0 })}>
                            <img src={album.coverImageUrl} alt={album.title} className="w-full h-48 object-cover transform group-hover:scale-110 transition-transform duration-300"/>
                            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                            <div className="absolute bottom-0 left-0 p-4 text-white">
                                <h3 className="font-bold text-lg">{album.title}</h3>
                                <p className="text-xs">{new Date(album.date).toLocaleDateString('ms-MY')}</p>
                            </div>
                            <button onClick={(e) => { e.stopPropagation(); handleDeleteAlbumClick(album.id); }} className="absolute top-2 right-2 bg-red-600/80 text-white rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4"/></button>
                        </div>
                    ))}
                    {albums.length === 0 && <p className="col-span-full text-center text-gray-500 py-10">Tiada album foto.</p>}
                </div>
            )}

            {/* Modals */}
            {isAIGenModalOpen && <AIGeneratorModal onClose={() => setIsAIGenModalOpen(false)} onAddAnnouncement={handleAddAnnouncement} />}
            {isPlannerModalOpen && <AIPlannerModal onClose={() => setIsPlannerModalOpen(false)} onAddAnnouncement={handleAddAnnouncement} />}
            {isInviteModalOpen && selectedAnnouncement && <InvitationModal onClose={() => setIsInviteModalOpen(false)} announcement={selectedAnnouncement} surauInfo={surauInfo} />}
            {isAnnounceDeleteConfirmOpen && <ConfirmationModal title="Padam Pengumuman" message="Anda pasti ingin memadam pengumuman ini?" onClose={() => setAnnounceDeleteConfirmOpen(false)} onConfirm={handleConfirmDeleteAnnounce} />}
            {isAlbumFormOpen && <AlbumFormModal onClose={() => setIsAlbumFormOpen(false)} onSave={handleSaveAlbum} />}
            {isAlbumDeleteConfirmOpen && <ConfirmationModal title="Padam Album" message="Anda pasti ingin memadam album ini dan semua gambarnya?" onClose={() => setIsAlbumDeleteConfirmOpen(false)} onConfirm={handleConfirmDeleteAlbum} />}
            {lightboxOpen && <Lightbox photos={lightboxOpen.photos} startIndex={lightboxOpen.startIndex} onClose={() => setLightboxOpen(null)} />}
        </div>
    );
};

export default Aktiviti;