import React, { useState, useEffect } from 'react';
import { getSurauInfo } from '../services/dataService';
import { SurauLogoIcon } from './icons';

interface DynamicLogoProps {
    className?: string;
}

const DynamicLogo: React.FC<DynamicLogoProps> = ({ className }) => {
    const [logoUrl, setLogoUrl] = useState<string | undefined>();

    useEffect(() => {
        const handleLogoUpdate = () => {
            getSurauInfo().then(info => {
                setLogoUrl(info.logoUrl);
            }).catch(err => {
                console.error("Failed to get surau info for logo:", err);
            });
        };

        handleLogoUpdate(); // Initial call

        window.addEventListener('logoUpdated', handleLogoUpdate);
        
        const storageHandler = (e: StorageEvent) => {
            if (e.key === 'surau_info') {
                handleLogoUpdate();
            }
        };
        window.addEventListener('storage', storageHandler);

        return () => {
            window.removeEventListener('logoUpdated', handleLogoUpdate);
            window.removeEventListener('storage', storageHandler);
        };
    }, []);

    if (logoUrl) {
        return <img src={logoUrl} alt="Surau Logo" className={className} />;
    }

    return <SurauLogoIcon className={className} />;
};

export default DynamicLogo;