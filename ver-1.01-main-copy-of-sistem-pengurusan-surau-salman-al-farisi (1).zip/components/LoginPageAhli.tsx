import React, { useState } from 'react';
import DynamicLogo from './DynamicLogo';
import { useToast } from '../App';
import { ViewMode, Member } from '../types';
import { loginMember } from '../services/dataService';

interface LoginPageAhliProps {
    onLogin: (member: Member) => void;
    setViewMode: (mode: ViewMode) => void;
}

const LoginPageAhli: React.FC<LoginPageAhliProps> = ({ onLogin, setViewMode }) => {
    const [icNumber, setIcNumber] = useState('');
    const [password, setPassword] = useState('');
    const { addToast } = useToast();
    const [isLoggingIn, setIsLoggingIn] = useState(false);

    const handleLoginAttempt = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoggingIn(true);
        try {
            // Using a mock password for all members for this demo
            const member = await loginMember(icNumber, 'password123');
            if (member) {
                addToast(`Selamat datang, ${member.name}!`, 'success');
                onLogin(member);
            } else {
                addToast('No. Kad Pengenalan tidak ditemui atau tidak sah.', 'error');
            }
        } catch (error) {
            const errorMessage = (error instanceof Error) ? error.message : "Ralat tidak dijangka semasa log masuk.";
            addToast(errorMessage, 'error');
        } finally {
            setIsLoggingIn(false);
        }
    };
    
    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100 font-sans">
            <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-2xl shadow-lg animate-fade-in">
                <div className="text-center">
                    <DynamicLogo className="w-20 h-20 mx-auto text-primary" />
                    <h2 className="mt-6 text-3xl font-extrabold text-dark">
                        Log Masuk Portal Ahli
                    </h2>
                    <p className="mt-2 text-sm text-gray-600">
                        Sistem Pengurusan Surau Salman Al-Farisi
                    </p>
                </div>
                <form className="mt-8 space-y-6" onSubmit={handleLoginAttempt}>
                    <div className="rounded-md shadow-sm -space-y-px">
                        <div>
                            <label htmlFor="ic-number" className="sr-only">No. Kad Pengenalan</label>
                            <input
                                id="ic-number"
                                name="ic"
                                type="text"
                                value={icNumber}
                                onChange={(e) => setIcNumber(e.target.value)}
                                required
                                className="appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                                placeholder="No. Kad Pengenalan (cth: 800101061234)"
                            />
                        </div>
                        <div>
                            <label htmlFor="password" className="sr-only">Kata Laluan</label>
                            <input
                                id="password"
                                name="password"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                className="appearance-none rounded-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-primary focus:border-primary focus:z-10 sm:text-sm"
                                placeholder="Kata Laluan"
                            />
                        </div>
                    </div>

                    <div>
                        <button
                            type="submit"
                            disabled={isLoggingIn}
                            className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-hover disabled:bg-gray-400"
                        >
                            {isLoggingIn ? 'Memproses...' : 'Log Masuk'}
                        </button>
                    </div>
                </form>
                <div className="text-center">
                    <button 
                        onClick={() => setViewMode('Public')}
                        className="font-medium text-sm text-primary hover:text-primary-hover"
                    >
                        &larr; Kembali ke Laman Web Awam
                    </button>
                </div>
                 <div className="text-center text-xs text-gray-500 p-3 bg-yellow-50 rounded-md border border-yellow-200">
                    <p>Untuk tujuan demo, sila gunakan No. K/P ahli sedia ada (cth: <strong>800101-06-1234</strong>) dan kata laluan: <strong>password123</strong></p>
                </div>
            </div>
        </div>
    );
};

export default LoginPageAhli;
