import React, { useState, useEffect } from 'react';
import { getSchedule, saveSchedule, getDutyPersonnel } from '../services/dataService';
import { Duty, DutyPersonnel } from '../types';
import { CloseIcon, WhatsAppIcon } from './icons';
import { useToast } from '../App';
import Spinner from './Spinner';

// Modal for editing schedule
const EditScheduleModal: React.FC<{
    onClose: () => void;
    onSave: (newImam: string, newBilal: string) => void;
    slotData: { imam: string, bilal: string };
    slotInfo: string;
    personnel: DutyPersonnel;
}> = ({ onClose, onSave, slotData, slotInfo, personnel }) => {
    const [imam, setImam] = useState(slotData.imam);
    const [bilal, setBilal] = useState(slotData.bilal);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(imam, bilal);
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 border-b flex justify-between items-center">
                        <div>
                            <h2 className="text-xl font-bold text-dark">Kemaskini Jadual</h2>
                            <p className="text-sm text-gray-500">{slotInfo}</p>
                        </div>
                        <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Nama Imam</label>
                            <select
                                value={imam}
                                onChange={(e) => setImam(e.target.value)}
                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                                required
                            >
                                <option value="" disabled>Pilih Imam</option>
                                {personnel.imams.map(name => <option key={name} value={name}>{name}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Nama Bilal</label>
                             <select
                                value={bilal}
                                onChange={(e) => setBilal(e.target.value)}
                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                                required
                            >
                                <option value="" disabled>Pilih Bilal</option>
                                {personnel.bilals.map(name => <option key={name} value={name}>{name}</option>)}
                            </select>
                        </div>
                    </div>
                    <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const Jadual: React.FC = () => {
    const [schedule, setSchedule] = useState<Duty[]>([]);
    const [personnel, setPersonnel] = useState<DutyPersonnel | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingSlot, setEditingSlot] = useState<{ day: Duty['day'], waktu: keyof Omit<Duty, 'day'>} | null>(null);
    const { addToast } = useToast();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [scheduleData, personnelData] = await Promise.all([
                    getSchedule(),
                    getDutyPersonnel(),
                ]);
                setSchedule(scheduleData);
                setPersonnel(personnelData);
            } catch (err) {
                setError("Gagal memuatkan data jadual.");
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const prayerTimes = ['subuh', 'zohor', 'asar', 'maghrib', 'isyak'] as const;

    const handleCellClick = (day: Duty['day'], waktu: keyof Omit<Duty, 'day'>) => {
        setEditingSlot({ day, waktu });
        setIsEditModalOpen(true);
    };

    const handleSaveChanges = async (newImam: string, newBilal: string) => {
        if (!editingSlot) return;
        
        const updatedSchedule = schedule.map(dayDuty => {
            if (dayDuty.day === editingSlot.day) {
                const newDayDuty = { ...dayDuty };
                newDayDuty[editingSlot.waktu] = { imam: newImam, bilal: newBilal };
                return newDayDuty;
            }
            return dayDuty;
        });
        
        try {
            await saveSchedule(updatedSchedule);
            setSchedule(updatedSchedule);
            addToast(`Jadual untuk ${editingSlot.day} waktu ${editingSlot.waktu} telah dikemaskini.`);
        } catch (err) {
            addToast("Gagal menyimpan perubahan jadual.", "error");
        } finally {
            setIsEditModalOpen(false);
            setEditingSlot(null);
        }
    };

    const formatScheduleForWhatsApp = (): string => {
        let message = "Assalamualaikum, berikut adalah Jadual Bertugas Mingguan Surau Salman Al-Farisi:\n\n";
        schedule.forEach(dayDuty => {
            message += `*${dayDuty.day.toUpperCase()}*\n`;
            prayerTimes.forEach(waktu => {
                message += ` - *${waktu}:* ${dayDuty[waktu].imam} (Imam), ${dayDuty[waktu].bilal} (Bilal)\n`;
            });
            message += "\n";
        });
        message += "Harap maklum dan terima kasih.";
        return encodeURIComponent(message);
    };

    const handleSendWhatsApp = () => {
        const message = formatScheduleForWhatsApp();
        const url = `https://wa.me/?text=${message}`;
        window.open(url, '_blank');
        addToast("Sila pilih penerima di WhatsApp.", "info");
    };

    const ChangeRequestModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
        const handleSubmitRequest = (e: React.FormEvent) => {
            e.preventDefault();
            addToast('Permohonan pertukaran jadual telah dihantar untuk pengesahan.');
            onClose();
        };

        return (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
                <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                    <div className="p-6 border-b flex justify-between items-center">
                        <h2 className="text-xl font-bold text-dark">Borang Pertukaran Jadual</h2>
                        <button onClick={onClose} className="text-gray-500 hover:text-red-500">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <form className="p-6 space-y-4" onSubmit={handleSubmitRequest}>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Nama Pemohon</label>
                            <input type="text" className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Tarikh & Waktu Asal</label>
                            <input type="datetime-local" className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Nama Pengganti</label>
                            <input type="text" className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Sebab Pertukaran</label>
                            <textarea className="mt-1 block w-full p-2 border border-gray-300 rounded-md" rows={3}></textarea>
                        </div>
                        <div className="pt-4 flex justify-end space-x-3">
                            <button type="button" onClick={onClose} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">Batal</button>
                            <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Hantar Permohonan</button>
                        </div>
                    </form>
                </div>
            </div>
        );
    };

    if (isLoading) return <Spinner />;
    if (error || !personnel) return <div className="text-center p-10 text-red-600">{error || "Data penting tidak dapat dimuatkan."}</div>;

    const currentSlotData = editingSlot ? schedule.find(d => d.day === editingSlot.day)?.[editingSlot.waktu] : null;

    return (
        <div className="space-y-8">
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold text-dark">Jadual Bertugas Mingguan</h2>
                    <div className="space-x-2">
                        <button 
                            onClick={() => setIsRequestModalOpen(true)}
                            className="bg-secondary text-white px-4 py-2 rounded-lg hover:bg-yellow-800 transition-colors">
                            Mohon Tukar Jadual
                        </button>
                         <button 
                            onClick={handleSendWhatsApp}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2">
                            <WhatsAppIcon className="w-5 h-5"/>
                            <span>Hantar Notifikasi</span>
                        </button>
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-gray-200">
                        <thead className="bg-primary text-white">
                            <tr>
                                <th className="p-3 border border-emerald-300">Waktu Solat</th>
                                {schedule.map(item => <th key={item.day} className="p-3 border border-emerald-300">{item.day}</th>)}
                            </tr>
                        </thead>
                        <tbody className="text-center text-sm">
                            {prayerTimes.map(waktu => (
                                <tr key={waktu} className="odd:bg-white even:bg-green-50">
                                    <td className="font-semibold p-3 border border-gray-200 capitalize text-primary">{waktu}</td>
                                    {schedule.map(dayDuty => (
                                        <td key={`${dayDuty.day}-${waktu}`} className="p-0 border border-gray-200">
                                            <div 
                                                onClick={() => handleCellClick(dayDuty.day, waktu)}
                                                className="cursor-pointer h-full w-full p-3 hover:bg-yellow-100 transition-colors"
                                            >
                                                <p className="font-medium text-dark">{dayDuty[waktu].imam}</p>
                                                <p className="text-xs text-gray-500">{dayDuty[waktu].bilal} (Bilal)</p>
                                            </div>
                                        </td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {isRequestModalOpen && <ChangeRequestModal onClose={() => setIsRequestModalOpen(false)} />}
            {isEditModalOpen && currentSlotData && editingSlot && (
                <EditScheduleModal
                    onClose={() => setIsEditModalOpen(false)}
                    onSave={handleSaveChanges}
                    slotData={currentSlotData}
                    slotInfo={`${editingSlot.day}, Waktu ${editingSlot.waktu.charAt(0).toUpperCase() + editingSlot.waktu.slice(1)}`}
                    personnel={personnel}
                />
            )}
        </div>
    );
};

export default Jadual;