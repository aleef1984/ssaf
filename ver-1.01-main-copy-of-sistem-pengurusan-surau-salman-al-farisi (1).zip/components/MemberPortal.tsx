import React, { useState, useMemo, useEffect } from 'react';
import { Member, SurauInfo, Transaction } from '../types';
import { getSurauInfo, getTransactions } from '../services/dataService';
import { usePrint } from '../App';
import { LogOutIcon, DashboardIcon, UsersIcon, DollarSignIcon, CloseIcon } from './icons';
import DynamicLogo from './DynamicLogo';
import Spinner from './Spinner';

type MemberPortalView = 'dashboard' | 'profile' | 'finance';

// Yearly Statement Modal for Member Portal
const YearlyStatementModal: React.FC<{
    onClose: () => void;
    member: Member;
    surauInfo: SurauInfo;
    transactions: Transaction[];
}> = ({ onClose, member, surauInfo, transactions }) => {
    const { handlePrint } = usePrint();
    const [year, setYear] = useState(new Date().getFullYear());
    
    const yearOptions = useMemo(() => {
        const currentYear = new Date().getFullYear();
        const years = [];
        for (let i = 0; i < 5; i++) {
            years.push(currentYear - i);
        }
        return years;
    }, []);

    const memberTransactions = useMemo(() => {
        return transactions.filter(t => 
            t.type === 'Derma' &&
            t.memberId === member.id && 
            new Date(t.date).getFullYear() === year
        );
    }, [year, member.id, transactions]);

    const totalDonation = useMemo(() => memberTransactions.reduce((sum, t) => sum + t.amount, 0), [memberTransactions]);
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4 print-hidden">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
                 <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-dark">Penyata Sumbangan Tahunan</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-red-500"><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-8 overflow-y-auto" id="statement-content">
                    <div className="text-center mb-8 pb-4 border-b-2 border-dashed">
                        <DynamicLogo className="w-16 h-16 text-primary mx-auto object-contain" />
                        <h1 className="text-2xl font-bold text-dark mt-2">{surauInfo.name}</h1>
                        <p className="text-sm text-gray-600">{surauInfo.address}</p>
                        <h2 className="text-xl font-semibold text-gray-800 mt-6">Penyata Sumbangan Tahunan</h2>
                    </div>
                    <div className="grid grid-cols-2 gap-8 mb-8">
                        <div>
                            <p className="text-sm text-gray-500">Kepada:</p>
                            <p className="font-bold text-dark">{member.name}</p>
                            <p className="text-gray-700">{member.icNumber}</p>
                            <p className="text-gray-700">{member.address}</p>
                        </div>
                        <div className="text-right">
                            <p className="text-sm text-gray-500">Tahun:</p>
                            <p className="font-bold text-2xl text-dark">{year}</p>
                            <select value={year} onChange={e => setYear(parseInt(e.target.value))} className="mt-1 p-1 border border-gray-300 rounded-md print-hidden">
                                {yearOptions.map(y => <option key={y} value={y}>{y}</option>)}
                            </select>
                        </div>
                    </div>
                    <table className="w-full text-sm">
                        <thead className="bg-gray-100"><tr><th className="px-4 py-2 text-left">Tarikh</th><th className="px-4 py-2 text-left">Keterangan</th><th className="px-4 py-2 text-right">Jumlah (RM)</th></tr></thead>
                        <tbody>
                            {memberTransactions.map(t => (<tr key={t.id} className="border-b"><td className="px-4 py-3">{new Date(t.date).toLocaleDateString('ms-MY')}</td><td className="px-4 py-3">{t.description}</td><td className="px-4 py-3 text-right font-medium text-green-700">{t.amount.toFixed(2)}</td></tr>))}
                            {memberTransactions.length === 0 && (<tr><td colSpan={3} className="text-center py-10 text-gray-500">Tiada rekod sumbangan untuk tahun {year}.</td></tr>)}
                        </tbody>
                        <tfoot><tr className="bg-gray-100 font-bold"><td colSpan={2} className="px-4 py-3 text-right">Jumlah Keseluruhan</td><td className="px-4 py-3 text-right text-lg text-primary">RM {totalDonation.toFixed(2)}</td></tr></tfoot>
                    </table>
                    <p className="text-center text-xs text-gray-500 mt-10">Ini adalah penyata janaan komputer untuk tujuan rujukan dan percukaian. Sah tanpa tandatangan.</p>
                </div>
                <div className="p-6 bg-gray-50 text-right rounded-b-lg border-t mt-auto">
                    <button onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 mr-2">Tutup</button>
                    <button onClick={handlePrint} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Cetak Penyata</button>
                </div>
            </div>
        </div>
    );
};

const MemberPortal: React.FC<{ member: Member; onLogout: () => void; }> = ({ member, onLogout }) => {
    const [view, setView] = useState<MemberPortalView>('dashboard');
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isStatementModalOpen, setIsStatementModalOpen] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [info, trans] = await Promise.all([getSurauInfo(), getTransactions()]);
                setSurauInfo(info);
                setTransactions(trans);
            } catch (err) {
                console.error("Failed to load member portal data", err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const renderContent = () => {
        if (isLoading || !surauInfo) return <Spinner />;

        const currentYear = new Date().getFullYear();
        const khairatPayment = member.khairatPayments.find(p => p.year === currentYear);
        const khairatStatus = khairatPayment?.status || 'Tertunggak';
        
        const totalContribution = transactions
            .filter(t => t.type === 'Derma' && t.memberId === member.id && new Date(t.date).getFullYear() === currentYear)
            .reduce((sum, t) => sum + t.amount, 0);

        switch (view) {
            case 'profile':
                return (
                    <div className="bg-white p-6 rounded-xl shadow-md space-y-6">
                        <h2 className="text-2xl font-bold text-dark border-b pb-2">Profil Saya</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><strong>Nama Penuh:</strong> {member.name}</div>
                            <div><strong>No. K/P:</strong> {member.icNumber}</div>
                            <div><strong>No. Telefon:</strong> {member.phone}</div>
                             <div><strong>Ahli Sejak:</strong> {new Date(member.joinDate).toLocaleDateString('ms-MY')}</div>
                            <div className="md:col-span-2"><strong>Alamat:</strong> {member.address}</div>
                        </div>
                        <div>
                            <h3 className="font-semibold text-lg text-primary mt-4">Tanggungan</h3>
                            <ul className="list-disc list-inside mt-2">
                                {member.dependents.map(d => <li key={d.id}>{d.name} ({d.relationship})</li>)}
                                {member.dependents.length === 0 && <p className="text-gray-500">Tiada tanggungan direkodkan.</p>}
                            </ul>
                        </div>
                        <p className="text-sm text-gray-500 pt-4 border-t">Sila hubungi AJK Surau jika terdapat sebarang perubahan pada maklumat anda.</p>
                    </div>
                );
            case 'finance':
                return (
                    <div className="bg-white p-6 rounded-xl shadow-md space-y-6">
                         <div className="flex justify-between items-center">
                            <h2 className="text-2xl font-bold text-dark">Kewangan Saya</h2>
                            <button onClick={() => setIsStatementModalOpen(true)} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Jana Penyata Tahunan</button>
                        </div>
                        <div>
                            <h3 className="font-semibold text-lg text-primary mb-2">Sejarah Bayaran Khairat Kematian</h3>
                            <table className="w-full text-sm">
                                <thead className="bg-gray-100"><tr><th className="p-2 text-left">Tahun</th><th className="p-2 text-left">Tarikh Bayaran</th><th className="p-2 text-left">Status</th></tr></thead>
                                <tbody>
                                    {member.khairatPayments.map(p => (
                                        <tr key={p.id} className="border-b"><td className="p-2">{p.year}</td><td className="p-2">{new Date(p.paymentDate).toLocaleDateString('ms-MY')}</td><td className="p-2"><span className={`px-2 py-1 rounded-full text-xs font-medium ${p.status === 'Lunas' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{p.status}</span></td></tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                         <div>
                            <h3 className="font-semibold text-lg text-primary mb-2">Sejarah Sumbangan</h3>
                             <table className="w-full text-sm">
                                <thead className="bg-gray-100"><tr><th className="p-2 text-left">Tarikh</th><th className="p-2 text-left">Keterangan</th><th className="p-2 text-right">Jumlah (RM)</th></tr></thead>
                                <tbody>
                                    {transactions.filter(t => t.memberId === member.id).map(t => (<tr key={t.id} className="border-b"><td className="p-2">{new Date(t.date).toLocaleDateString('ms-MY')}</td><td className="p-2">{t.description}</td><td className="p-2 text-right font-medium text-green-700">{t.amount.toFixed(2)}</td></tr>))}
                                </tbody>
                            </table>
                        </div>
                        {isStatementModalOpen && <YearlyStatementModal onClose={() => setIsStatementModalOpen(false)} member={member} surauInfo={surauInfo} transactions={transactions} />}
                    </div>
                );
            case 'dashboard':
            default:
                return (
                    <div className="space-y-8">
                        <h2 className="text-3xl font-bold text-dark">Selamat Datang, {member.name.split(' ')[0]}!</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className={`p-6 rounded-xl shadow-lg text-white ${khairatStatus === 'Lunas' ? 'bg-green-600' : 'bg-red-600'}`}>
                                <h3 className="text-lg font-semibold">Status Yuran Khairat {currentYear}</h3>
                                <p className="text-4xl font-bold">{khairatStatus}</p>
                                {khairatStatus === 'Tertunggak' && <p className="text-sm opacity-90 mt-2">Sila buat pembayaran di surau atau hubungi bendahari.</p>}
                            </div>
                            <div className="p-6 rounded-xl shadow-lg bg-blue-600 text-white">
                                <h3 className="text-lg font-semibold">Jumlah Sumbangan Anda ({currentYear})</h3>
                                <p className="text-4xl font-bold">RM {totalContribution.toFixed(2)}</p>
                                <p className="text-sm opacity-90 mt-2">Terima kasih atas kemurahan hati anda.</p>
                            </div>
                        </div>
                    </div>
                );
        }
    };
    
    const NavItem: React.FC<{ icon: React.ReactNode, label: string, current: string, target: MemberPortalView, onClick: () => void }> = ({ icon, label, current, target, onClick }) => (
         <button onClick={onClick} className={`flex items-center w-full p-3 rounded-lg text-left ${current === target ? 'bg-primary text-white' : 'hover:bg-primary/10'}`}>
             {icon} <span className="ml-3 font-semibold">{label}</span>
         </button>
    );

    return (
        <div className="flex h-screen bg-background font-sans">
             <div className="w-64 bg-white text-dark flex flex-col shadow-lg h-full print-hidden">
                <div className="flex items-center justify-center p-6 border-b border-gray-200">
                    <DynamicLogo className="w-12 h-12 text-primary object-contain" />
                    <div className="ml-3 text-left">
                        <h1 className="text-lg font-bold text-dark">Portal Ahli</h1>
                        <p className="text-xs text-gray-500">Surau Salman Al-Farisi</p>
                    </div>
                </div>
                <nav className="flex-1 p-4 space-y-2">
                    <NavItem icon={<DashboardIcon className="w-6 h-6"/>} label="Papan Pemuka" current={view} target="dashboard" onClick={() => setView('dashboard')}/>
                    <NavItem icon={<UsersIcon className="w-6 h-6"/>} label="Profil Saya" current={view} target="profile" onClick={() => setView('profile')}/>
                    <NavItem icon={<DollarSignIcon className="w-6 h-6"/>} label="Kewangan Saya" current={view} target="finance" onClick={() => setView('finance')}/>
                </nav>
                 <div className="p-4 border-t">
                     <button onClick={onLogout} className="w-full flex items-center justify-center p-3 text-gray-600 hover:text-red-600 hover:bg-red-100 rounded-lg border border-gray-200">
                         <LogOutIcon className="w-5 h-5 mr-2"/> Log Keluar
                     </button>
                </div>
             </div>
             <div className="flex-1 flex flex-col overflow-hidden">
                <header className="bg-white shadow-sm z-10 print-hidden">
                    <div className="flex items-center justify-between h-20 px-8">
                        <h1 className="text-2xl font-bold text-dark">Portal Ahli Kariah</h1>
                         <div className="flex items-center space-x-6">
                            <div className="text-right">
                                <p className="font-semibold text-gray-800">{member.name}</p>
                                <p className="text-xs text-gray-500">Ahli Kariah</p>
                            </div>
                            <img className="w-12 h-12 rounded-full ring-2 ring-offset-2 ring-primary" src={`https://i.pravatar.cc/100?u=${member.id}`} alt="User Avatar" />
                        </div>
                    </div>
                </header>
                 <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-4 md:p-8">
                    {renderContent()}
                 </main>
             </div>
        </div>
    );
};

export default MemberPortal;