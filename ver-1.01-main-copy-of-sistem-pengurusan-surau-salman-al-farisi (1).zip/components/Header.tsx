import React from 'react';
import { Page } from '../types';
import { LogOutIcon } from './icons';

interface HeaderProps {
  pageTitle: Page;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ pageTitle, onLogout }) => {
  return (
    <header className="bg-white shadow-sm z-10 print-hidden">
      <div className="flex items-center justify-between h-20 px-8">
        <h1 className="text-2xl font-bold text-dark">{pageTitle}</h1>
        <div className="flex items-center space-x-6">
            <div className="text-right">
              <p className="font-semibold text-gray-800">Admin</p>
              <p className="text-xs text-gray-500">Pengerusi Surau</p>
            </div>
            <img 
                className="w-12 h-12 rounded-full ring-2 ring-offset-2 ring-primary" 
                src="https://picsum.photos/100/100?random=user" 
                alt="User Avatar" 
            />
            <button
              onClick={onLogout}
              className="flex items-center text-gray-500 hover:text-red-600 transition-colors"
              title="Log Keluar"
            >
              <LogOutIcon className="w-6 h-6" />
            </button>
        </div>
      </div>
    </header>
  );
};

export default Header;