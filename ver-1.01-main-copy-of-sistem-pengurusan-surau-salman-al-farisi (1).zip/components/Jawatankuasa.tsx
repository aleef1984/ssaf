import React, { useState, useEffect, useRef } from 'react';
import { getCommittee, saveCommittee } from '../services/dataService';
import { CommitteeMember } from '../types';
import { CloseIcon, PencilIcon, TrashIcon, PlusIcon, ImageIcon } from './icons';
import { useToast } from '../App';
import Spinner from './Spinner';

// Confirmation Modal for destructive actions
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan" }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{title}</h2></div>
            <div className="p-6"><p className="text-gray-700">{message}</p></div>
            <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Padam</button>
            </div>
        </div>
    </div>
);

// Committee Member Form Modal
const CommitteeFormModal: React.FC<{
    onClose: () => void;
    onSave: (member: Omit<CommitteeMember, 'id'>) => void;
    memberToEdit: CommitteeMember | null;
}> = ({ onClose, onSave, memberToEdit }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [position, setPosition] = useState('');
    const [session, setSession] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [imageUrl, setImageUrl] = useState<string | undefined>();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const positions = ['Pengerusi', 'Timbalan Pengerusi', 'Setiausaha', 'Bendahari', 'AJK Muslimat', 'AJK Belia', 'AJK Kebersihan', 'AJK Teknikal', 'Pemeriksa Kira-kira'];

    useEffect(() => {
        if (memberToEdit) {
            setName(memberToEdit.name);
            setPosition(memberToEdit.position);
            setSession(memberToEdit.session);
            setPhone(memberToEdit.phone);
            setEmail(memberToEdit.email);
            setImageUrl(memberToEdit.imageUrl);
        }
    }, [memberToEdit]);

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 512 * 1024) { // 512KB limit
                addToast("Saiz gambar tidak boleh melebihi 512KB.", "error");
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => setImageUrl(reader.result as string);
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !position || !session) {
            addToast('Sila isi semua medan yang diperlukan (Nama, Jawatan, Sesi).', 'error');
            return;
        }
        onSave({ name, position, session, phone, email, imageUrl });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <form onSubmit={handleSubmit} className="flex flex-col h-full">
                    <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{memberToEdit ? 'Kemaskini AJK' : 'Tambah AJK Baru'}</h2></div>
                    <div className="p-6 overflow-y-auto space-y-4">
                        <div className="flex items-center space-x-6">
                            <div className="w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border">
                                {imageUrl ? <img src={imageUrl} className="w-full h-full object-cover" /> : <ImageIcon className="w-12 h-12 text-gray-400" />}
                            </div>
                            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageUpload} className="hidden"/>
                            <button type="button" onClick={() => fileInputRef.current?.click()} className="bg-secondary text-white px-4 py-2 rounded-lg text-sm hover:bg-yellow-800">Tukar Gambar</button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><label>Nama Penuh*</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" required /></div>
                            <div><label>Sesi Perkhidmatan*</label><input type="text" value={session} onChange={e => setSession(e.target.value)} placeholder="cth: 2024-2026" className="mt-1 block w-full p-2 border rounded-md" required /></div>
                            <div>
                                <label>Jawatan*</label>
                                <select value={position} onChange={e => setPosition(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" required>
                                    <option value="" disabled>Pilih Jawatan</option>
                                    {positions.sort().map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                             <div><label>No. Telefon</label><input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" /></div>
                             <div className="md:col-span-2"><label>Emel</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" /></div>
                        </div>
                    </div>
                    <div className="p-6 bg-gray-50 flex justify-end space-x-3 mt-auto">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">{memberToEdit ? 'Simpan Perubahan' : 'Tambah AJK'}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

// Main Component
const Jawatankuasa: React.FC = () => {
    const [committee, setCommittee] = useState<CommitteeMember[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [memberToEdit, setMemberToEdit] = useState<CommitteeMember | null>(null);
    const [memberToDelete, setMemberToDelete] = useState<CommitteeMember | null>(null);
    const { addToast } = useToast();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const data = await getCommittee();
                setCommittee(data);
            } catch (err) {
                setError("Gagal memuatkan data jawatankuasa.");
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleOpenAddModal = () => {
        setMemberToEdit(null);
        setIsFormModalOpen(true);
    };

    const handleOpenEditModal = (member: CommitteeMember) => {
        setMemberToEdit(member);
        setIsFormModalOpen(true);
    };

    const handleSave = async (data: Omit<CommitteeMember, 'id'>) => {
        let updatedCommittee: CommitteeMember[];
        let successMessage = "";
        if (memberToEdit) {
            updatedCommittee = committee.map(m => m.id === memberToEdit.id ? { ...memberToEdit, ...data } : m);
            successMessage = `Maklumat ${data.name} telah dikemaskini.`;
        } else {
            const newMember: CommitteeMember = { id: Date.now(), ...data };
            updatedCommittee = [newMember, ...committee];
            successMessage = `${data.name} telah ditambah sebagai AJK.`;
        }
        try {
            await saveCommittee(updatedCommittee);
            setCommittee(updatedCommittee);
            addToast(successMessage);
        } catch (err) {
            addToast("Gagal menyimpan data AJK.", "error");
        } finally {
            setIsFormModalOpen(false);
        }
    };

    const handleDelete = (member: CommitteeMember) => {
        setMemberToDelete(member);
    };

    const handleConfirmDelete = async () => {
        if (!memberToDelete) return;
        const updatedCommittee = committee.filter(m => m.id !== memberToDelete.id);
        try {
            await saveCommittee(updatedCommittee);
            setCommittee(updatedCommittee);
            addToast(`${memberToDelete.name} telah dipadam dari senarai AJK.`);
        } catch (err) {
            addToast("Gagal memadam data AJK.", "error");
        } finally {
            setMemberToDelete(null);
        }
    };
    
    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-dark">Pengurusan Jawatankuasa</h2>
                <button onClick={handleOpenAddModal} className="flex items-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">
                    <PlusIcon className="w-5 h-5 mr-2" /> Tambah AJK Baru
                </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {committee.map(member => (
                    <div key={member.id} className="bg-white rounded-xl shadow-md p-6 text-center flex flex-col items-center">
                        <img src={member.imageUrl || 'https://via.placeholder.com/100'} alt={member.name} className="w-24 h-24 rounded-full object-cover mb-4 ring-2 ring-offset-2 ring-primary"/>
                        <h3 className="text-lg font-bold text-dark">{member.name}</h3>
                        <p className="text-primary font-semibold">{member.position}</p>
                        <p className="text-sm text-gray-500 mb-4">Sesi: {member.session}</p>
                        <div className="flex items-center space-x-3 mt-auto pt-4 border-t w-full justify-center">
                            <button onClick={() => handleOpenEditModal(member)} className="flex items-center text-sm text-secondary hover:underline"><PencilIcon className="w-4 h-4 mr-1"/>Kemaskini</button>
                            <button onClick={() => handleDelete(member)} className="flex items-center text-sm text-red-600 hover:underline"><TrashIcon className="w-4 h-4 mr-1"/>Padam</button>
                        </div>
                    </div>
                ))}
            </div>

            {committee.length === 0 && (
                 <div className="text-center py-20 text-gray-500 bg-white rounded-xl shadow-md">
                    <p>Tiada ahli jawatankuasa yang telah direkodkan.</p>
                    <p>Klik "Tambah AJK Baru" untuk bermula.</p>
                </div>
            )}
            
            {isFormModalOpen && <CommitteeFormModal onClose={() => setIsFormModalOpen(false)} onSave={handleSave} memberToEdit={memberToEdit}/>}
            {memberToDelete && <ConfirmationModal onClose={() => setMemberToDelete(null)} onConfirm={handleConfirmDelete} message={`Anda pasti ingin memadam ${memberToDelete.name} dari senarai jawatankuasa?`}/>}
        </div>
    );
};

export default Jawatankuasa;
