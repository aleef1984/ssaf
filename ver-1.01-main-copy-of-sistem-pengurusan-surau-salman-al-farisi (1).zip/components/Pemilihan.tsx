import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useToast } from '../App';
import { getElectionSessions, saveElectionSessions, getNominations, saveNominations, getMembers, saveCommittee, getDutyPersonnel } from '../services/dataService';
import { ElectionSession, Nomination, Member, Candidate, Page, CommitteeMember, ContestedPosition } from '../types';
import { CloseIcon, PlusIcon, CheckIcon, TrashIcon, BriefcaseIcon, InfoIcon } from './icons';
import Spinner from './Spinner';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';


const toISODateString = (date: Date) => date.toISOString().split('T')[0];

const SessionFormModal: React.FC<{
    onClose: () => void;
    onSave: (session: Omit<ElectionSession, 'id' | 'status' | 'candidates' | 'votes'>) => void;
}> = ({ onClose, onSave }) => {
    const [title, setTitle] = useState('');
    const [nominationStartDate, setNominationStartDate] = useState(toISODateString(new Date()));
    const [nominationEndDate, setNominationEndDate] = useState(toISODateString(new Date()));
    const [votingStartDate, setVotingStartDate] = useState(toISODateString(new Date()));
    const [votingEndDate, setVotingEndDate] = useState(toISODateString(new Date()));
    const [positions, setPositions] = useState<ContestedPosition[]>([]);
    const { addToast } = useToast();

    const handleAddPosition = () => {
        setPositions([...positions, { position: '', vacancies: 1 }]);
    };
    
    const handlePositionChange = (index: number, field: 'position' | 'vacancies', value: string | number) => {
        const newPositions = [...positions];
        newPositions[index] = {...newPositions[index], [field]: value};
        setPositions(newPositions);
    };

    const handleRemovePosition = (index: number) => {
        setPositions(positions.filter((_, i) => i !== index));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!title || positions.length === 0 || positions.some(p => !p.position || p.vacancies < 1)) {
            addToast('Sila isi semua medan dengan betul, termasuk sekurang-kurangnya satu jawatan.', 'error');
            return;
        }
        onSave({ title, nominationStartDate, nominationEndDate, votingStartDate, votingEndDate, contestedPositions: positions });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col">
                <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">Cipta Sesi Pemilihan Baru</h2></div>
                <div className="p-6 space-y-4 overflow-y-auto">
                    <div><label>Tajuk Sesi</label><input type="text" value={title} onChange={e => setTitle(e.target.value)} className="w-full mt-1 p-2 border rounded" required/></div>
                    <div className="grid grid-cols-2 gap-4">
                        <div><label>Tarikh Mula Pencalonan</label><input type="date" value={nominationStartDate} onChange={e => setNominationStartDate(e.target.value)} className="w-full mt-1 p-2 border rounded" required/></div>
                        <div><label>Tarikh Tamat Pencalonan</label><input type="date" value={nominationEndDate} onChange={e => setNominationEndDate(e.target.value)} className="w-full mt-1 p-2 border rounded" required/></div>
                        <div><label>Tarikh Mula Pengundian</label><input type="date" value={votingStartDate} onChange={e => setVotingStartDate(e.target.value)} className="w-full mt-1 p-2 border rounded" required/></div>
                        <div><label>Tarikh Tamat Pengundian</label><input type="date" value={votingEndDate} onChange={e => setVotingEndDate(e.target.value)} className="w-full mt-1 p-2 border rounded" required/></div>
                    </div>
                     <div>
                        <h4 className="font-semibold mt-4 mb-2">Jawatan Yang Dipertandingkan</h4>
                        <div className="space-y-2">
                           {positions.map((pos, index) => (
                               <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                                   <input type="text" placeholder="Nama Jawatan" value={pos.position} onChange={e => handlePositionChange(index, 'position', e.target.value)} className="w-full p-2 border rounded" required/>
                                   <input type="number" placeholder="Kekosongan" min="1" value={pos.vacancies} onChange={e => handlePositionChange(index, 'vacancies', parseInt(e.target.value))} className="w-24 p-2 border rounded" required/>
                                   <button type="button" onClick={() => handleRemovePosition(index)} className="text-red-500 p-2"><TrashIcon className="w-5 h-5"/></button>
                               </div>
                           ))}
                        </div>
                        <button type="button" onClick={handleAddPosition} className="mt-2 text-sm text-primary hover:underline">+ Tambah Jawatan</button>
                    </div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end space-x-3 mt-auto"><button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button><button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Simpan Sesi</button></div>
            </form>
        </div>
    );
};

const ManageSessionView: React.FC<{
    session: ElectionSession;
    nominations: Nomination[];
    members: Member[];
    onBack: () => void;
    onUpdateSession: (updatedSession: ElectionSession) => Promise<void>;
    onUpdateNominations: (updatedNominations: Nomination[]) => Promise<void>;
    setActivePage: (page: Page) => void;
}> = ({ session: initialSession, nominations, members, onBack, onUpdateSession, onUpdateNominations, setActivePage }) => {
    const [session, setSession] = useState(initialSession);
    const [activeTab, setActiveTab] = useState('pencalonan');
    const { addToast } = useToast();
    
    const nominationsByPosition = useMemo(() => {
        return session.contestedPositions.reduce((acc, pos) => {
            acc[pos.position] = nominations.filter(n => n.sessionId === session.id && n.position === pos.position);
            return acc;
        }, {} as Record<string, Nomination[]>);
    }, [nominations, session.id, session.contestedPositions]);
    
    const handleNominationStatusChange = async (nominationId: number, status: 'Diterima' | 'Ditolak') => {
        const updatedNominations = nominations.map(n => n.id === nominationId ? {...n, status} : n);
        
        let updatedSession = {...session};
        if (status === 'Diterima') {
            const nomination = updatedNominations.find(n => n.id === nominationId);
            const member = members.find(m => m.id === nomination?.nominatedMemberId);
            if (member && nomination && !session.candidates.some(c => c.id === member.id && c.position === nomination.position)) {
                const newCandidate: Candidate = { id: member.id, name: member.name, position: nomination.position, imageUrl: `https://i.pravatar.cc/100?u=${member.id}` };
                updatedSession.candidates = [...session.candidates, newCandidate];
            }
        }
        
        await onUpdateNominations(updatedNominations);
        await onUpdateSession(updatedSession);
        setSession(updatedSession);
        addToast(`Status pencalonan telah dikemaskini.`);
    };

    const voteResultsByPosition = useMemo(() => {
        const results: Record<string, { candidate: Candidate, count: number }[]> = {};
        session.contestedPositions.forEach(p => {
            const positionCandidates = session.candidates.filter(c => c.position === p.position);
            const voteCounts = new Map<number, number>();
            
            session.votes.forEach(vote => {
                const selectionForPosition = vote.selections.find(s => s.position === p.position);
                selectionForPosition?.candidateIds.forEach(candidateId => {
                    voteCounts.set(candidateId, (voteCounts.get(candidateId) || 0) + 1);
                });
            });

            results[p.position] = positionCandidates
                .map(candidate => ({
                    candidate,
                    count: voteCounts.get(candidate.id) || 0,
                }))
                .sort((a, b) => b.count - a.count);
        });
        return results;
    }, [session]);
    
    const [newlyAppointed, setNewlyAppointed] = useState<Record<string, Candidate[]>>({});

    const handleAppointCommittee = async () => {
        if (Object.keys(newlyAppointed).length === 0) {
            addToast("Sila pilih sekurang-kurangnya seorang calon untuk dilantik.", "error");
            return;
        }

        const newCommitteeMembers: Omit<CommitteeMember, 'id'>[] = [];
        Object.entries(newlyAppointed).forEach(([position, appointees]) => {
            appointees.forEach(appointee => {
                const memberDetails = members.find(m => m.id === appointee.id);
                newCommitteeMembers.push({
                    name: appointee.name,
                    position: position,
                    session: session.title,
                    phone: memberDetails?.phone || '',
                    email: `ajk.${appointee.id}@surau.my`,
                    imageUrl: appointee.imageUrl,
                });
            });
        });

        const setiausahaPositionKey = "Setiausaha";
        const penolongSetiausahaPositionName = "Penolong Setiausaha";
        const setiausahaWinners = newlyAppointed[setiausahaPositionKey];
        const setiausahaResults = voteResultsByPosition[setiausahaPositionKey];

        if (setiausahaWinners && setiausahaWinners.length > 0 && setiausahaResults && setiausahaResults.length > 1) {
            const runnerUpCandidate = setiausahaResults[1].candidate;
            const isRunnerUpAlreadyAppointed = newCommitteeMembers.some(cm => cm.name === runnerUpCandidate.name);

            if (runnerUpCandidate && !isRunnerUpAlreadyAppointed) {
                 const runnerUpMemberDetails = members.find(m => m.id === runnerUpCandidate.id);
                 newCommitteeMembers.push({
                    name: runnerUpCandidate.name,
                    position: penolongSetiausahaPositionName,
                    session: session.title,
                    phone: runnerUpMemberDetails?.phone || '',
                    email: `ajk.${runnerUpCandidate.id}@surau.my`,
                    imageUrl: runnerUpCandidate.imageUrl,
                });
                addToast(`${runnerUpCandidate.name} dilantik secara automatik sebagai ${penolongSetiausahaPositionName}.`, 'info');
            }
        }

        const finalCommittee = newCommitteeMembers.map((m,i) => ({ ...m, id: Date.now()+i }));

        await saveCommittee(finalCommittee);
        addToast(`Jawatankuasa baru bagi sesi ${session.title} telah berjaya dilantik!`, 'success');
        setActivePage(Page.Jawatankuasa);
    };

    const renderTabContent = () => {
        switch (activeTab) {
            case 'pencalonan':
                return (
                    <div className="space-y-4">
                        {Object.entries(nominationsByPosition).map(([position, positionNominations]) => (
                            <div key={position}>
                                <h3 className="font-bold mb-2 text-lg text-primary">{position}</h3>
                                 <div className="overflow-x-auto border rounded-lg">
                                     <table className="w-full text-sm">
                                        <thead className="bg-gray-100"><tr><th className="p-2 text-left">Calon</th><th className="p-2 text-left">Pencadang</th><th className="p-2 text-left">Tarikh</th><th className="p-2 text-left">Status</th><th className="p-2 text-left">Tindakan</th></tr></thead>
                                        <tbody>
                                            {positionNominations.map(n => {
                                                const nominee = members.find(m => m.id === n.nominatedMemberId);
                                                const nominator = members.find(m => m.id === n.nominatorMemberId);
                                                return (
                                                    <tr key={n.id} className="border-b last:border-0">
                                                        <td className="p-2 font-semibold">{nominee?.name || 'Tidak Ditemui'}</td>
                                                        <td className="p-2">{nominator?.name || 'Tidak Ditemui'}</td>
                                                        <td className="p-2">{new Date(n.nominationDate).toLocaleDateString('ms-MY')}</td>
                                                        <td className="p-2"><span className={`px-2 py-1 rounded-full text-xs ${n.status === 'Diterima' ? 'bg-green-100 text-green-800' : n.status === 'Ditolak' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>{n.status}</span></td>
                                                        <td className="p-2">
                                                            {n.status === 'Menunggu' && (
                                                                <div className="flex gap-2">
                                                                    <button onClick={() => handleNominationStatusChange(n.id, 'Diterima')} className="text-xs bg-green-500 text-white px-2 py-1 rounded hover:bg-green-600">Terima</button>
                                                                    <button onClick={() => handleNominationStatusChange(n.id, 'Ditolak')} className="text-xs bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600">Tolak</button>
                                                                </div>
                                                            )}
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                             {positionNominations.length === 0 && <tr><td colSpan={5} className="text-center p-4 text-gray-500">Tiada pencalonan untuk jawatan ini.</td></tr>}
                                        </tbody>
                                     </table>
                                 </div>
                            </div>
                        ))}
                    </div>
                );
            case 'keputusan':
                 return (
                    <div className="space-y-8">
                        {Object.entries(voteResultsByPosition).map(([position, results]) => (
                            <div key={position}>
                                <h3 className="font-bold mb-4 text-lg text-primary">{position}</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div>
                                        <h4 className="font-semibold mb-2">Senarai Calon & Undi</h4>
                                        {results.map((result, index) => (
                                            <div key={result.candidate.id} className="flex items-center justify-between py-2 border-b">
                                                <div className="flex items-center"><span className="font-bold w-6">{index + 1}.</span><img src={result.candidate.imageUrl} className="w-10 h-10 rounded-full mr-3"/><span>{result.candidate.name}</span></div>
                                                <span className="font-bold text-primary">{result.count} undi</span>
                                            </div>
                                        ))}
                                    </div>
                                    <div className="h-64">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={results} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                                                <CartesianGrid strokeDasharray="3 3" />
                                                <XAxis type="number" allowDecimals={false} />
                                                <YAxis type="category" dataKey="candidate.name" width={120} tick={{fontSize: 10}}/>
                                                <Tooltip />
                                                <Bar dataKey="count" name="Jumlah Undi" fill="#065f46" />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                );
            case 'pelantikan':
                 return (
                    <div>
                        <h3 className="font-bold mb-4 text-xl text-dark">Lantik Jawatankuasa Baru</h3>
                        <p className="text-sm text-gray-600 mb-6">Pilih calon yang menang untuk dilantik sebagai barisan jawatankuasa sesi <strong>{session.title}</strong>. Jawatan mereka akan ditetapkan secara automatik.</p>
                        <div className="space-y-6">
                            {Object.entries(voteResultsByPosition).map(([position, results]) => (
                                <div key={position}>
                                    <h4 className="font-bold text-lg text-primary mb-2">{position} (Pilih {session.contestedPositions.find(p => p.position === position)?.vacancies || 0})</h4>
                                     {position === 'Setiausaha' && (
                                        <p className="text-xs text-blue-700 bg-blue-100 p-2 rounded-md mb-4 flex items-start">
                                            <InfoIcon className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0"/>
                                            <span>Nota: Calon dengan undian kedua tertinggi untuk jawatan Setiausaha akan dilantik sebagai <strong>Penolong Setiausaha</strong> secara automatik jika tidak dilantik untuk jawatan lain.</span>
                                        </p>
                                    )}
                                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                                        {results.map(({candidate, count}) => (
                                            <div key={candidate.id} onClick={() => {
                                                setNewlyAppointed(prev => {
                                                    const currentForPos = prev[position] || [];
                                                    const isSelected = currentForPos.some(c => c.id === candidate.id);
                                                    let newForPos;
                                                    if (isSelected) {
                                                        newForPos = currentForPos.filter(c => c.id !== candidate.id);
                                                    } else {
                                                        newForPos = [...currentForPos, candidate];
                                                    }
                                                    return {...prev, [position]: newForPos };
                                                });
                                            }} className={`p-3 text-center border-2 rounded-lg cursor-pointer relative ${newlyAppointed[position]?.some(c=>c.id === candidate.id) ? 'border-primary bg-primary/10' : ''}`}>
                                                <img src={candidate.imageUrl} className="w-20 h-20 rounded-full mx-auto mb-2" />
                                                <p className="font-semibold text-sm">{candidate.name}</p>
                                                <p className="text-xs text-gray-500">{count} undi</p>
                                                {newlyAppointed[position]?.some(c=>c.id === candidate.id) && <div className="absolute top-1 right-1 bg-primary text-white rounded-full p-1"><CheckIcon className="w-4 h-4"/></div>}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="text-right mt-8 border-t pt-4">
                            <button onClick={handleAppointCommittee} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark disabled:bg-gray-400" disabled={Object.keys(newlyAppointed).length === 0}>
                                Lantik {Object.values(newlyAppointed).flat().length} AJK Terpilih
                            </button>
                        </div>
                    </div>
                );
            default: return null;
        }
    }

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4 border-b pb-4">
                <div>
                    <h2 className="text-2xl font-bold text-dark">{session.title}</h2>
                    <p className="text-sm text-gray-500">Status: <span className="font-semibold text-primary">{session.status}</span></p>
                </div>
                <button onClick={onBack} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300">&larr; Kembali</button>
            </div>
            <div className="border-b border-gray-200 mb-6">
                <nav className="-mb-px flex space-x-6">
                    <button onClick={() => setActiveTab('pencalonan')} className={`py-3 px-1 border-b-2 text-sm font-medium ${activeTab==='pencalonan' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:border-gray-300'}`}>Pengurusan Pencalonan</button>
                    <button onClick={() => setActiveTab('keputusan')} className={`py-3 px-1 border-b-2 text-sm font-medium ${activeTab==='keputusan' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:border-gray-300'}`}>Keputusan Undian</button>
                    <button onClick={() => setActiveTab('pelantikan')} className={`py-3 px-1 border-b-2 text-sm font-medium ${activeTab==='pelantikan' ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:border-gray-300'}`}>Pelantikan AJK Baru</button>
                </nav>
            </div>
            {renderTabContent()}
        </div>
    );
};


const Pemilihan: React.FC<{ setActivePage: (page: Page) => void }> = ({ setActivePage }) => {
    const [sessions, setSessions] = useState<ElectionSession[]>([]);
    const [nominations, setNominations] = useState<Nomination[]>([]);
    const [members, setMembers] = useState<Member[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [selectedSession, setSelectedSession] = useState<ElectionSession | null>(null);
    const { addToast } = useToast();

    const getSessionStatus = useCallback((session: ElectionSession): ElectionSession['status'] => {
        const today = new Date();
        const nomEnd = new Date(session.nominationEndDate);
        nomEnd.setHours(23, 59, 59, 999);
        const voteEnd = new Date(session.votingEndDate);
        voteEnd.setHours(23, 59, 59, 999);

        if (today > voteEnd) return 'Selesai';
        if (today >= new Date(session.votingStartDate)) return 'Pengundian';
        if (today >= new Date(session.nominationStartDate)) return 'Pencalonan';
        return 'Akan Datang';
    }, []);

    const fetchData = useCallback(async () => {
        try {
            setIsLoading(true);
            const [sessionsData, nominationsData, membersData] = await Promise.all([
                getElectionSessions(),
                getNominations(),
                getMembers(),
            ]);
            setSessions(sessionsData.map(s => ({...s, status: getSessionStatus(s)})));
            setNominations(nominationsData);
            setMembers(membersData);
        } catch (err) {
            setError("Gagal memuatkan data pemilihan.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [getSessionStatus]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleSaveSession = async (data: Omit<ElectionSession, 'id' | 'status' | 'candidates' | 'votes'>) => {
        const newSession: ElectionSession = {
            id: Date.now(),
            ...data,
            status: 'Akan Datang',
            candidates: [],
            votes: [],
        };
        const updatedSessions = [newSession, ...sessions];
        try {
            await saveElectionSessions(updatedSessions);
            setSessions(updatedSessions.map(s => ({...s, status: getSessionStatus(s)})));
            addToast("Sesi pemilihan baru telah dicipta.");
        } catch (err) {
            addToast("Gagal mencipta sesi.", "error");
        } finally {
            setIsFormModalOpen(false);
        }
    };
    
    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    if (selectedSession) {
        return <ManageSessionView 
            session={selectedSession}
            nominations={nominations}
            members={members}
            onBack={() => setSelectedSession(null)}
            onUpdateSession={async (updated) => {
                const newSessions = sessions.map(s => s.id === updated.id ? updated : s);
                await saveElectionSessions(newSessions);
                setSessions(newSessions);
            }}
            onUpdateNominations={async (updated) => {
                await saveNominations(updated);
                setNominations(updated);
            }}
            setActivePage={setActivePage}
        />
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-dark">Pengurusan Pemilihan AJK</h2>
                <button onClick={() => setIsFormModalOpen(true)} className="flex items-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">
                    <PlusIcon className="w-5 h-5 mr-2" /> Cipta Sesi Baru
                </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-bold text-dark mb-4">Sejarah Sesi Pemilihan</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-100"><tr><th className="p-3">Sesi</th><th className="p-3">Tarikh Pencalonan</th><th className="p-3">Tarikh Pengundian</th><th className="p-3">Status</th><th className="p-3">Tindakan</th></tr></thead>
                        <tbody>
                            {sessions.sort((a,b) => b.id - a.id).map(s => (
                                <tr key={s.id} className="border-b hover:bg-gray-50">
                                    <td className="p-3 font-semibold">{s.title}</td>
                                    <td className="p-3">{new Date(s.nominationStartDate).toLocaleDateString()} - {new Date(s.nominationEndDate).toLocaleDateString()}</td>
                                    <td className="p-3">{new Date(s.votingStartDate).toLocaleDateString()} - {new Date(s.votingEndDate).toLocaleDateString()}</td>
                                    <td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${s.status === 'Selesai' ? 'bg-gray-200' : 'bg-green-100 text-green-800'}`}>{s.status}</span></td>
                                    <td className="p-3"><button onClick={() => setSelectedSession(s)} className="text-primary hover:underline font-semibold">Urus Sesi</button></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {isFormModalOpen && <SessionFormModal onClose={() => setIsFormModalOpen(false)} onSave={handleSaveSession} />}
        </div>
    );
};

export default Pemilihan;