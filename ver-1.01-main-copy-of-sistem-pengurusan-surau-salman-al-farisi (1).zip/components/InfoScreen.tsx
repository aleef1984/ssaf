import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { PrayerData, PrayerTime, Announcement, SurauInfo, Album, Transaction, IdleSlide, IslamicEvent } from '../types';
import { getAnnouncements, getSurauInfo, getAlbums, getTransactions } from '../services/dataService';
import { islamicEvents } from '../data/islamicEvents';
import Spinner from './Spinner';
import DynamicLogo from './DynamicLogo';

// --- TYPES & CONSTANTS ---
type Mode = 'LOADING' | 'IDLE' | 'PREP' | 'ADHAN' | 'IQAMAH_COUNTDOWN' | 'ERROR';
const PRAYER_NAMES: { [key: string]: string } = { subuh: 'Subuh', zohor: 'Zohor', asar: 'Asar', maghrib: 'Maghrib', isyak: 'Isyak' };
const PREP_TIME_MINUTES = 5;
const IQAMAH_WAIT_MINUTES = 10;
const IDLE_SLIDE_INTERVAL_S = 20;

// --- HELPER FUNCTIONS ---
const parseTimeToDate = (timeStr: string): Date | null => {
    if (!timeStr || !timeStr.includes(':')) return null;
    const [hours, minutes] = timeStr.split(':').map(Number);
    if (isNaN(hours) || isNaN(minutes)) return null;
    const date = new Date();
    date.setHours(hours, minutes, 0, 0);
    return date;
};

const formatCountdown = (totalSeconds: number): string => `${String(Math.floor(totalSeconds / 60)).padStart(2, '0')}:${String(totalSeconds % 60).padStart(2, '0')}`;
const formatHijriDate = (hijriStr: string): string => {
    if (!hijriStr || !/^\d{4}-\d{2}-\d{2}$/.test(hijriStr)) return hijriStr;
    const [year, month, day] = hijriStr.split('-').map(Number);
    const months = ['Muharram', 'Safar', 'Rabiulawal', 'Rabiulakhir', 'Jamadilawal', 'Jamadilakhir', 'Rejab', 'Syaaban', 'Ramadan', 'Syawal', 'Zulkaedah', 'Zulhijah'];
    return (month >= 1 && month <= 12) ? `${day} ${months[month - 1]} ${year}H` : hijriStr;
};

// --- CHILD COMPONENTS (for performance & clarity) ---
const DigitalClock = React.memo(() => {
    const [time, setTime] = useState(new Date());
    useEffect(() => {
        const timerId = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timerId);
    }, []);

    const timeString = time.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    const [timePart, ampmPart] = timeString.split(' ');

    return (
        <h1 className="text-8xl lg:text-9xl font-bold font-mono tracking-tighter">
            {timePart}
            <span className="text-5xl lg:text-6xl ml-4 align-baseline">{ampmPart}</span>
        </h1>
    );
});

const MainSlide = React.memo(({ todayTimes, nextPrayerName }: { todayTimes: PrayerTime, nextPrayerName: string | null }) => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 w-full h-full p-4 md:p-8 animate-fade-in">
        <div className="lg:col-span-2 flex flex-col justify-between p-6 bg-black/30 backdrop-blur-md rounded-2xl border border-white/10">
            <div>
                <DigitalClock />
                <p className="text-3xl lg:text-4xl">{new Date().toLocaleDateString('ms-MY', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
                <p className="text-xl lg:text-2xl text-secondary">{formatHijriDate(todayTimes.hijri)}</p>
            </div>
        </div>
        <div className="lg:col-span-1 bg-black/40 p-4 lg:p-6 rounded-2xl backdrop-blur-md border border-white/10">
            <h3 className="text-2xl lg:text-3xl font-bold text-center mb-4">Waktu Solat</h3>
            <ul className="text-xl lg:text-2xl space-y-2 lg:space-y-3">
                {Object.entries(PRAYER_NAMES).map(([key, name]) => {
                    const time = todayTimes[key as keyof typeof PRAYER_NAMES];
                    const prayerDate = parseTimeToDate(time);
                    const isNext = nextPrayerName === name;
                    return <li key={key} className={`flex justify-between p-2 lg:p-3 rounded-lg transition-colors ${isNext ? 'bg-white/90 text-black' : ''}`}><span className={`font-semibold ${isNext ? 'text-primary' : ''}`}>{name}</span><span className={`font-bold font-mono ${isNext ? '' : 'opacity-80'}`}>{prayerDate ? prayerDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }) : '-:--'}</span></li>;
                })}
            </ul>
        </div>
    </div>
));

const CommunitySlide = React.memo(({ album, totalFund, announcements }: { album: Album | null, totalFund: number, announcements: Announcement[] }) => (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 w-full h-full p-4 md:p-8 animate-fade-in">
        <div className="lg:col-span-2 bg-black/30 backdrop-blur-md rounded-2xl border border-white/10 flex flex-col p-6">
            <h3 className="text-3xl font-bold mb-4">Sorotan Komuniti</h3>
            {album ? <div className="flex-grow rounded-lg overflow-hidden relative"><img src={album.coverImageUrl} alt={album.title} className="w-full h-full object-cover" /><div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4"><h4 className="text-2xl font-bold">{album.title}</h4></div></div> : <p>Tiada aktiviti terkini.</p>}
        </div>
        <div className="lg:col-span-1 flex flex-col gap-8">
            <div className="bg-black/40 p-6 rounded-2xl backdrop-blur-md border border-white/10 flex-grow"><h3 className="text-3xl font-bold mb-2">Dana Surau</h3><p className="text-5xl font-bold font-mono text-secondary">RM{totalFund.toFixed(2)}</p></div>
            <div className="bg-black/40 p-6 rounded-2xl backdrop-blur-md border border-white/10 flex-grow"><h3 className="text-3xl font-bold mb-2">Pengumuman</h3><p className="text-lg">{announcements[0]?.title || 'Tiada pengumuman baru.'}</p></div>
        </div>
    </div>
));

const IslamicEventSlide = React.memo(({ event }: { event: { name: string; daysLeft: number } | null }) => {
    if (!event) return <div className="flex flex-col items-center justify-center text-center p-8 bg-black/30 backdrop-blur-md rounded-2xl border border-white/10 w-full h-full animate-fade-in"><h3 className="text-3xl font-bold">Tiada Acara Dijadualkan</h3></div>;
    return (
        <div className="flex flex-col items-center justify-center text-center p-8 bg-black/30 backdrop-blur-md rounded-2xl border border-white/10 w-full h-full animate-fade-in">
            <p className="text-3xl text-secondary">Acara Islamik Akan Datang</p>
            <h3 className="text-7xl font-bold my-4">{event.name}</h3>
            <div className="flex items-baseline gap-4">
                <p className="text-9xl font-bold text-secondary">{event.daysLeft}</p>
                <p className="text-5xl">Hari Lagi</p>
            </div>
        </div>
    );
});


const FocusScreen = React.memo(({ title, prayerName, children }: { title: string, prayerName: string, children: React.ReactNode }) => (
    <div className="text-center animate-fade-in flex flex-col items-center justify-center p-8 bg-black/50 backdrop-blur-xl rounded-full w-[80vw] h-[80vw] md:w-[70vh] md:h-[70vh] border-4 border-secondary shadow-2xl shadow-secondary/30">
        <h2 className="text-4xl md:text-7xl font-bold tracking-wider">{title}</h2>
        <h1 className="text-6xl md:text-9xl font-extrabold my-4">{prayerName.toUpperCase()}</h1>
        {children}
    </div>
));

const CircularCountdown = React.memo(({ seconds, maxSeconds }: { seconds: number, maxSeconds: number }) => {
    const radius = 90; const circumference = 2 * Math.PI * radius;
    const progress = (maxSeconds - seconds) / maxSeconds; const offset = circumference * (1 - progress);
    return <div className="relative w-52 h-52 md:w-64 md:h-64 flex items-center justify-center"><svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200"><circle cx="100" cy="100" r={radius} stroke="rgba(255,255,255,0.2)" strokeWidth="8" fill="transparent" /><circle cx="100" cy="100" r={radius} stroke="#fcd34d" strokeWidth="10" fill="transparent" strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round" style={{ transition: 'stroke-dashoffset 1s linear' }} /></svg><div className="absolute font-mono text-4xl md:text-6xl tracking-widest">{formatCountdown(seconds)}</div></div>;
});

const Marquee = React.memo(({ items }: { items: string[] }) => {
    const marqueeText = useMemo(() => items.length > 0 ? items.join('  •  ') : 'Selamat datang ke surau kami.', [items]);
    return <div className="absolute bottom-0 left-0 w-full h-12 bg-black/50 backdrop-blur-md overflow-hidden"><div className="absolute whitespace-nowrap text-lg h-full flex items-center animate-marquee"><p className="mx-4">{marqueeText}</p><p className="mx-4">{marqueeText}</p></div></div>;
});

// --- MAIN COMPONENT ---
const InfoScreen: React.FC = () => {
    const [isStarted, setIsStarted] = useState(false);
    const [mode, setMode] = useState<Mode>('LOADING');
    const [prayerData, setPrayerData] = useState<PrayerData | null>(null);
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);
    const [albums, setAlbums] = useState<Album[]>([]);
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [announcements, setAnnouncements] = useState<Announcement[]>([]);
    const [activePrayerInfo, setActivePrayerInfo] = useState<{ name: string; time: Date } | null>(null);
    const [countdownSeconds, setCountdownSeconds] = useState(0);
    const [idleSlideIndex, setIdleSlideIndex] = useState(0);
    const [zikrText, setZikrText] = useState('Subhanallah');
    const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
    const azanVideoRef = useRef<HTMLVideoElement>(null);
    
    const handleStart = useCallback(() => {
        setIsStarted(true);
        document.documentElement.requestFullscreen().catch(e => console.warn(e));
    }, []);

    const todayTimes = prayerData?.prayerTime[0];
    const marqueeItems = useMemo(() => announcements.map(a => a.title), [announcements]);

    const nextPrayerName = useMemo(() => {
        if (!todayTimes) return null;
        const now = new Date();
        for (const key of ['subuh', 'zohor', 'asar', 'maghrib', 'isyak']) {
            const prayerDate = parseTimeToDate(todayTimes[key as keyof PrayerTime]);
            if (prayerDate && prayerDate > now) return PRAYER_NAMES[key];
        }
        return 'Subuh';
    }, [todayTimes, countdownSeconds]);

    useEffect(() => {
        if (!isStarted) return;
        const fetchData = async () => {
            try {
                const year = new Date().getFullYear(); const month = new Date().getMonth() + 1; const day = new Date().getDate().toString().padStart(2, '0');
                const [prayerRes, announcementsData, surauInfoData, albumsData, transactionsData] = await Promise.all([
                    fetch(`https://api.waktusolat.app/solat/PHG02?year=${year}&month=${month}`),
                    getAnnouncements(), getSurauInfo(), getAlbums(), getTransactions()
                ]);
                if (!prayerRes.ok) throw new Error('API Waktu Solat Gagal');
                const prayerApiData = await prayerRes.json();
                const todayDateString = `${day}-${new Date().toLocaleString('en-GB', { month: 'short' })}-${year}`;
                const todayRaw = prayerApiData.prayerTime.find((p: any) => p.date === todayDateString);
                if (!todayRaw) throw new Error("Waktu solat hari ini tidak ditemui");
                const todayPrayerInfo: PrayerTime = { hijri: todayRaw.hijri, date: todayRaw.date, imsak: todayRaw.imsak, subuh: todayRaw.fajr, syuruk: todayRaw.syuruk, zohor: todayRaw.dhuhr, asar: todayRaw.asr, maghrib: todayRaw.maghrib, isyak: todayRaw.isha, };
                setPrayerData({ prayerTime: [todayPrayerInfo], status: prayerApiData.status, zone: prayerApiData.zone });
                setAnnouncements(announcementsData); setSurauInfo(surauInfoData); setAlbums(albumsData); setTransactions(transactionsData);
                setMode('IDLE');
            } catch (err) { setMode('ERROR'); console.error(err); }
        };
        fetchData();
    }, [isStarted]);

    const nextIslamicEvent = useMemo(() => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const upcomingEvent = islamicEvents
            .map(event => ({ ...event, dateObj: new Date(event.date) }))
            .filter(event => event.dateObj >= today)
            .sort((a, b) => a.dateObj.getTime() - b.dateObj.getTime())[0];

        if (!upcomingEvent) return null;
        
        const daysLeft = Math.ceil((upcomingEvent.dateObj.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        
        return { name: upcomingEvent.name, daysLeft };
    }, []);

    useEffect(() => {
        if (mode !== 'IDLE' || !isStarted) return;
        const SLIDE_ORDER: IdleSlide[] = ['main', 'community', 'event'];
        const slideTimer = setInterval(() => {
            setIdleSlideIndex(current => (current + 1) % SLIDE_ORDER.length);
        }, IDLE_SLIDE_INTERVAL_S * 1000);
        return () => clearInterval(slideTimer);
    }, [mode, isStarted]);
    
    useEffect(() => {
        if (mode !== 'IQAMAH_COUNTDOWN' || !isStarted) return;
        const zikrCycle = ['Subhanallah', 'Alhamdulillah', 'Allahu Akbar']; let i = 0;
        const zikrTimer = setInterval(() => { i = (i + 1) % zikrCycle.length; setZikrText(zikrCycle[i]); }, 3000);
        return () => clearInterval(zikrTimer);
    }, [mode, isStarted]);
    
     useEffect(() => {
        if (!isStarted || mode === 'LOADING' || mode === 'ERROR' || !prayerData?.prayerTime[0]) return;
        const timerId = setInterval(() => {
            const now = new Date();
            const nowMs = now.getTime();
            
            for (const key in PRAYER_NAMES) {
                const prayerDate = parseTimeToDate(prayerData.prayerTime[0][key as keyof PrayerTime]);
                if (prayerDate) {
                    const prayerName = PRAYER_NAMES[key];
                    const adhanTimeMs = prayerDate.getTime();
                    const prepTimeMs = adhanTimeMs - PREP_TIME_MINUTES * 60 * 1000;
                    const iqamahEndTimeMs = adhanTimeMs + IQAMAH_WAIT_MINUTES * 60 * 1000;
                    
                    // Rule 1: Preparation Mode
                    if (nowMs >= prepTimeMs && nowMs < adhanTimeMs) {
                        if (mode !== 'PREP') {
                            setMode('PREP');
                            setActivePrayerInfo({ name: prayerName, time: prayerDate });
                        }
                        setCountdownSeconds(Math.round((adhanTimeMs - nowMs) / 1000));
                        return; // Stop checking further
                    }

                    // Rule 2: Adhan and Iqamah Countdown period
                    if (nowMs >= adhanTimeMs && nowMs < iqamahEndTimeMs) {
                        // Enter ADHAN mode if not already in it or IQAMAH
                        if (mode !== 'ADHAN' && mode !== 'IQAMAH_COUNTDOWN') {
                            setMode('ADHAN');
                            setActivePrayerInfo({ name: prayerName, time: prayerDate });
                        }
                        // If in IQAMAH_COUNTDOWN, just update seconds
                        if (mode === 'IQAMAH_COUNTDOWN') {
                            setCountdownSeconds(Math.round((iqamahEndTimeMs - nowMs) / 1000));
                        }
                        return; // Stop checking further
                    }
                }
            }
            // If no rules match, go back to IDLE
            if (mode !== 'IDLE') {
                setMode('IDLE');
            }
        }, 1000);
        return () => clearInterval(timerId);
    }, [isStarted, prayerData, mode]);

    useEffect(() => {
        if (mode === 'ADHAN' && azanVideoRef.current) {
            azanVideoRef.current.play().catch(e => console.error("Azan video play failed:", e));
        }
    }, [mode]);

    const handleAzanVideoEnd = () => {
        if (activePrayerInfo) {
             const iqamahEndTimeMs = activePrayerInfo.time.getTime() + IQAMAH_WAIT_MINUTES * 60 * 1000;
             setCountdownSeconds(Math.round((iqamahEndTimeMs - new Date().getTime()) / 1000));
        }
        setMode('IQAMAH_COUNTDOWN');
    };
    
    const handleBackgroundVideoEnded = () => {
        const videoCount = surauInfo?.infoScreenSettings?.backgroundVideoUrls.length || 0;
        if (videoCount > 0) {
            setCurrentVideoIndex(prevIndex => (prevIndex + 1) % videoCount);
        }
    };


    const renderContent = () => {
        if (!todayTimes || !surauInfo) return null;
        switch (mode) {
            case 'PREP': return <FocusScreen title="BERSEDIA UNTUK SOLAT" prayerName={activePrayerInfo!.name}><p className="text-6xl md:text-8xl font-mono tracking-widest">{formatCountdown(countdownSeconds)}</p></FocusScreen>;
            case 'ADHAN': {
                const isSubuh = activePrayerInfo?.name === 'Subuh';
                const adhanVideoUrl = isSubuh 
                    ? surauInfo.infoScreenSettings.azanSubuhVideoUrl 
                    : surauInfo.infoScreenSettings.azanVideoUrl;
                
                return (
                    <div className="absolute inset-0 z-50 bg-black flex items-center justify-center animate-fade-in">
                        <video
                            ref={azanVideoRef}
                            key={adhanVideoUrl}
                            src={adhanVideoUrl}
                            onEnded={handleAzanVideoEnd}
                            className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 bg-black/50 backdrop-blur-lg p-4 rounded-xl text-center border border-white/20 shadow-lg">
                            <p className="text-2xl font-semibold">Telah masuk waktu solat</p>
                            <p className="text-5xl font-bold text-secondary my-2">{activePrayerInfo?.name.toUpperCase()}</p>
                            <p className="text-lg opacity-80">Peringatan Iqamah akan bermula selepas Azan.</p>
                        </div>
                    </div>
                );
            }
            case 'IQAMAH_COUNTDOWN': return <FocusScreen title="IQAMAH DALAM" prayerName={activePrayerInfo!.name}><CircularCountdown seconds={countdownSeconds} maxSeconds={IQAMAH_WAIT_MINUTES * 60} /><p className="text-3xl md:text-5xl font-bold mt-4">{zikrText}</p></FocusScreen>;
            case 'IDLE':
                const SLIDE_ORDER: IdleSlide[] = ['main', 'community', 'event'];
                const currentSlide = SLIDE_ORDER[idleSlideIndex];
                const latestAlbum = albums.length > 0 ? albums.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0] : null;
                const totalFund = transactions.reduce((sum, t) => sum + t.amount, 0);

                switch(currentSlide) {
                    case 'community':
                        return <CommunitySlide album={latestAlbum} totalFund={totalFund} announcements={announcements} />;
                    case 'event':
                        return <IslamicEventSlide event={nextIslamicEvent} />;
                    case 'main':
                    default:
                        return <MainSlide todayTimes={todayTimes} nextPrayerName={nextPrayerName} />;
                }
            default: return null;
        }
    };
    
    if (!isStarted) return (<div className="bg-dark text-white w-screen h-screen flex flex-col justify-center items-center"><DynamicLogo className="w-48 h-48 text-primary" /><h1 className="text-5xl font-bold mt-4">InfoScreen {surauInfo?.name || 'Surau'}</h1><p className="text-xl text-gray-300 mt-2">Sistem Papan Maklumat Digital</p><button onClick={handleStart} className="mt-12 bg-primary text-white text-2xl font-bold py-4 px-10 rounded-lg hover:bg-green-700 transition-colors">MULAKAN</button></div>);
    if (mode === 'LOADING') return <div className="bg-dark w-screen h-screen flex items-center justify-center"><Spinner /></div>;
    if (mode === 'ERROR') return <div className="bg-dark text-white w-screen h-screen flex items-center justify-center p-8 text-center"><h1 className="text-3xl font-bold">Ralat Memuatkan Data</h1><p>Gagal memuatkan data waktu solat atau maklumat surau. Sila pastikan sambungan internet berfungsi dan cuba muat semula halaman.</p></div>;
    
    const backgroundVideos = surauInfo?.infoScreenSettings?.backgroundVideoUrls || [];

    return (
        <div className="w-screen h-screen text-white flex items-center justify-center font-sans overflow-hidden bg-black">
            {backgroundVideos.length > 0 && (
                <video 
                    key={backgroundVideos[currentVideoIndex]} 
                    autoPlay 
                    muted 
                    onEnded={handleBackgroundVideoEnded}
                    className="absolute top-0 left-0 w-full h-full object-cover z-0 transition-opacity duration-1000 opacity-80"
                >
                    <source src={backgroundVideos[currentVideoIndex]} type="video/mp4" />
                </video>
            )}
            <div className="absolute inset-0 bg-black/30"></div>
            <div className="relative z-10 w-full h-full flex flex-col">
                <header className="w-full p-4 flex items-center gap-4 bg-black/20 backdrop-blur-sm">
                    <DynamicLogo className="w-12 h-12"/>
                    <div>
                        <h2 className="text-xl md:text-2xl font-bold">{surauInfo?.name}</h2>
                        <p className="text-xs md:text-sm opacity-80">{surauInfo?.address}</p>
                    </div>
                </header>
                <main className="flex-grow flex items-center justify-center">
                    {renderContent()}
                </main>
                <Marquee items={marqueeItems}/>
            </div>
        </div>
    );
};
export default InfoScreen;