import React, { useState, useEffect } from 'react';
import { Page, Duty, Member, Transaction, Announcement, KhairatTask, SurauInfo, AIInsight } from '../types';
import { getMembers, getAnnouncements, getSchedule, getTransactions, getKhairatTasks, saveKhairatTasks, saveTransactions, getSurauInfo } from '../services/dataService';
import { generateDashboardInsight } from '../services/geminiService';
import { UsersIcon, DollarSignIcon, CalendarIcon, MegaphoneIcon, ClockIcon, CheckCircleIcon, HeartCrackIcon, LightbulbIcon, SparklesIcon } from './icons';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Spinner from './Spinner';
import { useToast } from '../App';

interface StatCardProps {
    icon: React.ReactNode;
    title: string;
    value: string;
    onClick: () => void;
    className?: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, onClick, className = '' }) => (
    <div 
        className={`bg-white p-6 rounded-xl shadow-card flex items-center space-x-4 cursor-pointer hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300 ${className}`}
        onClick={onClick}
    >
        <div className="bg-primary/10 p-4 rounded-full">
            {icon}
        </div>
        <div>
            <p className="text-sm text-gray-500 font-medium">{title}</p>
            <p className="text-2xl font-bold text-dark">{value}</p>
        </div>
    </div>
);

const AIInsightCard: React.FC<{
    insight: AIInsight | null;
    isLoading: boolean;
    onGenerate: () => void;
}> = ({ insight, isLoading, onGenerate }) => {
    return (
        <div className="bg-white p-6 rounded-xl shadow-card border-l-4 border-secondary">
            <div className="flex justify-between items-start mb-3">
                <h3 className="text-xl font-bold text-dark flex items-center">
                    <LightbulbIcon className="w-6 h-6 mr-3 text-secondary" />
                    Pandangan AI
                </h3>
                <button onClick={onGenerate} disabled={isLoading} className="text-sm bg-secondary text-white px-3 py-1.5 rounded-md hover:bg-yellow-800 disabled:bg-gray-400 flex items-center gap-2">
                    <SparklesIcon className="w-4 h-4" />
                    Jana Baru
                </button>
            </div>
            {isLoading && !insight && <div className="h-20 flex items-center justify-center"><Spinner /></div>}
            {!isLoading && !insight && <p className="text-gray-500 text-sm text-center py-5">Klik "Jana Baru" untuk mendapatkan cadangan daripada AI.</p>}
            {insight && (
                 <div className="bg-light p-4 rounded-lg animate-fade-in">
                    <span className="font-semibold text-xs text-dark bg-secondary/20 px-2 py-0.5 rounded-full">{insight.category}</span>
                    <p className="text-lg font-semibold text-dark mt-2">{insight.title}</p>
                    <p className="text-sm text-gray-700">{insight.suggestion}</p>
                </div>
            )}
        </div>
    );
};

const KhairatActionCard: React.FC<{
    tasks: KhairatTask[];
    onProcess: (task: KhairatTask) => void;
}> = ({ tasks, onProcess }) => {
    const pendingTasks = tasks.filter(t => t.status === 'Menunggu Tindakan');

    if (pendingTasks.length === 0) {
        return null;
    }

    return (
        <div className="bg-rose-50 p-6 rounded-xl shadow-card border-l-4 border-rose-500">
            <h3 className="text-xl font-bold text-dark mb-4 flex items-center">
                <HeartCrackIcon className="w-6 h-6 mr-3 text-rose-600" />
                Tindakan Khairat Kematian
            </h3>
            <div className="space-y-3">
                {pendingTasks.map(task => (
                    <div key={task.id} className="bg-white p-4 rounded-lg flex justify-between items-center shadow-sm">
                        <div>
                            <p className="font-semibold text-gray-800">
                                {task.type === 'Tanggungan' ? task.dependentName : task.memberName}
                            </p>
                            {task.type === 'Tanggungan' && (
                                <p className="text-xs text-gray-500">Tanggungan kepada {task.memberName}</p>
                            )}
                            <p className="text-xs text-gray-500">Dilaporkan pada: {new Date(task.deathDate).toLocaleDateString('ms-MY')}</p>
                        </div>
                        <button 
                            onClick={() => onProcess(task)}
                            className="bg-primary text-white text-sm px-3 py-1.5 rounded-md hover:bg-dark transition-colors flex items-center gap-2"
                        >
                            <CheckCircleIcon className="w-4 h-4" />
                            Proses Bayaran (RM {task.amount.toFixed(2)})
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};


const Dashboard: React.FC<{ setActivePage: (page: Page) => void; viewPending: () => void; }> = ({ setActivePage, viewPending }) => {
    const [allMembers, setAllMembers] = useState<Member[]>([]);
    const [announcements, setAnnouncements] = useState<Announcement[]>([]);
    const [schedule, setSchedule] = useState<Duty[]>([]);
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [khairatTasks, setKhairatTasks] = useState<KhairatTask[]>([]);
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { addToast } = useToast();
    
    // AI Insight state
    const [aiInsight, setAiInsight] = useState<AIInsight | null>(null);
    const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);


    const handleGenerateInsight = async () => {
        setIsGeneratingInsight(true);
        setAiInsight(null);
        try {
            // Compile a data summary for the AI
            const pendingMembersCount = allMembers.filter(m => m.status === 'Menunggu Pengesahan').length;
            const totalDonations = transactions.filter(t => t.type === 'Derma').reduce((sum, t) => sum + t.amount, 0);
            const totalExpenses = transactions.filter(t => t.type === 'Perbelanjaan').reduce((sum, t) => sum + t.amount, 0);
            
            const summary = `
                Kewangan: Kutipan derma RM${totalDonations.toFixed(2)}, perbelanjaan RM${Math.abs(totalExpenses).toFixed(2)}.
                Keahlian: ${allMembers.length} ahli aktif, ${pendingMembersCount} permohonan baru.
                Tugasan: ${khairatTasks.filter(t => t.status === 'Menunggu Tindakan').length} tugasan khairat belum selesai.
            `;
            
            const result = await generateDashboardInsight(summary);
            if (typeof result === 'string') {
                addToast(result, 'error');
            } else {
                setAiInsight(result);
            }
        } catch (err) {
            addToast("Gagal menjana pandangan AI.", "error");
        } finally {
            setIsGeneratingInsight(false);
        }
    };
    
    const fetchData = async () => {
        try {
            setIsLoading(true);
            const [membersData, announcementsData, scheduleData, transactionsData, tasksData, infoData] = await Promise.all([
                getMembers(),
                getAnnouncements(),
                getSchedule(),
                getTransactions(),
                getKhairatTasks(),
                getSurauInfo(),
            ]);
            setAllMembers(membersData);
            setAnnouncements(announcementsData);
            setSchedule(scheduleData);
            setTransactions(transactionsData);
            setKhairatTasks(tasksData);
            setSurauInfo(infoData);
            
            // Generate initial insight after fetching data
            if (process.env.API_KEY) {
                const pendingMembersCount = membersData.filter(m => m.status === 'Menunggu Pengesahan').length;
                const totalDonations = transactionsData.filter(t => t.type === 'Derma').reduce((sum, t) => sum + t.amount, 0);
                const totalExpenses = transactionsData.filter(t => t.type === 'Perbelanjaan').reduce((sum, t) => sum + t.amount, 0);
                
                const summary = `
                    Kewangan: Kutipan derma RM${totalDonations.toFixed(2)}, perbelanjaan RM${Math.abs(totalExpenses).toFixed(2)}.
                    Keahlian: ${membersData.length} ahli aktif, ${pendingMembersCount} permohonan baru.
                    Tugasan: ${tasksData.filter(t => t.status === 'Menunggu Tindakan').length} tugasan khairat belum selesai.
                `;
                 const result = await generateDashboardInsight(summary);
                 if (typeof result !== 'string') {
                    setAiInsight(result);
                }
            }

        } catch (err) {
            console.error("Failed to load dashboard data:", err);
            setError("Gagal memuatkan data papan pemuka. Sila cuba lagi.");
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleProcessKhairatPayment = async (task: KhairatTask) => {
        const updatedTasks = khairatTasks.map(t => 
            t.id === task.id ? { ...t, status: 'Selesai' as const, processedDate: new Date().toISOString() } : t
        );
        
        const description = task.type === 'Tanggungan' 
            ? `Bayaran Khairat Kematian untuk Arwah ${task.dependentName} (Tanggungan ${task.memberName})`
            : `Bayaran Khairat Kematian untuk Arwah ${task.memberName}`;

        const newTransaction: Transaction = {
            id: `TXN-KRT${Date.now()}`,
            date: new Date().toISOString(),
            description: description,
            type: 'Perbelanjaan',
            amount: -task.amount,
            category: 'Sumbangan Luar',
        };
        const updatedTransactions = [newTransaction, ...transactions];

        try {
            await saveKhairatTasks(updatedTasks);
            await saveTransactions(updatedTransactions);
            setKhairatTasks(updatedTasks);
            setTransactions(updatedTransactions);
            addToast(`Bayaran khairat untuk ${task.type === 'Tanggungan' ? `Arwah ${task.dependentName}` : `Arwah ${task.memberName}`} telah berjaya diproses.`);
        } catch (err) {
            addToast("Gagal memproses bayaran khairat.", "error");
        }
    };

    if (isLoading) {
        return <Spinner />;
    }

    if (error || !surauInfo) {
        return <div className="text-center text-red-600 p-10">{error || "Gagal memuatkan data surau."}</div>;
    }
    
    const activeMembers = allMembers.filter(m => m.status === 'Aktif');
    const pendingMembersCount = allMembers.filter(m => m.status === 'Menunggu Pengesahan').length;

    const totalDonations = transactions
        .filter(t => t.type === 'Derma')
        .reduce((sum, t) => sum + t.amount, 0);

    const today = new Date().toLocaleDateString('ms-MY', { weekday: 'long' });
    const todayDuty = schedule.find(d => d.day === today) as Duty | undefined;

    const currentYear = new Date().getFullYear();
    const khairatStats = activeMembers.reduce(
        (acc, member) => {
            const payment = member.khairatPayments.find(p => p.year === currentYear);
            if (payment && payment.status === 'Lunas') {
                acc.Lunas += 1;
            } else {
                acc.Tertunggak += 1;
            }
            return acc;
        }, { Lunas: 0, Tertunggak: 0 }
    );
    
    const pieData = [
        { name: 'Lunas', value: khairatStats.Lunas },
        { name: 'Tertunggak', value: khairatStats.Tertunggak },
    ];
    
    const PIE_COLORS = ['#065f46', '#fca5a5'];

    return (
        <div className="space-y-8">
            {/* Stat Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                    icon={<UsersIcon className="w-8 h-8 text-primary"/>} 
                    title="Jumlah Ahli Aktif" 
                    value={activeMembers.length.toString()}
                    onClick={() => setActivePage(Page.Kariah)}
                />
                <StatCard 
                    icon={<DollarSignIcon className="w-8 h-8 text-primary"/>} 
                    title="Derma Terkumpul" 
                    value={`RM ${totalDonations.toFixed(2)}`}
                    onClick={() => setActivePage(Page.Kewangan)}
                />
                <StatCard 
                    icon={<MegaphoneIcon className="w-8 h-8 text-primary"/>} 
                    title="Aktiviti & Galeri" 
                    value={`${announcements.length} Pengumuman`}
                    onClick={() => setActivePage(Page.Aktiviti)}
                />
                <StatCard 
                    icon={<ClockIcon className="w-8 h-8 text-yellow-600"/>} 
                    title="Permohonan Baru" 
                    value={pendingMembersCount.toString()}
                    onClick={viewPending}
                    className="bg-yellow-50 border-l-4 border-yellow-400"
                />
            </div>
            
            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column */}
                <div className="lg:col-span-2 space-y-8">
                    <AIInsightCard insight={aiInsight} isLoading={isGeneratingInsight} onGenerate={handleGenerateInsight} />
                    <KhairatActionCard tasks={khairatTasks} onProcess={handleProcessKhairatPayment} />
                     {/* Khairat Status */}
                    <div className="bg-white p-6 rounded-xl shadow-card">
                        <h3 className="text-xl font-bold text-dark mb-4">Status Khairat Kematian {currentYear}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                            <div className="h-64">
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} fill="#8884d8" paddingAngle={5} dataKey="value">
                                            {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} /> )}
                                        </Pie>
                                        <Tooltip formatter={(value) => `${value} ahli`} />
                                        <Legend />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>
                            <div className="text-center md:text-left">
                                <h4 className="text-4xl font-bold text-dark">{`${khairatStats.Lunas} / ${activeMembers.length}`}</h4>
                                <p className="text-gray-600">Ahli telah membuat bayaran</p>
                                <p className="mt-4 text-sm text-gray-500">
                                    Ini adalah ringkasan bayaran yuran khairat kematian untuk tahun semasa. Sila rujuk modul Ahli Kariah untuk butiran lanjut.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right Column */}
                <div className="space-y-8">
                     {/* Jadual Bertugas */}
                    <div className="bg-white p-6 rounded-xl shadow-card">
                        <h3 className="text-xl font-bold text-dark mb-4">Jadual Bertugas Hari Ini ({today})</h3>
                        {todayDuty ? (
                             <ul className="space-y-3">
                                {Object.entries(todayDuty).filter(([key]) => key !== 'day').map(([waktu, petugas]) => (
                                    <li key={waktu} className="flex justify-between items-center text-sm p-2 rounded-md even:bg-gray-50">
                                        <span className="font-semibold capitalize text-primary">{waktu}</span>
                                        <div className="text-right">
                                            <p className="font-medium text-gray-800">{(petugas as any).imam}</p>
                                            <p className="text-xs text-gray-500">{(petugas as any).bilal} (Bilal)</p>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-gray-500 text-center py-4">Tiada jadual untuk hari ini.</p>
                        )}
                    </div>

                     {/* Pengumuman */}
                    <div className="bg-white p-6 rounded-xl shadow-card">
                        <h3 className="text-xl font-bold text-dark mb-4">Pengumuman Terkini</h3>
                        <ul className="space-y-4">
                            {announcements.slice(0, 3).map(ann => (
                                <li key={ann.id} className="border-b border-gray-100 pb-3 last:border-b-0">
                                    <h4 className="font-semibold text-gray-800">{ann.title}</h4>
                                    <p className="text-xs text-gray-500">{new Date(ann.date).toLocaleDateString('ms-MY')}</p>
                                </li>
                            ))}
                             {announcements.length === 0 && <p className="text-gray-500 text-center py-4">Tiada pengumuman terkini.</p>}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;