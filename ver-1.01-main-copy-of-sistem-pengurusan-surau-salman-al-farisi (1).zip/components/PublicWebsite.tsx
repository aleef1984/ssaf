import React, { useState, useMemo, useEffect } from 'react';
import { getSurauInfo, getAnnouncements, getSchedule, getAlbums, saveMembers, getMembers, getCommittee, getElectionSessions, saveElectionSessions, getNominations, saveNominations, getFacilities, saveBookings, getBookings, createToyyibpayBill, getQurbanSessions, saveQurbanParticipants, getQurbanParticipants, saveTransactions, getTransactions, getClassSessions } from '../services/dataService';
import { ViewMode, Member, Dependent, Album, SurauInfo, Announcement, Duty, CommitteeMember, ElectionSession, Nomination, Candidate, Facility, Booking, QurbanSession, QurbanParticipant, Transaction, ClassSession, Photo } from '../types';
import { FacebookIcon, TiktokIcon, CloseIcon, CreditCardIcon, BookOpenIcon, MegaphoneIcon, CalendarIcon, ClockIcon } from './icons';
import Lightbox from './Lightbox';
import { useToast } from '../App';
import DynamicLogo from './DynamicLogo';
import Spinner from './Spinner';
import WaktuSolat from './WaktuSolat';

type FormDependent = Omit<Dependent, 'id' | 'status'> & { id?: number, status?: 'Hidup' | 'Meninggal Dunia' };
type ActivityItem = { type: 'announcement', data: Announcement, date: Date } | { type: 'class', data: ClassSession, date: Date };

// --- Reusable Components ---
const QurbanRegistrationForm: React.FC<{ session: QurbanSession }> = ({ session }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [parts, setParts] = useState(1);
    const [isProcessing, setIsProcessing] = useState(false);

    const totalAmount = parts * session.pricePerPart;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (parts <= 0 || !name.trim() || !phone.trim()) {
            addToast("Sila isi semua maklumat pendaftaran.", "error"); return;
        }
        setIsProcessing(true);
        try {
            const participants = await getQurbanParticipants();
            const newParticipant: QurbanParticipant = { id: Date.now(), sessionId: session.id, name, phone, email, parts, totalAmount, paymentStatus: 'Belum Bayar', registrationDate: new Date().toISOString() };
            const { billCode, billpaymentUrl } = await createToyyibpayBill({ userName: name, userEmail: email || 'pesertakorban@surau.my', userPhone: phone, billAmount: totalAmount, billDescription: `Bayaran ${parts} bahagian korban untuk ${session.title}` });
            newParticipant.billCode = billCode;
            await saveQurbanParticipants([...participants, newParticipant]);
            const transactions = await getTransactions();
            const newTransaction: Transaction = { id: `TXN-QBN-${Date.now()}`, date: new Date().toISOString(), description: `Penyertaan Korban: ${name} (${parts} bahagian)`, type: 'Derma', amount: totalAmount, category: 'Korban & Aqiqah', payerName: name };
            await saveTransactions([...transactions, newTransaction]);
            addToast("Pendaftaran diterima! Anda akan dihalakan ke halaman pembayaran...", "info");
            window.location.href = billpaymentUrl;
        } catch (error) {
            const errorMessage = (error instanceof Error) ? error.message : "Gagal memproses pendaftaran korban.";
            addToast(errorMessage, "error");
            console.error("Qurban Registration Error:", error);
            setIsProcessing(false);
        }
    };

    return (
        <section id="qurban" className="bg-emerald-50 py-16">
            <div className="container mx-auto px-6">
                 <h2 className="text-3xl font-bold text-center mb-8 text-dark">Program Korban & Aqiqah</h2>
                <div className="bg-white p-8 rounded-xl shadow-lg border w-full max-w-lg mx-auto">
                    <h3 className="text-xl font-bold text-dark text-center mb-1">{session.title}</h3>
                    <p className="text-center text-secondary font-semibold mb-6">Harga: RM {session.pricePerPart.toFixed(2)} / bahagian</p>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div><label>Nama Penuh (Untuk Sijil)</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full mt-1 p-3 border rounded-lg" required /></div>
                        <div><label>No. Telefon</label><input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full mt-1 p-3 border rounded-lg" required /></div>
                        <div><label>Emel (Pilihan)</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full mt-1 p-3 border rounded-lg" /></div>
                        <div><label>Bilangan Bahagian</label><input type="number" min="1" value={parts} onChange={e => setParts(Number(e.target.value))} className="w-full mt-1 p-3 border rounded-lg" required /></div>
                        <div className="text-center p-4 bg-gray-100 rounded-lg"><p className="text-gray-600">Jumlah Bayaran:</p><p className="text-3xl font-bold text-primary">RM {totalAmount.toFixed(2)}</p></div>
                        <button type="submit" disabled={isProcessing} className="w-full flex items-center justify-center gap-3 bg-primary text-white p-3 rounded-lg hover:bg-dark transition-colors text-base font-bold disabled:bg-gray-400">{isProcessing ? "Memproses..." : "Daftar & Bayar"}</button>
                    </form>
                </div>
            </div>
        </section>
    );
};

const OnlineDonationForm: React.FC = () => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [amount, setAmount] = useState<number | ''>('');
    const [isProcessing, setIsProcessing] = useState(false);
    const presetAmounts = [10, 20, 50, 100];
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (amount === '' || amount <= 0) { addToast("Sila masukkan amaun derma yang sah.", "error"); return; }
        setIsProcessing(true);
        try {
            const { billpaymentUrl } = await createToyyibpayBill({ userName: name || 'Hamba Allah', userEmail: email || 'penderma@surau.my', userPhone: '0123456789', billAmount: amount, billDescription: `Sumbangan Ikhlas kepada Surau Salman Al-Farisi` });
            addToast("Anda akan dihalakan ke halaman pembayaran...", "info");
            window.location.href = billpaymentUrl;
        } catch (error) {
            const errorMessage = (error instanceof Error) ? error.message : "Gagal memproses pembayaran.";
            addToast(errorMessage, "error");
            console.error("ToyyibPay Error:", error);
            setIsProcessing(false);
        }
    };
    return (
        <div className="bg-white p-8 rounded-xl shadow-lg border w-full max-w-lg mx-auto">
            <h3 className="text-xl font-bold text-dark text-center mb-4">Derma Secara Dalam Talian</h3>
            <p className="text-center text-sm text-gray-600 mb-6">Sumbangan anda amat kami hargai. Sila isi maklumat di bawah.</p>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="text-sm font-medium text-gray-700">Amaun Derma (RM)</label>
                    <input type="number" step="1" min="1" value={amount} onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))} className="w-full mt-1 p-3 border border-gray-300 rounded-lg text-lg font-bold" placeholder="0.00" required />
                    <div className="flex gap-2 mt-2">
                        {presetAmounts.map(preset => (<button type="button" key={preset} onClick={() => setAmount(preset)} className="flex-1 text-sm bg-gray-100 p-2 rounded-md hover:bg-primary/10 transition-colors">RM{preset}</button>))}
                    </div>
                </div>
                <div><label className="text-sm font-medium text-gray-700">Nama Penderma (Pilihan)</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full mt-1 p-3 border border-gray-300 rounded-lg" placeholder="Hamba Allah"/></div>
                <div><label className="text-sm font-medium text-gray-700">Emel (Pilihan, untuk rujukan)</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full mt-1 p-3 border border-gray-300 rounded-lg" placeholder="penderma@surau.my"/></div>
                <button type="submit" disabled={isProcessing} className="w-full flex items-center justify-center gap-3 bg-primary text-white p-3 rounded-lg hover:bg-dark transition-colors text-base font-bold disabled:bg-gray-400">{isProcessing ? "Memproses..." : <><CreditCardIcon className="w-6 h-6"/> Teruskan Pembayaran</>}</button>
            </form>
        </div>
    );
};

const SelfRegistrationModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [icNumber, setIcNumber] = useState('');
    const [address, setAddress] = useState('');
    const [phone, setPhone] = useState('');
    const [isSubmitted, setIsSubmitted] = useState(false);
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !icNumber || !address || !phone) { addToast('Sila isi semua maklumat peribadi.', 'error'); return; }
        try {
            const allMembers = await getMembers();
            const newMember: Member = { id: allMembers.length > 0 ? Math.max(...allMembers.map(m => m.id)) + 1 : 1, name, icNumber, address, phone, joinDate: new Date().toISOString().split('T')[0], status: 'Menunggu Pengesahan', dependents: [], khairatPayments: [] };
            await saveMembers([...allMembers, newMember]);
            setIsSubmitted(true);
            addToast('Permohonan anda telah berjaya dihantar!', 'success');
        } catch (err) { addToast('Gagal menghantar permohonan.', 'error'); console.error(err); }
    };
    if (isSubmitted) return (<div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4"><div className="bg-white rounded-lg shadow-xl w-full max-w-lg text-center p-8"><h2 className="text-2xl font-bold text-primary mb-4">Permohonan Diterima!</h2><p className="text-gray-700 mb-6">Terima kasih. Permohonan anda akan disemak oleh AJK Surau.</p><button onClick={onClose} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark">Tutup</button></div></div>)
    return (<div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4"><div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col"><form onSubmit={handleSubmit} className="flex flex-col h-full"><div className="p-6 border-b flex justify-between items-center"><h2 className="text-2xl font-bold text-dark">Pendaftaran Ahli Kariah Baru</h2><button type="button" onClick={onClose}><CloseIcon/></button></div><div className="p-6 overflow-y-auto space-y-4"><h3 className="font-semibold text-primary">Maklumat Peribadi</h3><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><div><label>Nama Penuh</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full p-2 border rounded" required /></div><div><label>No. K/P</label><input type="text" value={icNumber} onChange={e => setIcNumber(e.target.value)} className="mt-1 block w-full p-2 border rounded" required /></div><div><label>No. Telefon</label><input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="mt-1 block w-full p-2 border rounded" required /></div><div className="md:col-span-2"><label>Alamat</label><textarea value={address} onChange={e => setAddress(e.target.value)} rows={3} className="mt-1 block w-full p-2 border rounded" required /></div></div></div><div className="p-6 bg-gray-50 text-right rounded-b-lg border-t mt-auto"><button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg mr-2">Batal</button><button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg">Hantar</button></div></form></div></div>);
};

// --- Main Component ---
const PublicWebsite: React.FC<{ setViewMode: (mode: ViewMode) => void; }> = ({ setViewMode }) => {
    const [data, setData] = useState<{ surauInfo: SurauInfo | null; announcements: Announcement[]; schedule: Duty[]; albums: Album[]; committee: CommitteeMember[]; classSessions: ClassSession[]; transactions: Transaction[] }>({ surauInfo: null, announcements: [], schedule: [], albums: [], committee: [], classSessions: [], transactions: [] });
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [lightboxOpen, setLightboxOpen] = useState<{ photos: Photo[], startIndex: number } | null>(null);
    const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
    const [qurbanSession, setQurbanSession] = useState<QurbanSession | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [info, announce, sched, alb, com, sessions, qurban, trans] = await Promise.all([ getSurauInfo(), getAnnouncements(), getSchedule(), getAlbums(), getCommittee(), getClassSessions(), getQurbanSessions(), getTransactions() ]);
                setData({ surauInfo: info, announcements: announce, schedule: sched, albums: alb, committee: com, classSessions: sessions, transactions: trans });
                setQurbanSession(qurban.find(s => s.status === 'Buka') || null);
            } catch (err) {
                setError("Gagal memuatkan laman web. Sila cuba sebentar lagi."); console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const { surauInfo } = data;

    const { upcomingKuliah, activityFeed } = useMemo(() => {
        const today = new Date();
        today.setHours(0,0,0,0);
        const upcomingKuliah = data.classSessions
            .filter(cs => cs.date ? new Date(cs.date) >= today : true)
            .sort((a,b) => (a.date ? new Date(a.date).getTime() : Infinity) - (b.date ? new Date(b.date).getTime() : Infinity))[0];
        
        const announcementItems: ActivityItem[] = data.announcements.map(a => ({ type: 'announcement', data: a, date: new Date(a.date) }));
        const classItems: ActivityItem[] = data.classSessions.map(c => ({ type: 'class', data: c, date: c.date ? new Date(c.date) : new Date() }));
        const activityFeed = [...announcementItems, ...classItems].sort((a, b) => b.date.getTime() - a.date.getTime());
        
        return { upcomingKuliah, activityFeed };
    }, [data.classSessions, data.announcements]);
    
    const totalFund = useMemo(() => {
        return data.transactions.reduce((sum, t) => sum + t.amount, 0);
    }, [data.transactions]);

    const renderActivityCard = (item: ActivityItem) => {
        const iconClass = "w-6 h-6 text-primary flex-shrink-0";
        if (item.type === 'announcement') {
            return (
                <div key={`ann-${item.data.id}`} className="flex items-start space-x-4">
                    <div className="bg-primary/10 p-3 rounded-full"><MegaphoneIcon className={iconClass}/></div>
                    <div>
                        <p className="text-sm text-gray-500">Pengumuman • {item.date.toLocaleDateString('ms-MY')}</p>
                        <h4 className="font-bold text-dark">{item.data.title}</h4>
                        <p className="text-sm text-gray-600">{item.data.content}</p>
                    </div>
                </div>
            );
        }
        return (
            <div key={`cls-${item.data.id}`} className="flex items-start space-x-4">
                <div className="bg-primary/10 p-3 rounded-full"><BookOpenIcon className={iconClass}/></div>
                <div>
                    <p className="text-sm text-gray-500">Kuliah • {item.data.isRecurring ? item.data.day : item.date.toLocaleDateString('ms-MY')}</p>
                    <h4 className="font-bold text-dark">{item.data.title}</h4>
                    <p className="text-sm text-gray-600">{item.data.time}</p>
                </div>
            </div>
        );
    };

    if (isLoading) return <div className="min-h-screen flex items-center justify-center"><Spinner /></div>;
    if (error || !surauInfo) return <div className="min-h-screen flex items-center justify-center text-red-600">{error || "Maklumat surau tidak dapat dipaparkan."}</div>;

    return (
        <div className="bg-light text-gray-800 font-sans">
            <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-40">
                <div className="container mx-auto px-6 py-3 flex justify-between items-center">
                    <div className="flex items-center"><DynamicLogo className="w-8 h-8 text-primary"/><span className="ml-3 text-xl font-bold text-dark">{surauInfo.name}</span></div>
                    <nav className="hidden md:flex items-center space-x-6 text-sm">
                        <a href="#activities" className="text-gray-600 hover:text-primary">Aktiviti</a>
                        <a href="#gallery" className="text-gray-600 hover:text-primary">Galeri</a>
                        <a href="#committee" className="text-gray-600 hover:text-primary">Jawatankuasa</a>
                    </nav>
                    <div className="flex items-center space-x-3">
                         <button onClick={() => setViewMode('MemberLogin')} className="text-sm text-gray-600 hover:text-primary px-3 py-2 rounded-md">Log Masuk Ahli</button>
                         <button onClick={() => setViewMode('Login')} className="text-sm text-gray-600 hover:text-primary px-3 py-2 rounded-md">Admin</button>
                         <button onClick={() => document.getElementById('donation-form')?.scrollIntoView({ behavior: 'smooth' })} className="bg-secondary text-white px-4 py-2 rounded-lg hover:bg-yellow-700 transition-colors text-sm font-bold">Derma Sekarang</button>
                    </div>
                </div>
            </header>
            
            <section className="relative text-white py-24 px-6 text-center bg-cover bg-center" style={{backgroundImage: "url('https://images.unsplash.com/photo-1588925964222-ea8c454ce1e4?q=80&w=2070&auto=format&fit=crop')"}}>
                <div className="absolute inset-0 bg-primary/80"></div>
                <div className="relative z-10">
                    <h1 className="text-4xl md:text-5xl font-extrabold mb-4">Selamat Datang ke Surau Salman Al-Farisi</h1>
                    <p className="text-lg font-light max-w-2xl mx-auto">{surauInfo.address}</p>
                    <div className="mt-8 max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4 text-dark">
                         <div className="bg-white/90 p-4 rounded-lg"><p className="text-sm">Kuliah Akan Datang</p><p className="text-2xl font-bold">{upcomingKuliah?.title || 'Tiada maklumat'}</p></div>
                         <div className="bg-white/90 p-4 rounded-lg"><p className="text-sm">Tabung Terkini</p><p className="text-2xl font-bold">RM{totalFund.toFixed(2)}</p></div>
                    </div>
                </div>
            </section>
            
            <main className="container mx-auto px-6 py-16">
                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                     <div className="lg:col-span-2 space-y-12">
                        <section id="activities">
                            <h2 className="text-3xl font-bold mb-6 text-dark">Suapan Aktiviti</h2>
                            <div className="space-y-8 border-l-2 border-primary/20 pl-6">
                                {activityFeed.slice(0, 5).map(item => renderActivityCard(item))}
                            </div>
                        </section>
                        <section id="gallery">
                            <h2 className="text-3xl font-bold mb-6 text-dark">Galeri Foto</h2>
                             <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {data.albums.flatMap(a => a.photos).slice(0, 8).map((p, i) => (
                                    <div key={p.id} className="group relative rounded-xl overflow-hidden shadow-lg cursor-pointer aspect-w-1 aspect-h-1" onClick={() => setLightboxOpen({photos: data.albums.flatMap(a => a.photos), startIndex: i})}>
                                        <img src={p.url} alt={p.caption || ''} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"/>
                                    </div>
                                ))}
                            </div>
                        </section>
                         <section id="committee">
                            <h2 className="text-3xl font-bold mb-6 text-dark">Jawatankuasa Surau</h2>
                             <div className="flex flex-wrap justify-center gap-8">
                                {data.committee.map(member => (<div key={member.id} className="text-center w-32"><img src={member.imageUrl || 'https://via.placeholder.com/100'} alt={member.name} className="w-24 h-24 rounded-full object-cover mb-2 mx-auto ring-4 ring-primary/20"/><h3 className="font-bold text-sm text-dark">{member.name}</h3><p className="text-xs text-secondary font-semibold">{member.position}</p></div>))}
                             </div>
                        </section>
                     </div>
                     <aside className="lg:col-span-1 space-y-8 sticky top-24 self-start">
                         <WaktuSolat />
                          <div className="bg-white p-6 rounded-xl shadow-lg text-center">
                            <h3 className="font-bold text-lg mb-3 text-dark">Ahli Kariah</h3>
                             <p className="text-sm text-gray-600 mb-4">Jadi sebahagian dari komuniti kami. Daftar sebagai ahli kariah untuk menyertai program dan mendapat manfaat khairat kematian.</p>
                             <button onClick={() => setIsRegisterModalOpen(true)} className="w-full bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark transition-colors text-sm font-bold">Daftar Sekarang</button>
                         </div>
                     </aside>
                 </div>
            </main>

            {qurbanSession && <QurbanRegistrationForm session={qurbanSession} />}

            <section id="donation-form" className="py-16">
                 <div className="container mx-auto px-6">
                    <OnlineDonationForm />
                </div>
            </section>
            
            <footer className="bg-dark text-white"><div className="container mx-auto px-6 py-8"><div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left"><div><h3 className="text-lg font-bold">{surauInfo.name}</h3><p className="text-sm text-gray-400">{surauInfo.address}</p></div><div className="mt-4 md:mt-0"><p className="text-sm text-gray-400 mb-2">Ikuti kami:</p><div className="flex justify-center md:justify-start space-x-4"><a href="#" className="hover:text-primary"><FacebookIcon/></a><a href="#" className="hover:text-primary"><TiktokIcon/></a></div></div></div><div className="mt-8 border-t border-gray-700 pt-6 text-center text-sm text-gray-500"><p>&copy; {new Date().getFullYear()} Jawatankuasa Penaja Surau Salman Al-Farisi.</p></div></div></footer>
            
            {lightboxOpen && <Lightbox photos={lightboxOpen.photos} startIndex={lightboxOpen.startIndex} onClose={() => setLightboxOpen(null)} />}
            {isRegisterModalOpen && <SelfRegistrationModal onClose={() => setIsRegisterModalOpen(false)}/>}
        </div>
    );
};

export default PublicWebsite;