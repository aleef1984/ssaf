import React, { useMemo, useState, useEffect } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts';
import { getTransactions, saveTransactions, getFinanceCategories, getSurauInfo, getMembers, saveAssets, getAssets } from '../services/dataService';
import { Transaction, FinanceCategories, SurauInfo, Member, Asset } from '../types';
import { CloseIcon, TrashIcon, DownloadIcon } from './icons';
import { useToast, usePrint } from '../App';
import DynamicLogo from './DynamicLogo';
import Spinner from './Spinner';
import { AssetFormModal } from './Aset';


// Confirmation Modal for destructive actions
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
    confirmText?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan", confirmText = "Padam" }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <div className="p-6 border-b">
                    <h2 className="text-xl font-bold text-dark">{title}</h2>
                </div>
                <div className="p-6">
                    <p className="text-gray-700">{message}</p>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors">Batal</button>
                    <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">{confirmText}</button>
                </div>
            </div>
        </div>
    );
};

// Modal for a single transaction receipt
const ReceiptModal: React.FC<{
    onClose: () => void;
    transaction: Transaction;
    surauInfo: SurauInfo;
}> = ({ onClose, transaction, surauInfo }) => {
    const { isPrinting, handlePrint } = usePrint();

    return (
        <div className={`fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4 ${!isPrinting ? 'print-hidden' : ''}`}>
            <div className={`bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col ${isPrinting ? 'print-container' : ''}`}>
                 <div className="p-6 border-b flex justify-between items-center print-hidden">
                    <h2 className="text-xl font-bold text-dark">Resit Rasmi</h2>
                    <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500 transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <div className="p-8 overflow-y-auto" id="receipt-content">
                    {/* Receipt Header */}
                    <div className="text-center mb-8 pb-4 border-b-2 border-dashed">
                        <DynamicLogo className="w-12 h-12 text-primary mx-auto object-contain"/>
                        <h1 className="text-xl font-bold text-dark mt-2">{surauInfo.name}</h1>
                        <p className="text-xs text-gray-500">{surauInfo.address}</p>
                    </div>

                    {/* Receipt Details */}
                    <div className="space-y-4 text-sm">
                        <div className="flex justify-between">
                            <span className="text-gray-500">No. Resit:</span>
                            <span className="font-mono font-bold">{transaction.id}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-gray-500">Tarikh:</span>
                            <span className="font-medium">{new Date(transaction.date).toLocaleDateString('ms-MY', { day: '2-digit', month: 'long', year: 'numeric'})}</span>
                        </div>
                        {transaction.payerName && (
                        <div className="flex justify-between">
                            <span className="text-gray-500">Diterima Daripada:</span>
                            <span className="font-medium">{transaction.payerName}</span>
                        </div>
                        )}
                        <div className="flex justify-between items-start">
                            <span className="text-gray-500">Keterangan:</span>
                            <span className="font-medium text-right ml-4">{transaction.description}</span>
                        </div>
                         <div className="flex justify-between">
                            <span className="text-gray-500">Kategori:</span>
                            <span className="font-medium">{transaction.category}</span>
                        </div>
                         <div className="flex justify-between text-lg font-bold text-dark mt-6 pt-4 border-t">
                            <span>Jumlah:</span>
                            <span className={transaction.amount > 0 ? 'text-primary' : 'text-red-600'}>RM {Math.abs(transaction.amount).toFixed(2)}</span>
                        </div>
                    </div>

                     <p className="text-center text-xs text-gray-500 mt-8">Ini adalah resit janaan komputer. Terima kasih atas sumbangan/urusan anda.</p>
                </div>
                 <div className="p-6 bg-gray-50 text-right rounded-b-lg border-t mt-auto print-hidden">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 mr-2">Tutup</button>
                    <button type="button" onClick={handlePrint} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Cetak Resit</button>
                </div>
            </div>
        </div>
    );
}

const TransactionFormModal: React.FC<{ 
    onClose: () => void; 
    onSave: (data: Omit<Transaction, 'id'>, recordAsAsset: boolean) => void;
    categories: FinanceCategories;
    activeMembers: Member[];
}> = ({ onClose, onSave, categories, activeMembers }) => {
    const { addToast } = useToast();
    const [type, setType] = useState<'Derma' | 'Perbelanjaan'>('Derma');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [description, setDescription] = useState('');
    const [amount, setAmount] = useState<number | ''>('');
    const [category, setCategory] = useState('');
    const [recordAsAsset, setRecordAsAsset] = useState(false);

    const [selectedMemberId, setSelectedMemberId] = useState<string>('awam');
    const [publicPayerName, setPublicPayerName] = useState('');

    const handleTypeChange = (newType: 'Derma' | 'Perbelanjaan') => {
        setType(newType);
        setCategory(''); // Reset category when type changes
        if (newType === 'Derma') {
            setRecordAsAsset(false);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!description || amount === '' || amount <= 0 || !category) {
            addToast('Sila isi semua medan dengan betul, termasuk kategori.', 'error');
            return;
        }
        const finalAmount = type === 'Perbelanjaan' ? -Math.abs(amount) : Math.abs(amount);
        
        let memberId: number | undefined = undefined;
        let payerName: string | undefined = undefined;

        if (type === 'Derma') {
            if (selectedMemberId === 'awam') {
                payerName = publicPayerName.trim() || 'Penderma Awam';
            } else {
                const selectedMember = activeMembers.find(m => m.id === parseInt(selectedMemberId, 10));
                if (selectedMember) {
                    memberId = selectedMember.id;
                    payerName = selectedMember.name;
                }
            }
        }
        
        onSave({ type, date, description, amount: finalAmount, category, memberId, payerName }, recordAsAsset);
    };
    
    const currentCategories = type === 'Derma' ? categories.income : categories.expense;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 border-b flex justify-between items-center">
                        <h2 className="text-xl font-bold text-dark">Tambah Transaksi Baru</h2>
                        <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500 transition-colors">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="p-6 space-y-4 overflow-y-auto">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <div>
                                <label className="block text-sm font-medium text-gray-700">Jenis Transaksi</label>
                                <select value={type} onChange={e => handleTypeChange(e.target.value as any)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md">
                                    <option value="Derma">Derma (Pendapatan)</option>
                                    <option value="Perbelanjaan">Perbelanjaan</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Kategori</label>
                                <select value={category} onChange={e => setCategory(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required>
                                     <option value="" disabled>Pilih Kategori</option>
                                     {currentCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                                </select>
                            </div>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-700">Tarikh</label>
                            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Keterangan</label>
                            <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="cth: Derma Jumaat, Bayaran bil air" className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-700">Jumlah (RM)</label>
                            <input type="number" step="0.01" value={amount} onChange={e => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        {type === 'Perbelanjaan' && (
                             <div className="flex items-center p-3 bg-blue-50 border border-blue-200 rounded-md">
                                <input
                                    type="checkbox"
                                    id="recordAsAsset"
                                    checked={recordAsAsset}
                                    onChange={(e) => setRecordAsAsset(e.target.checked)}
                                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                />
                                <label htmlFor="recordAsAsset" className="ml-3 block text-sm font-medium text-gray-900">
                                    Rekod perbelanjaan ini sebagai Aset / Inventori baru?
                                </label>
                            </div>
                        )}
                        {type === 'Derma' && (
                            <div className="space-y-4 p-4 bg-gray-50 rounded-md border">
                                <h4 className="font-semibold text-gray-800">Maklumat Penderma (Pilihan)</h4>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Penderma</label>
                                    <select value={selectedMemberId} onChange={e => setSelectedMemberId(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md">
                                        <option value="awam">Penderma Awam / Tidak Dikenali</option>
                                        {activeMembers.map(member => (
                                            <option key={member.id} value={member.id.toString()}>{member.name} ({member.icNumber})</option>
                                        ))}
                                    </select>
                                </div>
                                {selectedMemberId === 'awam' && (
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700">Nama Penderma Awam</label>
                                        <input type="text" value={publicPayerName} onChange={e => setPublicPayerName(e.target.value)} placeholder="cth: Hamba Allah" className="mt-1 block w-full p-2 border border-gray-300 rounded-md" />
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                    <div className="p-6 bg-gray-50 text-right rounded-b-lg border-t mt-auto">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 mr-2">Batal</button>
                        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Simpan Transaksi</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const FinancialReportModal: React.FC<{
    onClose: () => void;
    transactions: Transaction[];
    totalIncome: number;
    totalExpense: number;
    balance: number;
    surauInfo: SurauInfo;
}> = ({ onClose, transactions, totalIncome, totalExpense, balance, surauInfo }) => {
    const { isPrinting, handlePrint } = usePrint();
    const sortedTransactions = transactions.slice().sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return (
        <div className={`fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4 ${!isPrinting ? 'print-hidden' : ''}`}>
            <div className={`bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col ${isPrinting ? 'print-container' : ''}`}>
                <div>
                    <div className="p-6 border-b flex justify-between items-center print-hidden">
                        <h2 className="text-xl font-bold text-dark">Laporan Kewangan</h2>
                        <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500 transition-colors">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>

                    <div className="p-6 overflow-y-auto">
                        {/* Report Header */}
                        <div className="text-center mb-8">
                           <DynamicLogo className="w-16 h-16 text-primary mx-auto object-contain"/>
                            <h1 className="text-2xl font-bold text-dark mt-2">Laporan Kewangan {surauInfo.name}</h1>
                            <p className="text-gray-600">{surauInfo.address}</p>
                            <p className="text-sm text-gray-500">Laporan dijana pada: {new Date().toLocaleDateString('ms-MY', { dateStyle: 'full' })}</p>
                        </div>

                        {/* Financial Summary */}
                        <div className="grid grid-cols-3 gap-4 mb-8 print-no-break">
                            <div className="bg-green-100 p-4 rounded-lg text-center border border-green-200">
                                <p className="text-sm font-medium text-green-700">Jumlah Derma</p>
                                <p className="text-2xl font-bold text-green-800">RM {totalIncome.toFixed(2)}</p>
                            </div>
                            <div className="bg-red-100 p-4 rounded-lg text-center border border-red-200">
                                <p className="text-sm font-medium text-red-700">Jumlah Perbelanjaan</p>
                                <p className="text-2xl font-bold text-red-800">RM {Math.abs(totalExpense).toFixed(2)}</p>
                            </div>
                            <div className="bg-blue-100 p-4 rounded-lg text-center border border-blue-200">
                                <p className="text-sm font-medium text-blue-700">Baki Keseluruhan</p>
                                <p className="text-2xl font-bold text-blue-800">RM {balance.toFixed(2)}</p>
                            </div>
                        </div>

                        {/* Transaction List */}
                        <div>
                             <h3 className="text-lg font-bold text-dark mb-4 border-b pb-2">Penyata Transaksi Terperinci</h3>
                             <table className="w-full text-sm">
                                <thead className="bg-gray-100">
                                    <tr>
                                        <th className="px-4 py-2 text-left font-semibold text-gray-600">Tarikh</th>
                                        <th className="px-4 py-2 text-left font-semibold text-gray-600">Keterangan</th>
                                        <th className="px-4 py-2 text-left font-semibold text-gray-600">Kategori</th>
                                        <th className="px-4 py-2 text-right font-semibold text-gray-600">Jumlah (RM)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sortedTransactions.map(t => (
                                        <tr key={t.id} className="border-b border-gray-100">
                                            <td className="px-4 py-2">{new Date(t.date).toLocaleDateString('ms-MY')}</td>
                                            <td className="px-4 py-2 text-gray-800">{t.description}</td>
                                            <td className="px-4 py-2 text-gray-500">{t.category || '-'}</td>
                                            <td className={`px-4 py-2 text-right font-medium ${t.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                                {t.amount.toFixed(2)}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                             </table>
                             {sortedTransactions.length === 0 && <p className="text-center text-gray-500 py-4">Tiada transaksi untuk dipaparkan.</p>}
                        </div>
                    </div>
                     <div className="p-6 bg-gray-50 text-right rounded-b-lg border-t mt-auto print-hidden">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 mr-2">Tutup</button>
                        <button type="button" onClick={handlePrint} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Cetak Laporan</button>
                    </div>
                </div>
            </div>
        </div>
    );
}

const Kewangan: React.FC = () => {
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [financeCategories, setFinanceCategories] = useState<FinanceCategories | null>(null);
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);
    const [activeMembers, setActiveMembers] = useState<Member[]>([]);
    
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    const [receiptTransaction, setReceiptTransaction] = useState<Transaction | null>(null);
    const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
    const [deletingTransactionId, setDeletingTransactionId] = useState<string | null>(null);
    const [assetModalData, setAssetModalData] = useState<Partial<Asset> | null>(null);
    
    const { addToast } = useToast();

    const fetchData = async () => {
        try {
            setIsLoading(true);
            const [transData, catData, infoData, membersData] = await Promise.all([
                getTransactions(),
                getFinanceCategories(),
                getSurauInfo(),
                getMembers()
            ]);
            setTransactions(transData);
            setFinanceCategories(catData);
            setSurauInfo(infoData);
            setActiveMembers(membersData.filter(m => m.status === 'Aktif'));
        } catch (err) {
            setError("Gagal memuatkan data kewangan.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };
    
    useEffect(() => {
        fetchData();
    }, []);

    const totalIncome = useMemo(() => transactions.filter(t => t.type === 'Derma').reduce((acc, curr) => acc + curr.amount, 0), [transactions]);
    const totalExpense = useMemo(() => transactions.filter(t => t.type === 'Perbelanjaan').reduce((acc, curr) => acc + curr.amount, 0), [transactions]);
    const balance = totalIncome + totalExpense;

    const handleSaveTransaction = async (data: Omit<Transaction, 'id'>, recordAsAsset: boolean) => {
        const newTransaction: Transaction = {
            id: `TXN${Date.now()}`,
            ...data
        };
        const updatedTransactions = [newTransaction, ...transactions];
        try {
            await saveTransactions(updatedTransactions);
            setTransactions(updatedTransactions);
            addToast("Transaksi baru telah berjaya direkodkan.");
            setIsModalOpen(false);
            
            if (recordAsAsset) {
                addToast("Sila lengkapkan maklumat aset.", "info");
                setAssetModalData({
                    name: data.description,
                    purchaseDate: data.date,
                    purchaseValue: Math.abs(data.amount),
                    category: data.category
                });
            }
        } catch (err) {
            addToast("Gagal menyimpan transaksi.", "error");
        }
    };
    
    const handleSaveAsset = async (assetData: Omit<Asset, 'id'>) => {
        try {
            const currentAssets = await getAssets();
            const newAsset: Asset = {
                id: currentAssets.length > 0 ? Math.max(...currentAssets.map(a => a.id)) + 1 : 1,
                ...assetData
            };
            await saveAssets([newAsset, ...currentAssets]);
            addToast(`Aset "${newAsset.name}" telah berjaya direkodkan.`);
        } catch (err) {
            addToast("Gagal menyimpan data aset.", "error");
        } finally {
            setAssetModalData(null);
        }
    };

    const handleDeleteTransaction = (id: string) => {
        setDeletingTransactionId(id);
        setIsConfirmDeleteOpen(true);
    };

    const handleConfirmDelete = async () => {
        if (!deletingTransactionId) return;
        const updatedTransactions = transactions.filter(t => t.id !== deletingTransactionId);
        try {
            await saveTransactions(updatedTransactions);
            setTransactions(updatedTransactions);
            addToast("Transaksi telah berjaya dipadam.");
        } catch (err) {
            addToast("Gagal memadam transaksi.", "error");
        } finally {
            setIsConfirmDeleteOpen(false);
            setDeletingTransactionId(null);
        }
    };

    const handleExportTransactions = () => {
        const dataToExport = transactions.map(t => ({
            ID_Transaksi: t.id,
            Tarikh: new Date(t.date).toLocaleDateString('ms-MY'),
            Keterangan: t.description,
            Jenis: t.type,
            Kategori: t.category || 'N/A',
            Penderma: t.payerName || 'N/A',
            Jumlah: t.amount,
        }));

        if (dataToExport.length === 0) {
            addToast('Tiada data untuk dieksport.', 'info');
            return;
        }

        const headers = Object.keys(dataToExport[0]);
        const csvContent = [
            headers.join(','),
            ...dataToExport.map(row => headers.map(header => JSON.stringify(row[header as keyof typeof row])).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `sejarah_transaksi_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        addToast('Data transaksi sedang dimuat turun.', 'success');
    };

    const processedChartData = useMemo(() => {
        const dataByMonth: { [key: string]: { Derma: number; Perbelanjaan: number } } = {};
        const today = new Date();

        for (let i = 11; i >= 0; i--) {
            const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            const monthKey = `${d.toLocaleString('ms-MY', { month: 'short' })} '${d.getFullYear().toString().slice(2)}`;
            dataByMonth[monthKey] = { Derma: 0, Perbelanjaan: 0 };
        }

        transactions.forEach(t => {
            const date = new Date(t.date);
            const monthKey = `${date.toLocaleString('ms-MY', { month: 'short' })} '${date.getFullYear().toString().slice(2)}`;
            if (dataByMonth.hasOwnProperty(monthKey)) {
                if (t.type === 'Derma') {
                    dataByMonth[monthKey].Derma += t.amount;
                } else if (t.type === 'Perbelanjaan') {
                    dataByMonth[monthKey].Perbelanjaan += Math.abs(t.amount);
                }
            }
        });

        return Object.keys(dataByMonth).map(key => ({
            name: key,
            ...dataByMonth[key],
        }));
    }, [transactions]);

    const categoryData = useMemo(() => {
        const reduceByCategory = (type: 'Derma' | 'Perbelanjaan') =>
            transactions
                .filter(t => t.type === type && t.category)
                .reduce((acc, t) => {
                    const key = t.category!;
                    acc[key] = (acc[key] || 0) + Math.abs(t.amount);
                    return acc;
                }, {} as Record<string, number>);

        return {
            income: Object.entries(reduceByCategory('Derma')).map(([name, value]) => ({ name, value })),
            expense: Object.entries(reduceByCategory('Perbelanjaan')).map(([name, value]) => ({ name, value })),
        };
    }, [transactions]);
    
    const COLORS_INCOME = ['#10b981', '#34d399', '#6ee7b7', '#a7f3d0', '#047857'];
    const COLORS_EXPENSE = ['#ef4444', '#f87171', '#fb923c', '#fdba74', '#b91c1c'];

    const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
        if (percent < 0.05) return null; // Don't render label for small slices
        const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
        const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
        const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));

        return (
            <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" className="font-bold text-xs pointer-events-none">
                {`${(percent * 100).toFixed(0)}%`}
            </text>
        );
    };

    if (isLoading) return <Spinner />;
    if (error || !financeCategories || !surauInfo) return <div className="text-center p-10 text-red-600">{error || "Data penting tidak dapat dimuatkan."}</div>;


    return (
        <div className="space-y-8">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-green-100 p-6 rounded-xl shadow-md border-l-4 border-green-500">
                    <p className="text-sm text-green-700">Jumlah Derma</p>
                    <p className="text-3xl font-bold text-green-800">RM {totalIncome.toFixed(2)}</p>
                </div>
                <div className="bg-red-100 p-6 rounded-xl shadow-md border-l-4 border-red-500">
                    <p className="text-sm text-red-700">Jumlah Perbelanjaan</p>
                    <p className="text-3xl font-bold text-red-800">RM {Math.abs(totalExpense).toFixed(2)}</p>
                </div>
                <div className="bg-blue-100 p-6 rounded-xl shadow-md border-l-4 border-blue-500">
                    <p className="text-sm text-blue-700">Baki Terkini</p>
                    <p className="text-3xl font-bold text-blue-800">RM {balance.toFixed(2)}</p>
                </div>
            </div>

            {/* Category Pie Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-xl font-bold text-dark mb-4">Pecahan Sumber Derma</h3>
                     <ResponsiveContainer width="100%" height={300}>
                        {categoryData.income.length > 0 ? (
                        <PieChart>
                            <Pie data={categoryData.income} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={110} labelLine={false} label={renderCustomizedLabel}>
                                {categoryData.income.map((entry, index) => <Cell key={`cell-income-${index}`} fill={COLORS_INCOME[index % COLORS_INCOME.length]} />)}
                            </Pie>
                            <Tooltip formatter={(value: number) => `RM ${value.toFixed(2)}`} />
                            <Legend />
                        </PieChart>
                        ) : <div className="flex items-center justify-center h-full text-gray-500">Tiada data kategori untuk derma.</div>}
                    </ResponsiveContainer>
                </div>
                 <div className="bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-xl font-bold text-dark mb-4">Pecahan Perbelanjaan</h3>
                     <ResponsiveContainer width="100%" height={300}>
                        {categoryData.expense.length > 0 ? (
                        <PieChart>
                            <Pie data={categoryData.expense} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={110} labelLine={false} label={renderCustomizedLabel}>
                                {categoryData.expense.map((entry, index) => <Cell key={`cell-expense-${index}`} fill={COLORS_EXPENSE[index % COLORS_EXPENSE.length]} />)}
                            </Pie>
                            <Tooltip formatter={(value: number) => `RM ${value.toFixed(2)}`} />
                            <Legend />
                        </PieChart>
                        ) : <div className="flex items-center justify-center h-full text-gray-500">Tiada data kategori untuk perbelanjaan.</div>}
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Main Content */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Financial Chart */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-xl font-bold text-dark mb-4">Carta Aliran Kewangan (12 Bulan Terakhir)</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={processedChartData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" fontSize={12}/>
                            <YAxis tickFormatter={(value) => `RM${value}`} fontSize={12} />
                            <Tooltip formatter={(value, name) => [`RM${(value as number).toFixed(2)}`, name]} />
                            <Legend />
                            <Line type="monotone" dataKey="Derma" stroke="#10b981" activeDot={{ r: 8 }} strokeWidth={2}/>
                            <Line type="monotone" dataKey="Perbelanjaan" stroke="#ef4444" strokeWidth={2}/>
                        </LineChart>
                    </ResponsiveContainer>
                </div>

                {/* Donation Section */}
                <div className="bg-white p-6 rounded-xl shadow-md flex flex-col items-center justify-center">
                    <h3 className="text-xl font-bold text-dark mb-4">Derma Secara Dalam Talian</h3>
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=DuitNow-Pay" alt="QR Code" className="w-40 h-40 mb-4 rounded-lg" />
                    <p className="text-center text-sm text-gray-600">Imbas kod QR ini menggunakan aplikasi perbankan anda untuk menderma.</p>
                     <button onClick={() => setIsReportModalOpen(true)} className="mt-4 bg-secondary text-white px-6 py-2 rounded-lg hover:bg-yellow-800 transition-colors w-full">
                        Hasilkan Laporan Kewangan
                    </button>
                </div>
            </div>

            {/* Transaction History */}
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-dark">Sejarah Transaksi Terkini</h3>
                    <div className="flex items-center gap-2">
                         <button 
                            onClick={handleExportTransactions}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                        >
                            <DownloadIcon className="w-5 h-5" />
                            Eksport ke CSV
                        </button>
                        <button onClick={() => setIsModalOpen(true)} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">+ Tambah Transaksi</button>
                    </div>
                </div>
                 <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">Tarikh</th>
                                <th scope="col" className="px-6 py-3">Keterangan</th>
                                <th scope="col" className="px-6 py-3">Penderma</th>
                                <th scope="col" className="px-6 py-3">Kategori</th>
                                <th scope="col" className="px-6 py-3 text-right">Jumlah (RM)</th>
                                <th scope="col" className="px-6 py-3 text-center">Tindakan</th>
                            </tr>
                        </thead>
                        <tbody>
                            {transactions.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(t => (
                                <tr key={t.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4">{new Date(t.date).toLocaleDateString('ms-MY')}</td>
                                    <td className="px-6 py-4 font-medium text-gray-900">{t.description}</td>
                                    <td className="px-6 py-4 text-gray-600">{t.payerName || '-'}</td>
                                    <td className="px-6 py-4 text-gray-600">{t.category || '-'}</td>
                                    <td className={`px-6 py-4 text-right font-semibold ${t.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>{t.amount.toFixed(2)}</td>
                                    <td className="px-6 py-4 text-center">
                                        <div className="flex items-center justify-center space-x-2">
                                            {t.type === 'Derma' && <button onClick={() => setReceiptTransaction(t)} className="font-medium text-primary hover:underline">Resit</button>}
                                            <button onClick={() => handleDeleteTransaction(t.id)} className="p-2 text-red-500 hover:bg-red-100 rounded-full" title="Padam Transaksi">
                                                <TrashIcon className="w-4 h-4"/>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                 </div>
            </div>
            {isModalOpen && <TransactionFormModal onClose={() => setIsModalOpen(false)} onSave={handleSaveTransaction} categories={financeCategories} activeMembers={activeMembers} />}
            {assetModalData && <AssetFormModal assetToEdit={assetModalData} onSave={handleSaveAsset} onClose={() => setAssetModalData(null)} />}
            {isReportModalOpen && <FinancialReportModal onClose={() => setIsReportModalOpen(false)} transactions={transactions} totalIncome={totalIncome} totalExpense={totalExpense} balance={balance} surauInfo={surauInfo} />}
            {receiptTransaction && <ReceiptModal onClose={() => setReceiptTransaction(null)} transaction={receiptTransaction} surauInfo={surauInfo} />}
            {isConfirmDeleteOpen && (
                <ConfirmationModal 
                    title="Padam Transaksi"
                    message="Anda pasti ingin memadam transaksi ini? Tindakan ini tidak boleh dibatalkan."
                    onClose={() => setIsConfirmDeleteOpen(false)}
                    onConfirm={handleConfirmDelete}
                />
            )}
        </div>
    );
};

export default Kewangan;