import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { getMembers, saveMembers, getSurauInfo, getTransactions, saveKhairatTasks, getKhairatTasks, saveAnnouncements, getAnnouncements } from '../services/dataService';
import { Member, Dependent, Payment, SurauInfo, Transaction, Page, Announcement, KhairatTask } from '../types';
import { CloseIcon, EyeIcon, PencilIcon, CheckIcon, TrashIcon, DownloadIcon, HeartCrackIcon } from './icons';
import { useToast, usePrint } from '../App';
import DynamicLogo from './DynamicLogo';
import Spinner from './Spinner';

type FormDependent = Omit<Dependent, 'id' | 'status'> & { id?: number, status?: 'Hidup' | 'Meninggal Dunia' };

// Yearly Statement Modal
const YearlyStatementModal: React.FC<{
    onClose: () => void;
    member: Member;
    surauInfo: SurauInfo;
}> = ({ onClose, member, surauInfo }) => {
    const { handlePrint } = usePrint();
    const [year, setYear] = useState(new Date().getFullYear());
    const [memberTransactions, setMemberTransactions] = useState<Transaction[]>([]);

    useEffect(() => {
        const fetchTransactions = async () => {
            const allTransactions = await getTransactions();
            const donations = allTransactions.filter(t => 
                t.type === 'Derma' &&
                t.memberId === member.id && 
                new Date(t.date).getFullYear() === year
            );
            setMemberTransactions(donations);
        };
        fetchTransactions();
    }, [year, member.id]);

    const totalDonation = useMemo(() => memberTransactions.reduce((sum, t) => sum + t.amount, 0), [memberTransactions]);
    
    const yearOptions = useMemo(() => {
        const currentYear = new Date().getFullYear();
        const years = [];
        for (let i = 0; i < 5; i++) {
            years.push(currentYear - i);
        }
        return years;
    }, []);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4 print-hidden">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
                 <div className="p-6 border-b flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-bold text-dark">Penyata Sumbangan Tahunan</h2>
                        <p className="text-sm text-gray-500">{member.name}</p>
                    </div>
                    <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500 transition-colors"><CloseIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-8 overflow-y-auto" id="statement-content">
                    {/* Header */}
                    <div className="text-center mb-8 pb-4 border-b-2 border-dashed">
                        <DynamicLogo className="w-16 h-16 text-primary mx-auto object-contain" />
                        <h1 className="text-2xl font-bold text-dark mt-2">{surauInfo.name}</h1>
                        <p className="text-sm text-gray-600">{surauInfo.address}</p>
                        <h2 className="text-xl font-semibold text-gray-800 mt-6">Penyata Sumbangan Tahunan</h2>
                    </div>

                    {/* Member and Year Info */}
                    <div className="grid grid-cols-2 gap-8 mb-8">
                        <div>
                            <p className="text-sm text-gray-500">Kepada:</p>
                            <p className="font-bold text-dark">{member.name}</p>
                            <p className="text-gray-700">{member.icNumber}</p>
                            <p className="text-gray-700">{member.address}</p>
                        </div>
                        <div className="text-right">
                             <p className="text-sm text-gray-500">Tahun:</p>
                            <p className="font-bold text-2xl text-dark">{year}</p>
                            <p className="text-sm text-gray-500 print-hidden">Tukar Tahun:</p>
                            <select value={year} onChange={e => setYear(parseInt(e.target.value))} className="mt-1 p-1 border border-gray-300 rounded-md print-hidden">
                                {yearOptions.map(y => <option key={y} value={y}>{y}</option>)}
                            </select>
                        </div>
                    </div>

                    {/* Transactions Table */}
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-100">
                            <tr>
                                <th className="px-4 py-2 text-left font-semibold text-gray-600">Tarikh</th>
                                <th className="px-4 py-2 text-left font-semibold text-gray-600">Keterangan</th>
                                <th className="px-4 py-2 text-left font-semibold text-gray-600">Kategori</th>
                                <th className="px-4 py-2 text-right font-semibold text-gray-600">Jumlah (RM)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {memberTransactions.map(t => (
                                <tr key={t.id} className="border-b border-gray-100">
                                    <td className="px-4 py-3">{new Date(t.date).toLocaleDateString('ms-MY')}</td>
                                    <td className="px-4 py-3 text-gray-800">{t.description}</td>
                                    <td className="px-4 py-3 text-gray-600">{t.category}</td>
                                    <td className="px-4 py-3 text-right font-medium text-green-700">{t.amount.toFixed(2)}</td>
                                </tr>
                            ))}
                             {memberTransactions.length === 0 && (
                                <tr><td colSpan={4} className="text-center py-10 text-gray-500">Tiada rekod sumbangan untuk tahun {year}.</td></tr>
                            )}
                        </tbody>
                        <tfoot>
                            <tr className="bg-gray-100 font-bold">
                                <td colSpan={3} className="px-4 py-3 text-right text-dark">Jumlah Keseluruhan Sumbangan</td>
                                <td className="px-4 py-3 text-right text-lg text-primary">RM {totalDonation.toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                    <p className="text-center text-xs text-gray-500 mt-10">Ini adalah penyata janaan komputer dan sah tanpa tandatangan. Terima kasih atas sumbangan anda.</p>
                </div>
                <div className="p-6 bg-gray-50 text-right rounded-b-lg border-t mt-auto">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 mr-2">Tutup</button>
                    <button type="button" onClick={handlePrint} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">Cetak Penyata</button>
                </div>
            </div>
        </div>
    );
};


// Modal for sending SMS Notification
const SmsNotificationModal: React.FC<{
    onClose: () => void;
    member: Member;
}> = ({ onClose, member }) => {
    const { addToast } = useToast();
    const [message, setMessage] = useState(`Salam dari Surau Salman Al-Farisi. Peringatan mesra untuk ${member.name}.`);

    const handleSend = () => {
        if (!message.trim()) {
            addToast("Mesej tidak boleh kosong.", "error");
            return;
        }
        console.log(`Sending SMS to ${member.phone}: ${message}`);
        addToast(`Notifikasi SMS telah dihantar kepada ${member.name}.`);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <div className="p-6 border-b flex justify-between items-center">
                    <h2 className="text-xl font-bold text-dark">Hantar Notifikasi SMS</h2>
                    <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500 transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>
                <div className="p-6 space-y-4">
                    <div>
                        <p className="text-sm text-gray-700"><strong>Penerima:</strong> {member.name}</p>
                        <p className="text-sm text-gray-700"><strong>No. Telefon:</strong> {member.phone}</p>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Kandungan Mesej</label>
                        <textarea
                            rows={5}
                            value={message}
                            onChange={e => setMessage(e.target.value)}
                            className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                        />
                    </div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                    <button type="button" onClick={handleSend} className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Hantar</button>
                </div>
            </div>
        </div>
    );
};


// Confirmation Modal for destructive actions
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
    confirmText?: string;
    confirmColor?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan", confirmText = "Padam", confirmColor = 'bg-red-600 hover:bg-red-700' }) => {
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <div className="p-6 border-b">
                    <h2 className="text-xl font-bold text-dark">{title}</h2>
                </div>
                <div className="p-6">
                    <p className="text-gray-700">{message}</p>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors">Batal</button>
                    <button type="button" onClick={onConfirm} className={`text-white px-4 py-2 rounded-lg transition-colors ${confirmColor}`}>{confirmText}</button>
                </div>
            </div>
        </div>
    );
};


// Modal for recording a new payment
const PaymentModal: React.FC<{
    onClose: () => void;
    onSave: (paymentData: { year: number; amount: number }) => void;
}> = ({ onClose, onSave }) => {
    const { addToast } = useToast();
    const [year, setYear] = useState<number>(new Date().getFullYear());
    const [amount, setAmount] = useState<number>(50);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (year > 0 && amount > 0) {
            onSave({ year, amount });
        } else {
            addToast('Sila masukkan tahun dan jumlah yang sah.', 'error');
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                <form onSubmit={handleSubmit}>
                    <div className="p-6 border-b flex justify-between items-center">
                        <h2 className="text-xl font-bold text-dark">Rekod Bayaran Khairat</h2>
                        <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500 transition-colors">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Tahun Bayaran</label>
                            <input
                                type="number"
                                value={year}
                                onChange={e => setYear(parseInt(e.target.value, 10))}
                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Jumlah (RM)</label>
                            <input
                                type="number"
                                step="0.01"
                                value={amount}
                                onChange={e => setAmount(parseFloat(e.target.value))}
                                className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"
                                required
                            />
                        </div>
                    </div>
                    <div className="p-6 bg-gray-50 text-right rounded-b-lg border-t">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors mr-2">Batal</button>
                        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark transition-colors">Simpan Bayaran</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


// New component to display member details in a dedicated view instead of a modal
const MemberDetailView: React.FC<{ 
    member: Member; 
    onBack: () => void; 
    onEdit: (member: Member) => void; 
    onRecordPayment: () => void; 
    onDelete: () => void; 
    onSendSms: () => void; 
    onGenerateStatement: () => void; 
    onReportDeath: () => void;
    onReportDependentDeath: (dependent: Dependent) => void;
}> = ({ member, onBack, onEdit, onRecordPayment, onDelete, onSendSms, onGenerateStatement, onReportDeath, onReportDependentDeath }) => {
    return (
        <div className="bg-white p-6 rounded-xl shadow-md animate-fade-in">
            {/* Header section of the detail view */}
            <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 pb-4 border-b">
                <div className="mb-4 md:mb-0">
                    <h2 className="text-3xl font-bold text-dark">{member.name}</h2>
                    <p className="text-gray-500">ID Ahli: {String(member.id).padStart(4, '0')} &bull; Ahli Sejak: {new Date(member.joinDate).toLocaleDateString('ms-MY', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
                <button onClick={onBack} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-300 transition-colors self-start md:self-center">
                    &larr; Kembali ke Senarai
                </button>
            </div>
            
            {/* Main content grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left Column: Personal Info & Dependents */}
                <div className="lg:col-span-1 space-y-6">
                    <div className="bg-light p-4 rounded-lg border border-gray-200">
                        <h3 className="font-bold text-lg text-primary mb-3">Maklumat Peribadi</h3>
                        <div className="space-y-2 text-sm">
                            <p><strong>No. K/P:</strong><br/>{member.icNumber}</p>
                            <p><strong>Telefon:</strong><br/>{member.phone}</p>
                            <p><strong>Alamat:</strong><br/>{member.address}</p>
                        </div>
                    </div>
                    <div className="bg-light p-4 rounded-lg border border-gray-200">
                         <h3 className="font-bold text-lg text-primary mb-3">Tanggungan</h3>
                        {member.dependents.length > 0 ? (
                            <div className="space-y-2">
                                {member.dependents.map((d) => (
                                    <div key={d.id} className="flex justify-between items-center p-2 rounded-md bg-gray-100">
                                        <p className={`text-sm ${d.status === 'Meninggal Dunia' ? 'text-gray-400 line-through' : 'text-gray-800'}`}>
                                            <strong>{d.name}</strong> ({d.relationship})
                                        </p>
                                        {d.status === 'Hidup' && (
                                            <button onClick={() => onReportDependentDeath(d)} className="text-xs bg-black text-white px-2 py-1 rounded hover:bg-gray-700 transition-colors" title="Laporkan Kematian Tanggungan">
                                                <HeartCrackIcon className="w-4 h-4" />
                                            </button>
                                        )}
                                    </div>
                                ))}
                            </div>
                        ) : <p className="text-sm text-gray-500">Tiada maklumat tanggungan.</p>}
                    </div>
                </div>

                {/* Right Column: Payment History & Actions */}
                <div className="lg:col-span-2">
                    <div className="bg-light p-4 rounded-lg border border-gray-200">
                        <div className="flex justify-between items-center mb-3">
                            <h3 className="font-bold text-lg text-primary">Sejarah Bayaran Khairat Kematian</h3>
                             <button onClick={onRecordPayment} className="bg-primary text-white text-xs px-3 py-1 rounded-md hover:bg-dark transition-colors">+ Rekod Bayaran Baru</button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left text-gray-500">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-200">
                                    <tr>
                                        <th scope="col" className="px-4 py-2">Tahun</th>
                                        <th scope="col" className="px-4 py-2">Jumlah (RM)</th>
                                        <th scope="col" className="px-4 py-2">Tarikh Bayaran</th>
                                        <th scope="col" className="px-4 py-2">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {member.khairatPayments.slice().sort((a, b) => b.year - a.year).map((p: Payment) => (
                                        <tr key={p.id} className="bg-white border-b hover:bg-gray-50">
                                            <td className="px-4 py-3 font-medium">{p.year}</td>
                                            <td className="px-4 py-3">{p.amount.toFixed(2)}</td>
                                            <td className="px-4 py-3">{p.paymentDate === '-' ? '-' : new Date(p.paymentDate).toLocaleDateString('ms-MY')}</td>
                                            <td className="px-4 py-3">
                                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${p.status === 'Lunas' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                    {p.status}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                    {member.khairatPayments.length === 0 && (
                                        <tr><td colSpan={4} className="text-center text-gray-500 py-4">Tiada sejarah bayaran.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                     <div className="mt-6 flex flex-wrap gap-2 justify-end">
                        <button onClick={onGenerateStatement} className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition-colors">Jana Penyata Tahunan</button>
                        {member.status === 'Aktif' && (
                            <button onClick={onReportDeath} className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                                <HeartCrackIcon className="w-5 h-5" /> Laporkan Kematian
                            </button>
                        )}
                        <button onClick={() => onEdit(member)} className="bg-secondary text-white px-4 py-2 rounded-lg hover:bg-yellow-800 transition-colors">Kemaskini Maklumat</button>
                        <button onClick={onSendSms} className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors">Hantar Notifikasi SMS</button>
                        <button onClick={onDelete} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">Padam Ahli</button>
                    </div>
                </div>
            </div>
        </div>
    );
};


const MemberFormModal: React.FC<{
    onClose: () => void;
    onSave: (memberData: Omit<Member, 'id' | 'khairatPayments' | 'joinDate' | 'dependents' | 'status'> & { dependents: FormDependent[] }) => void;
    initialData: Member | null;
}> = ({ onClose, onSave, initialData }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [icNumber, setIcNumber] = useState('');
    const [address, setAddress] = useState('');
    const [phone, setPhone] = useState('');
    const [dependents, setDependents] = useState<FormDependent[]>([]);

    useEffect(() => {
        if (initialData) {
            setName(initialData.name);
            setIcNumber(initialData.icNumber);
            setAddress(initialData.address);
            setPhone(initialData.phone);
            setDependents(initialData.dependents);
        }
    }, [initialData]);

    const handleAddDependent = () => {
        setDependents([...dependents, { name: '', relationship: '', status: 'Hidup' }]);
    };

    const handleRemoveDependent = (index: number) => {
        setDependents(dependents.filter((_, i) => i !== index));
    };

    const handleDependentChange = (index: number, field: 'name' | 'relationship', value: string) => {
        const newDependents = [...dependents];
        newDependents[index] = { ...newDependents[index], [field]: value };
        setDependents(newDependents);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !icNumber || !address || !phone) {
            addToast('Sila isi semua maklumat peribadi yang diperlukan.', 'error');
            return;
        }
        onSave({ name, icNumber, address, phone, dependents });
    };

    return (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col">
                <form onSubmit={handleSubmit} className="flex flex-col h-full">
                    <div className="p-6 border-b flex justify-between items-center">
                        <h2 className="text-2xl font-bold text-dark">{initialData ? 'Kemaskini Maklumat Ahli' : 'Daftar Ahli Kariah Baru'}</h2>
                        <button type="button" onClick={onClose} className="text-gray-500 hover:text-red-500 transition-colors">
                            <CloseIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="p-6 overflow-y-auto space-y-4">
                        <h3 className="font-semibold text-primary mb-2 border-b pb-2">Maklumat Peribadi</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Nama Penuh</label>
                                <input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">No. K/P</label>
                                <input type="text" value={icNumber} onChange={e => setIcNumber(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm" required />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700">No. Telefon</label>
                                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm" required />
                            </div>
                             <div className="md:col-span-2">
                                <label className="block text-sm font-medium text-gray-700">Alamat</label>
                                <textarea value={address} onChange={e => setAddress(e.target.value)} rows={3} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm" required />
                            </div>
                        </div>

                        <h3 className="font-semibold text-primary pt-4 mb-2 border-b pb-2">Maklumat Tanggungan</h3>
                        <div className="space-y-3">
                            {dependents.map((dep, index) => (
                                <div key={dep.id || index} className="flex items-center gap-2 p-2 bg-gray-50 rounded-md">
                                    <input type="text" placeholder="Nama Tanggungan" value={dep.name} onChange={e => handleDependentChange(index, 'name', e.target.value)} className="block w-full p-2 border border-gray-300 rounded-md" required/>
                                    <input type="text" placeholder="Hubungan" value={dep.relationship} onChange={e => handleDependentChange(index, 'relationship', e.target.value)} className="block w-full p-2 border border-gray-300 rounded-md" required/>
                                    <button type="button" onClick={() => handleRemoveDependent(index)} className="text-red-500 hover:text-red-700 p-2 rounded-full bg-red-100">
                                        <CloseIcon className="w-4 h-4" />
                                    </button>
                                </div>
                            ))}
                        </div>
                        <button type="button" onClick={handleAddDependent} className="mt-2 text-sm bg-green-100 text-green-800 px-3 py-1 rounded-md hover:bg-green-200">+ Tambah Tanggungan</button>

                    </div>
                    <div className="p-6 bg-gray-50 text-right rounded-b-lg border-t mt-auto">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors mr-2">Batal</button>
                        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark transition-colors">{initialData ? 'Simpan Perubahan' : 'Daftar Ahli'}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const Kariah: React.FC<{ initialTab?: 'aktif' | 'pengesahan'; setActivePage: (page: Page) => void }> = ({ initialTab = 'aktif', setActivePage }) => {
    const [allMembers, setAllMembers] = useState<Member[]>([]);
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    
    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState<'aktif' | 'pengesahan' | 'arkib'>(initialTab);
    const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
    const [isSmsModalOpen, setIsSmsModalOpen] = useState(false);
    const [isStatementModalOpen, setIsStatementModalOpen] = useState(false);
    const [editingMember, setEditingMember] = useState<Member | null>(null);
    const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState<{ id: number; name: string } | null>(null);
    const [isConfirmDeathOpen, setIsConfirmDeathOpen] = useState<Member | null>(null);
    const [isConfirmDependentDeathOpen, setIsConfirmDependentDeathOpen] = useState<{ member: Member, dependent: Dependent } | null>(null);

    const { addToast } = useToast();
    
    const fetchData = useCallback(async () => {
        try {
            const [membersData, infoData] = await Promise.all([getMembers(), getSurauInfo()]);
            setAllMembers(membersData);
            setSurauInfo(infoData);
            setError(null);
        } catch (err) {
            setError("Gagal memuatkan data ahli. Sila cuba lagi.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        setIsLoading(true);
        fetchData();
    }, [fetchData]);
    
    useEffect(() => {
        setActiveTab(initialTab);
    }, [initialTab]);

    const activeMembers = useMemo(() => allMembers.filter(m => m.status === 'Aktif'), [allMembers]);
    const pendingMembers = useMemo(() => allMembers.filter(m => m.status === 'Menunggu Pengesahan'), [allMembers]);
    const archivedMembers = useMemo(() => allMembers.filter(m => m.status === 'Meninggal Dunia'), [allMembers]);

    const listToDisplay = useMemo(() => {
        let list: Member[];
        if (activeTab === 'aktif') list = activeMembers;
        else if (activeTab === 'pengesahan') list = pendingMembers;
        else list = archivedMembers;

        return list.filter(member =>
            member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            member.icNumber.includes(searchTerm)
        );
    }, [searchTerm, activeTab, activeMembers, pendingMembers, archivedMembers]);

    const handleOpenAddModal = () => {
        setEditingMember(null);
        setIsFormModalOpen(true);
    };

    const handleOpenEditModal = (member: Member) => {
        setEditingMember(member);
        setIsFormModalOpen(true);
    };

    const downloadCSV = (data: any[], filename: string) => {
        if (data.length === 0) {
            addToast('Tiada data untuk dieksport.', 'info');
            return;
        }
        const headers = Object.keys(data[0]);
        const csvContent = [
            headers.join(','),
            ...data.map(row => headers.map(header => JSON.stringify(row[header])).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        addToast('Data sedang dimuat turun.', 'success');
    };

    const handleExportKariah = () => {
        const dataToExport = activeMembers.map(m => ({
            ID_Ahli: m.id,
            Nama: m.name,
            No_KP: m.icNumber,
            Alamat: m.address,
            Telefon: m.phone,
            Tarikh_Sertai: new Date(m.joinDate).toLocaleDateString('ms-MY'),
            Status_Bayaran_Khairat_2024: m.khairatPayments.find(p => p.year === 2024)?.status || 'Tertunggak',
            Bil_Tanggungan: m.dependents.length
        }));
        downloadCSV(dataToExport, `senarai_ahli_kariah_${new Date().toISOString().split('T')[0]}.csv`);
    };
    
    const handleAddPayment = async (paymentData: { year: number; amount: number }) => {
        if (!selectedMemberId) return;

        const updatedMembers = allMembers.map(member => {
            if (member.id === selectedMemberId) {
                const newPayments: Payment[] = member.khairatPayments ? [...member.khairatPayments] : [];
                const existingPaymentIndex = newPayments.findIndex(p => p.year === paymentData.year);
                
                if (existingPaymentIndex > -1) {
                    newPayments[existingPaymentIndex] = {
                        ...newPayments[existingPaymentIndex],
                        amount: paymentData.amount,
                        paymentDate: new Date().toISOString(),
                        status: 'Lunas',
                    };
                } else {
                    const newPayment: Payment = {
                        id: Date.now(),
                        ...paymentData,
                        paymentDate: new Date().toISOString(),
                        status: 'Lunas',
                    };
                    newPayments.push(newPayment);
                }
                return { ...member, khairatPayments: newPayments };
            }
            return member;
        });

        try {
            await saveMembers(updatedMembers);
            setIsPaymentModalOpen(false);
            addToast("Bayaran khairat telah berjaya direkodkan.");
            setAllMembers(updatedMembers); // Optimistic update
        } catch (err) {
            addToast("Gagal merekodkan bayaran.", "error");
        }
    };

    const handleRejectMember = (id: number, name: string) => {
        setIsConfirmDeleteOpen({ id, name });
    };

    const handleConfirmDelete = async () => {
        if (!isConfirmDeleteOpen) return;
        const updatedMembers = allMembers.filter(m => m.id !== isConfirmDeleteOpen.id);
        try {
            await saveMembers(updatedMembers);
            addToast(`Permohonan dari "${isConfirmDeleteOpen.name}" telah ditolak.`);
            setAllMembers(updatedMembers); // Optimistic update
        } catch(err) {
            addToast("Gagal menolak permohonan.", "error");
        } finally {
            setIsConfirmDeleteOpen(null);
        }
    };
    
    const handleConfirmDeleteActive = async () => {
        if (!selectedMemberId) return;
        const memberToDelete = allMembers.find(m => m.id === selectedMemberId);
        const updatedMembers = allMembers.filter(m => m.id !== selectedMemberId);
        try {
            await saveMembers(updatedMembers);
            addToast(`Maklumat ahli "${memberToDelete?.name}" telah berjaya dipadam.`);
            setAllMembers(updatedMembers); // Optimistic update
        } catch (err) {
            addToast("Gagal memadam ahli.", "error");
        } finally {
            setIsConfirmDeleteOpen(null);
            setSelectedMemberId(null);
        }
    };

    const handleConfirmDeath = async () => {
        if (!isConfirmDeathOpen || !surauInfo) return;

        try {
            // 1. Update member status
            const updatedMembers = allMembers.map(m => 
                m.id === isConfirmDeathOpen.id ? { ...m, status: 'Meninggal Dunia' as const } : m
            );
            
            // 2. Create Khairat Task
            const khairatTasks = await getKhairatTasks();
            const newKhairatTask: KhairatTask = {
                id: Date.now(),
                memberId: isConfirmDeathOpen.id,
                memberName: isConfirmDeathOpen.name,
                deathDate: new Date().toISOString(),
                status: 'Menunggu Tindakan',
                type: 'Ahli',
                amount: surauInfo.khairatAmountMember,
            };
            const updatedKhairatTasks = [newKhairatTask, ...khairatTasks];

            // 3. Create Draft Announcement
            const announcements = await getAnnouncements();
            const newAnnouncement: Announcement = {
                id: Date.now(),
                title: `(DRAF) Takziah - Pemergian ${isConfirmDeathOpen.name}`,
                content: `Dengan rasa dukacita, dimaklumkan bahawa ahli kariah kita, ${isConfirmDeathOpen.name}, telah kembali ke rahmatullah. Salam takziah diucapkan kepada seluruh ahli keluarga. Semoga rohnya dicucuri rahmat.\n\n(Maklumat lanjut akan dikemaskini).`,
                date: new Date().toISOString(),
            };
            const updatedAnnouncements = [newAnnouncement, ...announcements];

            // 4. Save all data
            await Promise.all([
                saveMembers(updatedMembers),
                saveKhairatTasks(updatedKhairatTasks),
                saveAnnouncements(updatedAnnouncements)
            ]);

            // 5. Update local state and UI
            setAllMembers(updatedMembers);
            addToast(`Kematian ${isConfirmDeathOpen.name} telah direkodkan.`);
            addToast("Draf pengumuman takziah & tugasan khairat telah dicipta.", "info");
            setIsConfirmDeathOpen(null);
            setSelectedMemberId(null); // Go back to list view
            setActivePage(Page.Aktiviti); // Navigate to announcements page

        } catch (err) {
            addToast("Gagal merekodkan kematian.", "error");
            console.error(err);
        }
    };
    
    const handleConfirmDependentDeath = async () => {
        if (!isConfirmDependentDeathOpen || !surauInfo) return;
        const { member, dependent } = isConfirmDependentDeathOpen;

        try {
             // 1. Update dependent status in member's record
            const updatedMembers = allMembers.map(m => {
                if (m.id === member.id) {
                    const updatedDependents = m.dependents.map(d => 
                        d.id === dependent.id ? { ...d, status: 'Meninggal Dunia' as const } : d
                    );
                    return { ...m, dependents: updatedDependents };
                }
                return m;
            });

             // 2. Create Khairat Task (if applicable)
            const khairatTasks = await getKhairatTasks();
            let updatedKhairatTasks = [...khairatTasks];
            if (surauInfo.khairatAmountDependent > 0) {
                const newKhairatTask: KhairatTask = {
                    id: Date.now(),
                    memberId: member.id,
                    memberName: member.name,
                    dependentId: dependent.id,
                    dependentName: dependent.name,
                    deathDate: new Date().toISOString(),
                    status: 'Menunggu Tindakan',
                    type: 'Tanggungan',
                    amount: surauInfo.khairatAmountDependent,
                };
                updatedKhairatTasks = [newKhairatTask, ...khairatTasks];
            }

             // 3. Create Draft Announcement
            const announcements = await getAnnouncements();
            const newAnnouncement: Announcement = {
                id: Date.now(),
                title: `(DRAF) Takziah - Pemergian ${dependent.name}`,
                content: `Dengan rasa dukacita, dimaklumkan bahawa ${dependent.name} (${dependent.relationship} kepada ahli kariah kita, ${member.name}), telah kembali ke rahmatullah. Salam takziah diucapkan kepada seluruh ahli keluarga.`,
                date: new Date().toISOString(),
            };
            const updatedAnnouncements = [newAnnouncement, ...announcements];

            // 4. Save all data
            await Promise.all([
                saveMembers(updatedMembers),
                saveKhairatTasks(updatedKhairatTasks),
                saveAnnouncements(updatedAnnouncements)
            ]);

            // 5. Update UI and provide feedback
            setAllMembers(updatedMembers);
            addToast(`Kematian tanggungan ${dependent.name} telah direkodkan.`);
            if (surauInfo.khairatAmountDependent > 0) {
                addToast("Tugasan khairat untuk tanggungan telah dicipta.", "info");
            }
            addToast("Draf pengumuman takziah telah dicipta.", "info");
            
        } catch (err) {
            addToast("Gagal merekodkan kematian tanggungan.", "error");
            console.error(err);
        } finally {
            setIsConfirmDependentDeathOpen(null);
        }
    };

    const handleSaveMember = async (memberData: Omit<Member, 'id' | 'khairatPayments' | 'joinDate' | 'dependents' | 'status'> & { dependents: FormDependent[] }) => {
        let updatedMembers: Member[];
        let successMessage = '';
        if (editingMember) {
            updatedMembers = allMembers.map(m => m.id === editingMember.id ? { ...editingMember, ...memberData, dependents: memberData.dependents.map((d) => ({ ...d, id: d.id || Date.now() + Math.random(), status: d.status || 'Hidup' })) } : m);
            successMessage = `Maklumat ahli "${editingMember.name}" telah berjaya dikemaskini.`;
        } else {
            const newMember: Member = {
                id: allMembers.length > 0 ? Math.max(...allMembers.map(m => m.id)) + 1 : 1,
                ...memberData,
                status: 'Aktif',
                joinDate: new Date().toISOString().split('T')[0],
                dependents: memberData.dependents.map((dep, index) => ({
                    id: Date.now() + index,
                    name: dep.name,
                    relationship: dep.relationship,
                    status: 'Hidup',
                })),
                khairatPayments: [{ id: 1, year: new Date().getFullYear(), amount: 50, paymentDate: '-', status: 'Tertunggak' }],
            };
            updatedMembers = [newMember, ...allMembers];
            successMessage = `Ahli baru "${newMember.name}" telah berjaya didaftarkan.`;
        }
        
        try {
            await saveMembers(updatedMembers);
            addToast(successMessage);
            setAllMembers(updatedMembers); // Optimistic update
        } catch (err) {
            addToast("Gagal menyimpan data ahli.", "error");
        } finally {
            setIsFormModalOpen(false);
            setEditingMember(null);
        }
    };

    const handleApproveMember = async (id: number) => {
        const updatedMembers = allMembers.map(m => {
            if (m.id === id) {
                return { 
                    ...m, 
                    status: 'Aktif' as const,
                    khairatPayments: [{ id: 1, year: new Date().getFullYear(), amount: 50, paymentDate: '-', status: 'Tertunggak' as const }]
                };
            }
            return m;
        });
        
        try {
            await saveMembers(updatedMembers);
            addToast("Permohonan ahli telah diluluskan.");
            setAllMembers(updatedMembers); // Optimistic update
        } catch(err) {
            addToast("Gagal meluluskan permohonan.", "error");
        }
    };

    const selectedMember = useMemo(() => allMembers.find(m => m.id === selectedMemberId), [allMembers, selectedMemberId]);

    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    if (selectedMember && surauInfo) {
        return (
            <>
                <MemberDetailView 
                    member={selectedMember} 
                    onBack={() => setSelectedMemberId(null)} 
                    onEdit={handleOpenEditModal}
                    onRecordPayment={() => setIsPaymentModalOpen(true)}
                    onDelete={() => setIsConfirmDeleteOpen({id: selectedMember.id, name: selectedMember.name})}
                    onSendSms={() => setIsSmsModalOpen(true)}
                    onGenerateStatement={() => setIsStatementModalOpen(true)}
                    onReportDeath={() => setIsConfirmDeathOpen(selectedMember)}
                    onReportDependentDeath={(dependent) => setIsConfirmDependentDeathOpen({ member: selectedMember, dependent })}
                />
                {isPaymentModalOpen && (
                    <PaymentModal onClose={() => setIsPaymentModalOpen(false)} onSave={handleAddPayment} />
                )}
                {isConfirmDeleteOpen && selectedMember && (
                    <ConfirmationModal title="Padam Ahli" message={`Anda pasti ingin memadam ahli "${selectedMember.name}"? Tindakan ini tidak boleh dibatalkan.`} onClose={() => setIsConfirmDeleteOpen(null)} onConfirm={handleConfirmDeleteActive} />
                )}
                {isConfirmDeathOpen && (
                    <ConfirmationModal 
                        title="Lapor Kematian Ahli" 
                        message={`Anda pasti ingin melaporkan kematian bagi ahli "${isConfirmDeathOpen.name}"? Ini akan mengarkibkan ahli dan mencipta tugasan khairat kematian.`} 
                        onClose={() => setIsConfirmDeathOpen(null)} 
                        onConfirm={handleConfirmDeath}
                        confirmText="Ya, Sahkan Kematian"
                        confirmColor="bg-black hover:bg-gray-800"
                    />
                )}
                {isConfirmDependentDeathOpen && (
                     <ConfirmationModal 
                        title="Lapor Kematian Tanggungan" 
                        message={`Anda pasti ingin melaporkan kematian bagi tanggungan "${isConfirmDependentDeathOpen.dependent.name}"?`} 
                        onClose={() => setIsConfirmDependentDeathOpen(null)} 
                        onConfirm={handleConfirmDependentDeath}
                        confirmText="Ya, Sahkan"
                        confirmColor="bg-black hover:bg-gray-800"
                    />
                )}
                 {isSmsModalOpen && (
                    <SmsNotificationModal member={selectedMember} onClose={() => setIsSmsModalOpen(false)} />
                )}
                {isStatementModalOpen && (
                    <YearlyStatementModal onClose={() => setIsStatementModalOpen(false)} member={selectedMember} surauInfo={surauInfo} />
                )}
            </>
        );
    }

    const TabButton: React.FC<{ name: string, count: number, current: string, target: string, onClick: () => void}> = ({ name, count, current, target, onClick }) => (
         <button onClick={onClick} className={`whitespace-nowrap py-4 px-3 border-b-2 font-medium text-sm flex items-center gap-2 ${current === target ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
            {name}
            {count > 0 && <span className={`text-xs font-bold rounded-full px-2 py-0.5 ${current === target ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700'}`}>{count}</span>}
        </button>
    );

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="border-b border-gray-200 mb-6">
                <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                    <TabButton name="Ahli Aktif" count={activeMembers.length} current={activeTab} target="aktif" onClick={() => setActiveTab('aktif')} />
                    <TabButton name="Menunggu Pengesahan" count={pendingMembers.length} current={activeTab} target="pengesahan" onClick={() => setActiveTab('pengesahan')} />
                    <TabButton name="Arkib" count={archivedMembers.length} current={activeTab} target="arkib" onClick={() => setActiveTab('arkib')} />
                </nav>
            </div>
            
            <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
                <input
                    type="text"
                    placeholder="Cari ahli (nama atau No. K/P)..."
                    className="w-full md:w-1/3 p-2 border border-gray-300 rounded-lg"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                {activeTab === 'aktif' && (
                    <div className="flex items-center gap-2">
                        <button 
                            onClick={handleExportKariah}
                            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors w-full md:w-auto flex items-center gap-2"
                        >
                            <DownloadIcon className="w-5 h-5" />
                            Eksport ke CSV
                        </button>
                        <button 
                            onClick={handleOpenAddModal}
                            className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark transition-colors w-full md:w-auto"
                        >
                            Daftar Ahli Baru
                        </button>
                    </div>
                )}
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3">Nama</th>
                            <th scope="col" className="px-6 py-3">No. Kad Pengenalan</th>
                            <th scope="col" className="px-6 py-3">Telefon</th>
                            <th scope="col" className="px-6 py-3">Status</th>
                            <th scope="col" className="px-6 py-3 text-center">Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        {listToDisplay.map(member => (
                            <tr key={member.id} className="bg-white border-b hover:bg-gray-50">
                                <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                    {member.name}
                                </th>
                                <td className="px-6 py-4">{member.icNumber}</td>
                                <td className="px-6 py-4">{member.phone}</td>
                                <td className="px-6 py-4">
                                    {activeTab === 'aktif' ? (
                                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${member.khairatPayments.find(p => p.year === 2024)?.status === 'Lunas' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                            {member.khairatPayments.find(p => p.year === 2024)?.status || 'Tertunggak'}
                                        </span>
                                    ) : activeTab === 'pengesahan' ? (
                                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                            Menunggu Pengesahan
                                        </span>
                                    ) : (
                                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-200 text-gray-800">
                                            Meninggal Dunia
                                        </span>
                                    )}
                                </td>
                                <td className="px-6 py-4 text-center">
                                    {activeTab === 'aktif' || activeTab === 'arkib' ? (
                                        <div className="flex items-center justify-center space-x-2">
                                            <button onClick={() => setSelectedMemberId(member.id)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="Lihat Butiran"><EyeIcon className="w-5 h-5" /></button>
                                            <button onClick={() => handleOpenEditModal(member)} className="p-2 text-yellow-600 hover:bg-yellow-100 rounded-full" title="Kemaskini"><PencilIcon className="w-5 h-5" /></button>
                                        </div>
                                    ) : (
                                         <div className="flex items-center justify-center space-x-2">
                                            <button onClick={() => handleApproveMember(member.id)} className="flex items-center gap-1 text-xs bg-green-500 text-white px-3 py-1 rounded-md hover:bg-green-600"><CheckIcon className="w-4 h-4"/>Sahkan</button>
                                            <button onClick={() => handleRejectMember(member.id, member.name)} className="flex items-center gap-1 text-xs bg-red-600 text-white px-3 py-1 rounded-md hover:bg-red-700"><TrashIcon className="w-4 h-4"/>Tolak</button>
                                         </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {listToDisplay.length === 0 && (
                    <div className="text-center py-10 text-gray-500">
                        <p>Tiada {activeTab === 'arkib' ? 'arkib ahli' : activeTab === 'aktif' ? 'ahli' : 'permohonan'} ditemui.</p>
                    </div>
                )}
            </div>

            {isFormModalOpen && <MemberFormModal onClose={() => setIsFormModalOpen(false)} onSave={handleSaveMember} initialData={editingMember} />}
            {isConfirmDeleteOpen && <ConfirmationModal title="Tolak Permohonan" message={`Anda pasti ingin menolak permohonan dari "${isConfirmDeleteOpen.name}"?`} onClose={() => setIsConfirmDeleteOpen(null)} onConfirm={handleConfirmDelete} />}
        </div>
    );
};

export default Kariah;