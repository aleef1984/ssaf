import React, { useState, useEffect, useRef } from 'react';
import { SurauInfo, FinanceCategories, DutyPersonnel, SettingsTab, InfoScreenSettings, AdminCredentials } from '../types';
import { getSurauInfo, saveSurauInfo, getFinanceCategories, saveFinanceCategories, getDutyPersonnel, saveDutyPersonnel, getAdminCredentials, saveAdminCredentials, getAllDataForBackup, restoreDataFromBackup } from '../services/dataService';
import { CloseIcon, SettingsIcon, DollarSignIcon, DatabaseIcon, ShieldIcon, TvIcon, TrashIcon, FolderOpenIcon, EyeIcon, EyeOffIcon, UploadIcon } from './icons';
import { useToast } from '../App';
import DynamicLogo from './DynamicLogo';
import Spinner from './Spinner';

// A reusable component for managing a list of strings (categories, names)
const ListManager: React.FC<{
    title: string;
    items: string[];
    onItemsChange: (newItems: string[]) => void;
}> = ({ title, items, onItemsChange }) => {
    const [newItem, setNewItem] = useState('');

    const handleAddItem = () => {
        if (newItem && !items.includes(newItem)) {
            onItemsChange([...items, newItem].sort());
            setNewItem('');
        }
    };

    const handleRemoveItem = (itemToRemove: string) => {
        onItemsChange(items.filter(item => item !== itemToRemove));
    };

    return (
        <div>
            <h4 className="text-lg font-semibold text-dark">{title}</h4>
            <div className="mt-2 space-y-2 max-h-48 overflow-y-auto pr-2">
                {items.map(item => (
                    <div key={item} className="flex items-center justify-between bg-gray-100 p-2 rounded-md">
                        <span>{item}</span>
                        <button onClick={() => handleRemoveItem(item)} className="text-red-500 hover:text-red-700 p-1 rounded-full hover:bg-red-100">
                            <CloseIcon className="w-4 h-4" />
                        </button>
                    </div>
                ))}
                 {items.length === 0 && <p className="text-sm text-gray-400 text-center py-4">Tiada item.</p>}
            </div>
            <div className="mt-3 flex gap-2">
                <input
                    type="text"
                    value={newItem}
                    onChange={(e) => setNewItem(e.target.value)}
                    onKeyDown={(e) => {if(e.key === 'Enter') { e.preventDefault(); handleAddItem();}}}
                    placeholder={`Tambah ${title.toLowerCase()} baru`}
                    className="flex-grow p-2 border border-gray-300 rounded-md"
                />
                <button onClick={handleAddItem} className="bg-primary text-white px-4 py-2 rounded-md hover:bg-dark">Tambah</button>
            </div>
        </div>
    );
};

// --- Security Card ---
const AdminSecurityCard: React.FC = () => {
    const { addToast } = useToast();
    const [credentials, setCredentials] = useState<AdminCredentials | null>(null);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [isCurrentVisible, setIsCurrentVisible] = useState(false);
    const [isNewVisible, setIsNewVisible] = useState(false);

    useEffect(() => {
        getAdminCredentials().then(setCredentials);
    }, []);

    const handleSavePassword = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!credentials) return;
        if (currentPassword !== credentials.password_plaintext) {
            addToast("Kata laluan semasa tidak sepadan.", "error"); return;
        }
        if (newPassword.length < 6) {
            addToast("Kata laluan baru mesti sekurang-kurangnya 6 aksara.", "error"); return;
        }
        if (newPassword !== confirmPassword) {
            addToast("Kata laluan baru dan pengesahan tidak sepadan.", "error"); return;
        }
        
        try {
            const updatedCredentials = { ...credentials, password_plaintext: newPassword };
            await saveAdminCredentials(updatedCredentials);
            setCredentials(updatedCredentials);
            addToast("Kata laluan admin berjaya ditukar!", "success");
            setCurrentPassword(''); setNewPassword(''); setConfirmPassword('');
        } catch (err) {
            addToast("Gagal menukar kata laluan.", "error");
        }
    };

    if (!credentials) return <Spinner />;

    return (
        <form onSubmit={handleSavePassword} className="space-y-4 max-w-md mx-auto">
            <h3 className="text-2xl font-bold text-dark mb-4 border-b pb-2">Tukar Kata Laluan Admin</h3>
            <div className="relative">
                <label className="block text-sm font-medium text-gray-700">Kata Laluan Semasa</label>
                <input type={isCurrentVisible ? 'text' : 'password'} value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                <button type="button" onClick={() => setIsCurrentVisible(!isCurrentVisible)} className="absolute inset-y-0 right-0 top-6 pr-3 flex items-center text-gray-500">{isCurrentVisible ? <EyeOffIcon className="w-5 h-5"/> : <EyeIcon className="w-5 h-5"/>}</button>
            </div>
             <div className="relative">
                <label className="block text-sm font-medium text-gray-700">Kata Laluan Baru</label>
                <input type={isNewVisible ? 'text' : 'password'} value={newPassword} onChange={e => setNewPassword(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
                 <button type="button" onClick={() => setIsNewVisible(!isNewVisible)} className="absolute inset-y-0 right-0 top-6 pr-3 flex items-center text-gray-500">{isNewVisible ? <EyeOffIcon className="w-5 h-5"/> : <EyeIcon className="w-5 h-5"/>}</button>
            </div>
             <div>
                <label className="block text-sm font-medium text-gray-700">Sahkan Kata Laluan Baru</label>
                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" required />
            </div>
            <div className="text-right pt-4">
                <button type="submit" className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark">Simpan Kata Laluan</button>
            </div>
        </form>
    );
};

// --- Backup & Restore Card ---
const BackupRestoreCard: React.FC = () => {
    const { addToast } = useToast();
    const [isRestoring, setIsRestoring] = useState(false);
    const [isConfirmRestoreOpen, setIsConfirmRestoreOpen] = useState(false);
    const restoreFileInputRef = useRef<HTMLInputElement>(null);
    const [fileToRestore, setFileToRestore] = useState<File | null>(null);

    const handleBackup = async () => {
        try {
            const data = await getAllDataForBackup();
            const jsonString = JSON.stringify(data, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `sandaran_surau_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            addToast("Fail sandaran berjaya dijana.", "success");
        } catch (error) {
            addToast("Gagal membuat sandaran data.", "error");
        }
    };

    const handleRestoreFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && file.type === 'application/json') {
            setFileToRestore(file);
            setIsConfirmRestoreOpen(true);
        } else {
            addToast("Sila pilih fail JSON yang sah.", "error");
        }
    };

    const handleConfirmRestore = async () => {
        if (!fileToRestore) return;
        setIsRestoring(true);
        setIsConfirmRestoreOpen(false);

        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const text = e.target?.result;
                if (typeof text !== 'string') throw new Error("Gagal membaca fail");
                const data = JSON.parse(text);
                await restoreDataFromBackup(data);
                addToast("Data berjaya dipulihkan! Sila muat semula halaman.", "success");
                setTimeout(() => window.location.reload(), 2000);
            } catch (error) {
                addToast("Gagal memulihkan data. Fail mungkin rosak.", "error");
                setIsRestoring(false);
            }
        };
        reader.readAsText(fileToRestore);
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h3 className="text-2xl font-bold text-dark mb-4 border-b pb-2">Sandaran & Pemulihan Data</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div className="text-center p-4 bg-light rounded-lg">
                    <h4 className="font-semibold text-lg text-dark">Buat Sandaran</h4>
                    <p className="text-sm text-gray-600 my-2">Muat turun semua data sistem (ahli, kewangan, tetapan, dll.) ke dalam satu fail JSON yang selamat.</p>
                    <button onClick={handleBackup} className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Muat Turun Sandaran</button>
                </div>
                <div className="text-center p-4 bg-light rounded-lg">
                    <h4 className="font-semibold text-lg text-dark">Pulihkan Data</h4>
                    <p className="text-sm text-gray-600 my-2">Pulihkan sistem dari fail sandaran. AMARAN: Tindakan ini akan memadam semua data semasa.</p>
                    <input type="file" ref={restoreFileInputRef} onChange={handleRestoreFileSelect} accept="application/json" className="hidden" />
                    <button onClick={() => restoreFileInputRef.current?.click()} disabled={isRestoring} className="w-full bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 disabled:bg-gray-400">
                        {isRestoring ? 'Memulihkan...' : 'Pulihkan Dari Fail'}
                    </button>
                </div>
            </div>
            {isConfirmRestoreOpen && (
                 <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
                        <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">Sahkan Pemulihan Data</h2></div>
                        <div className="p-6"><p className="text-gray-700">Anda pasti ingin memulihkan data dari fail <strong>{fileToRestore?.name}</strong>? Semua data sedia ada akan dipadam dan digantikan. Tindakan ini tidak boleh dibatalkan.</p></div>
                        <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                            <button onClick={() => setIsConfirmRestoreOpen(false)} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg">Batal</button>
                            <button onClick={handleConfirmRestore} className="bg-red-600 text-white px-4 py-2 rounded-lg">Ya, Teruskan</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};


// Main Settings component
const Settings: React.FC = () => {
    const [surauInfo, setSurauInfo] = useState<SurauInfo | null>(null);
    const [financeCategories, setFinanceCategories] = useState<FinanceCategories | null>(null);
    const [dutyPersonnel, setDutyPersonnel] = useState<DutyPersonnel | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [activeTab, setActiveTab] = useState<SettingsTab>('Umum');

    const { addToast } = useToast();
    const fileInputRefs = {
        logo: useRef<HTMLInputElement>(null),
        backgroundVideo: useRef<HTMLInputElement>(null),
        azanVideo: useRef<HTMLInputElement>(null),
    };
    
    // Load data on mount
    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [infoData, categoriesData, personnelData] = await Promise.all([
                    getSurauInfo(),
                    getFinanceCategories(),
                    getDutyPersonnel()
                ]);
                setSurauInfo(infoData);
                setFinanceCategories(categoriesData);
                setDutyPersonnel(personnelData);
            } catch (err) {
                setError("Gagal memuatkan data tetapan.");
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'logo' | 'azanSubuhVideo' | 'azanVideo' | `backgroundVideo-${number}`) => {
        const file = e.target.files?.[0];
        if (file) {
            const isVideo = file.type.startsWith('video/');
            const limit = isVideo ? 50 * 1024 * 1024 : 1024 * 1024; // 50MB for video, 1MB for logo
            if (file.size > limit) {
                addToast(`Saiz fail tidak boleh melebihi ${limit / (1024 * 1024)}MB.`, "error");
                return;
            }
            const fileUrl = URL.createObjectURL(file);
            
            setSurauInfo(prev => {
                if (!prev) return null;
                if (field === 'logo') {
                    return { ...prev, logoUrl: fileUrl };
                }
                const newInfoScreenSettings = { ...prev.infoScreenSettings };
                if (field === 'azanVideo') {
                    newInfoScreenSettings.azanVideoUrl = fileUrl;
                } else if (field === 'azanSubuhVideo') {
                    newInfoScreenSettings.azanSubuhVideoUrl = fileUrl;
                } else if (field.startsWith('backgroundVideo-')) {
                    const index = parseInt(field.split('-')[1], 10);
                    const newUrls = [...newInfoScreenSettings.backgroundVideoUrls];
                    newUrls[index] = fileUrl;
                    newInfoScreenSettings.backgroundVideoUrls = newUrls;
                }
                return { ...prev, infoScreenSettings: newInfoScreenSettings as InfoScreenSettings };
            });

            addToast("Pratonton dikemaskini. Sila simpan perubahan.", "info");
        }
    };
    
    const handleVideoUrlChange = (index: number, newUrl: string) => {
        if (surauInfo?.infoScreenSettings) {
            const updatedUrls = [...surauInfo.infoScreenSettings.backgroundVideoUrls];
            updatedUrls[index] = newUrl;
            setSurauInfo({
                ...surauInfo,
                infoScreenSettings: {
                    ...surauInfo.infoScreenSettings,
                    backgroundVideoUrls: updatedUrls,
                },
            });
        }
    };

    const handleAddVideoUrl = () => {
        if (surauInfo?.infoScreenSettings) {
            const updatedUrls = [...surauInfo.infoScreenSettings.backgroundVideoUrls, ''];
            setSurauInfo({
                ...surauInfo,
                infoScreenSettings: {
                    ...surauInfo.infoScreenSettings,
                    backgroundVideoUrls: updatedUrls,
                },
            });
        }
    };

    const handleRemoveVideoUrl = (index: number) => {
        if (surauInfo?.infoScreenSettings && surauInfo.infoScreenSettings.backgroundVideoUrls.length > 1) {
            const updatedUrls = surauInfo.infoScreenSettings.backgroundVideoUrls.filter((_, i) => i !== index);
            setSurauInfo({
                ...surauInfo,
                infoScreenSettings: {
                    ...surauInfo.infoScreenSettings,
                    backgroundVideoUrls: updatedUrls,
                },
            });
        } else {
            addToast("Perlu ada sekurang-kurangnya satu video latar belakang.", "error");
        }
    };

    const handleSaveSurauInfo = async () => {
        if (surauInfo) {
            try {
                await saveSurauInfo(surauInfo);
                addToast('Maklumat Surau telah disimpan!');
                window.dispatchEvent(new CustomEvent('logoUpdated'));
            } catch (err) {
                addToast('Gagal menyimpan maklumat surau.', 'error');
            }
        }
    };
    
    const handleSaveFinanceCategories = async () => {
        if (financeCategories) {
            try {
                await saveFinanceCategories(financeCategories);
                addToast('Kategori Kewangan telah disimpan!');
            } catch (err) {
                addToast('Gagal menyimpan kategori kewangan.', 'error');
            }
        }
    };
    
    const handleSaveDutyPersonnel = async () => {
        if (dutyPersonnel) {
            try {
                await saveDutyPersonnel(dutyPersonnel);
                addToast('Senarai Petugas telah disimpan!');
            } catch (err) {
                addToast('Gagal menyimpan senarai petugas.', 'error');
            }
        }
    };
    
    if (isLoading) return <Spinner />;
    if (error || !surauInfo || !financeCategories || !dutyPersonnel) {
        return <div className="text-center p-10 text-red-600">{error || "Data penting tidak dapat dimuatkan."}</div>;
    }

    const TabButton: React.FC<{ icon: React.ReactNode, label: string, tabName: SettingsTab }> = ({ icon, label, tabName }) => (
        <button
            onClick={() => setActiveTab(tabName)}
            className={`flex-1 flex items-center justify-center p-4 rounded-lg font-semibold transition-colors duration-200 ${
                activeTab === tabName
                    ? 'bg-primary text-white shadow-md'
                    : 'text-gray-600 hover:bg-primary/10'
            }`}
        >
            {icon}
            <span className="ml-2">{label}</span>
        </button>
    );

    return (
        <div className="space-y-8">
             <h2 className="text-3xl font-bold text-dark">Tetapan Sistem</h2>
            
            {/* Tab Navigation */}
            <div className="bg-white p-2 rounded-xl shadow-md">
                <nav className="flex space-x-2">
                    <TabButton icon={<SettingsIcon className="w-5 h-5"/>} label="Umum" tabName="Umum" />
                    <TabButton icon={<DollarSignIcon className="w-5 h-5"/>} label="Kewangan" tabName="Kewangan" />
                    <TabButton icon={<DatabaseIcon className="w-5 h-5"/>} label="Data Sistem" tabName="Data Sistem" />
                    <TabButton icon={<ShieldIcon className="w-5 h-5"/>} label="Keselamatan" tabName="Keselamatan" />
                    <TabButton icon={<TvIcon className="w-5 h-5"/>} label="InfoScreen" tabName="InfoScreen" />
                </nav>
            </div>

            {/* Tab Content */}
            <div className="animate-fade-in">
                {activeTab === 'Umum' && (
                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-2xl font-bold text-dark mb-4 border-b pb-2">Maklumat Asas Surau</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
                            <div className="md:col-span-1 flex flex-col items-center text-center">
                                <label className="block text-sm font-medium text-gray-700 mb-2">Logo Surau Semasa</label>
                                <div className="w-32 h-32 mb-4 p-2 border rounded-full flex items-center justify-center bg-gray-50">
                                    <DynamicLogo className="w-24 h-24 object-contain text-primary"/>
                                </div>
                                <input type="file" accept="image/png, image/jpeg, image/svg+xml" ref={fileInputRefs.logo} onChange={(e) => handleFileChange(e, 'logo')} className="hidden" />
                                <button onClick={() => fileInputRefs.logo.current?.click()} className="bg-secondary text-white px-4 py-2 rounded-lg text-sm hover:bg-yellow-800 transition-colors">Tukar Logo</button>
                                <p className="text-xs text-gray-500 mt-2">Saiz maks: 1MB. Format: PNG, JPG, SVG.</p>
                            </div>
                            <div className="md:col-span-2 space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Nama Surau</label>
                                    <input
                                        type="text"
                                        value={surauInfo.name}
                                        onChange={(e) => setSurauInfo({ ...surauInfo, name: e.target.value })}
                                        className="mt-1 block w-full p-2 border border-gray-300 rounded-md"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Alamat Surau</label>
                                    <textarea
                                        rows={3}
                                        value={surauInfo.address}
                                        onChange={(e) => setSurauInfo({ ...surauInfo, address: e.target.value })}
                                        className="mt-1 block w-full p-2 border border-gray-300 rounded-md"
                                    />
                                </div>
                            </div>
                        </div>
                         <div className="mt-6 text-right">
                            <button onClick={handleSaveSurauInfo} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark transition-colors">Simpan Maklumat Umum</button>
                        </div>
                    </div>
                )}
                {activeTab === 'Kewangan' && (
                    <div className="space-y-8">
                        <div className="bg-white p-6 rounded-xl shadow-md">
                             <h3 className="text-2xl font-bold text-dark mb-4 border-b pb-2">Polisi & Gerbang Pembayaran</h3>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <h4 className="text-lg font-semibold text-dark mb-2">Polisi Khairat</h4>
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Amaun Khairat Ahli (RM)</label>
                                            <input type="number" step="0.01" value={surauInfo.khairatAmountMember} onChange={(e) => setSurauInfo({ ...surauInfo, khairatAmountMember: parseFloat(e.target.value) || 0 })} className="mt-1 block w-full p-2 border border-gray-300 rounded-md"/>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Amaun Khairat Tanggungan (RM)</label>
                                            <input type="number" step="0.01" value={surauInfo.khairatAmountDependent} onChange={(e) => setSurauInfo({ ...surauInfo, khairatAmountDependent: parseFloat(e.target.value) || 0 })} className="mt-1 block w-full p-2 border border-gray-300 rounded-md"/>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                     <h4 className="text-lg font-semibold text-dark mb-2">Tetapan ToyyibPay</h4>
                                     <div className="space-y-4">
                                         <div>
                                            <label className="block text-sm font-medium text-gray-700">Category Code</label>
                                            <input type="text" value={surauInfo.paymentGateway?.categoryCode || ''} onChange={(e) => setSurauInfo({ ...surauInfo, paymentGateway: { ...(surauInfo.paymentGateway || { secretKey: '' }), categoryCode: e.target.value } })} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" placeholder="cth: abcde123"/>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700">Secret Key</label>
                                            <input type="password" value={surauInfo.paymentGateway?.secretKey || ''} onChange={(e) => setSurauInfo({ ...surauInfo, paymentGateway: { ...(surauInfo.paymentGateway || { categoryCode: '' }), secretKey: e.target.value } })} className="mt-1 block w-full p-2 border border-gray-300 rounded-md" placeholder="••••••••••••••••"/>
                                        </div>
                                     </div>
                                </div>
                            </div>
                             <div className="mt-6 text-right">
                                <button onClick={handleSaveSurauInfo} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark transition-colors">Simpan Polisi & Gateway</button>
                            </div>
                        </div>

                        <div className="bg-white p-6 rounded-xl shadow-md">
                            <h3 className="text-2xl font-bold text-dark mb-4 border-b pb-2">Kategori Kewangan</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <ListManager title="Kategori Derma" items={financeCategories.income} onItemsChange={(newItems) => setFinanceCategories({ ...financeCategories, income: newItems })} />
                                <ListManager title="Kategori Perbelanjaan" items={financeCategories.expense} onItemsChange={(newItems) => setFinanceCategories({ ...financeCategories, expense: newItems })} />
                            </div>
                            <div className="mt-6 text-right">
                                <button onClick={handleSaveFinanceCategories} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark transition-colors">Simpan Kategori</button>
                            </div>
                        </div>
                    </div>
                )}
                 {activeTab === 'Data Sistem' && (
                    <div className="space-y-8">
                        <div className="bg-white p-6 rounded-xl shadow-md">
                            <h3 className="text-2xl font-bold text-dark mb-4 border-b pb-2">Senarai Petugas (Imam & Bilal)</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <ListManager title="Imam" items={dutyPersonnel.imams} onItemsChange={(newItems) => setDutyPersonnel({ ...dutyPersonnel, imams: newItems })} />
                                <ListManager title="Bilal" items={dutyPersonnel.bilals} onItemsChange={(newItems) => setDutyPersonnel({ ...dutyPersonnel, bilals: newItems })} />
                            </div>
                            <div className="mt-6 text-right">
                                <button onClick={handleSaveDutyPersonnel} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark transition-colors">Simpan Senarai Petugas</button>
                            </div>
                        </div>
                        <BackupRestoreCard />
                    </div>
                 )}
                 {activeTab === 'Keselamatan' && (
                     <div className="bg-white p-6 rounded-xl shadow-md">
                        <AdminSecurityCard />
                    </div>
                 )}
                 {activeTab === 'InfoScreen' && (
                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-2xl font-bold text-dark mb-4 border-b pb-2">Pengurusan InfoScreen</h3>
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Senarai URL Video Latar Belakang</label>
                                <p className="text-xs text-gray-500 mt-1">Video akan dimainkan secara bergiliran. Gunakan pautan awam atau muat naik fail tempatan.</p>
                                <div className="space-y-2 mt-2">
                                    {surauInfo.infoScreenSettings.backgroundVideoUrls.map((url, index) => (
                                        <div key={index} className="flex items-center gap-2">
                                            <input type="file" accept="video/mp4" onChange={(e) => handleFileChange(e, `backgroundVideo-${index}`)} className="hidden" id={`bg-video-input-${index}`} />
                                            <button type="button" onClick={() => document.getElementById(`bg-video-input-${index}`)?.click()} className="p-2 text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200" title="Cari Fail Video"><FolderOpenIcon className="w-5 h-5"/></button>
                                            <input type="text" value={url} onChange={(e) => handleVideoUrlChange(index, e.target.value)} className="flex-grow p-2 border border-gray-300 rounded-md" placeholder="URL Video"/>
                                            <button type="button" onClick={() => handleRemoveVideoUrl(index)} className="p-2 text-red-500 hover:bg-red-100 rounded-full" title="Padam URL"><TrashIcon className="w-5 h-5" /></button>
                                        </div>
                                    ))}
                                </div>
                                <button type="button" onClick={handleAddVideoUrl} className="mt-3 text-sm bg-gray-100 text-gray-800 px-3 py-1.5 rounded-md hover:bg-gray-200">+ Tambah URL Video</button>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">URL Video Azan (Subuh)</label>
                                <div className="flex items-center gap-2 mt-1">
                                    <input type="file" accept="video/mp4" onChange={(e) => handleFileChange(e, 'azanSubuhVideo')} className="hidden" id="azan-subuh-video-input" />
                                    <button type="button" onClick={() => document.getElementById('azan-subuh-video-input')?.click()} className="p-2 text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200" title="Cari Fail Video"><FolderOpenIcon className="w-5 h-5"/></button>
                                    <input type="text" value={surauInfo.infoScreenSettings.azanSubuhVideoUrl} onChange={(e) => setSurauInfo({ ...surauInfo, infoScreenSettings: { ...surauInfo.infoScreenSettings, azanSubuhVideoUrl: e.target.value } })} className="flex-grow p-2 border border-gray-300 rounded-md" placeholder="cth: /video/azan_subuh.mp4" />
                                </div>
                                <p className="text-xs text-gray-500 mt-1">Video khas yang akan dimainkan untuk Azan Subuh.</p>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">URL Video Azan (Lain-lain)</label>
                                <div className="flex items-center gap-2 mt-1">
                                    <input type="file" accept="video/mp4" onChange={(e) => handleFileChange(e, 'azanVideo')} className="hidden" id="azan-video-input" />
                                    <button type="button" onClick={() => document.getElementById('azan-video-input')?.click()} className="p-2 text-gray-600 bg-gray-100 rounded-md hover:bg-gray-200" title="Cari Fail Video"><FolderOpenIcon className="w-5 h-5"/></button>
                                    <input type="text" value={surauInfo.infoScreenSettings.azanVideoUrl} onChange={(e) => setSurauInfo({ ...surauInfo, infoScreenSettings: { ...surauInfo.infoScreenSettings, azanVideoUrl: e.target.value } })} className="flex-grow p-2 border border-gray-300 rounded-md" placeholder="cth: /video/azan.mp4" />
                                </div>
                                <p className="text-xs text-gray-500 mt-1">Video yang akan dimainkan untuk waktu solat selain Subuh.</p>
                            </div>
                        </div>
                        <div className="mt-6 text-right">
                            <button onClick={handleSaveSurauInfo} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-dark transition-colors">Simpan Tetapan InfoScreen</button>
                        </div>
                    </div>
                 )}
            </div>
        </div>
    );
};

export default Settings;