import React, { useState, useEffect } from 'react';
import { Page, ViewMode } from '../types';
import { 
    DashboardIcon, UsersIcon, DollarSignIcon, CalendarIcon, MegaphoneIcon, 
    FacebookIcon, TiktokIcon, SettingsIcon, GlobeIcon, BarChartIcon, BriefcaseIcon, 
    ClipboardListIcon, ArchiveIcon, KeyIcon, HeartHandIcon, MailIcon, BookOpenIcon, 
    GitPullRequestIcon, ChevronDownIcon, TvIcon 
} from './icons';
import DynamicLogo from './DynamicLogo';

interface SidebarProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
  setViewMode: (mode: ViewMode) => void;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: Page;
  activePage: Page;
  onClick: () => void;
}> = ({ icon, label, activePage, onClick }) => (
  <li>
    <a
      href="#"
      onClick={(e) => {
        e.preventDefault();
        onClick();
      }}
      className={`flex items-center p-2.5 my-1 rounded-lg transition-colors duration-200 text-sm ${
        activePage === label
          ? 'bg-primary text-white font-semibold'
          : 'text-gray-600 hover:bg-primary/10 hover:text-dark'
      }`}
    >
      {icon}
      <span className="ml-3">{label}</span>
    </a>
  </li>
);

const NavGroup: React.FC<{
    title: string;
    children: React.ReactNode;
    isOpen: boolean;
    onToggle: () => void;
    icon: React.ReactNode;
}> = ({ title, children, isOpen, onToggle, icon }) => (
    <div className="py-1">
        <button
            onClick={onToggle}
            className="flex items-center justify-between w-full p-3 my-1 rounded-lg text-gray-700 hover:bg-primary/10 hover:text-dark transition-colors duration-200"
        >
            <div className="flex items-center">
                {icon}
                <span className="ml-3 font-semibold">{title}</span>
            </div>
            <ChevronDownIcon className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
        </button>
        {isOpen && (
            <div className="pl-5 border-l-2 border-primary/20 ml-5 mt-1">
                <ul>{children}</ul>
            </div>
        )}
    </div>
);


const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage, setViewMode }) => {
  const navGroups = [
    {
      title: 'Pengurusan Utama',
      icon: <BriefcaseIcon className="w-6 h-6"/>,
      items: [
        { icon: <DashboardIcon className="w-5 h-5" />, label: Page.Dashboard },
        { icon: <UsersIcon className="w-5 h-5" />, label: Page.Kariah },
        { icon: <BriefcaseIcon className="w-5 h-5" />, label: Page.Jawatankuasa },
        { icon: <ClipboardListIcon className="w-5 h-5" />, label: Page.Pemilihan },
      ],
    },
    {
      title: 'Operasi Kewangan',
      icon: <DollarSignIcon className="w-6 h-6"/>,
      items: [
        { icon: <DollarSignIcon className="w-5 h-5" />, label: Page.Kewangan },
        { icon: <BarChartIcon className="w-5 h-5" />, label: Page.Laporan },
        { icon: <HeartHandIcon className="w-5 h-5" />, label: Page.Korban },
      ],
    },
    {
      title: 'Operasi Surau',
      icon: <ArchiveIcon className="w-6 h-6"/>,
      items: [
        { icon: <ArchiveIcon className="w-5 h-5" />, label: Page.Aset },
        { icon: <KeyIcon className="w-5 h-5" />, label: Page.Tempahan },
        { icon: <CalendarIcon className="w-5 h-5" />, label: Page.Jadual },
      ],
    },
    {
        title: 'Komuniti & Program',
        icon: <MegaphoneIcon className="w-6 h-6"/>,
        items: [
            { icon: <MegaphoneIcon className="w-5 h-5" />, label: Page.Aktiviti },
            { icon: <BookOpenIcon className="w-5 h-5" />, label: Page.Kelas },
            { icon: <MailIcon className="w-5 h-5" />, label: Page.Notifikasi },
        ],
    },
    {
        title: 'Sistem',
        icon: <SettingsIcon className="w-6 h-6"/>,
        items: [
            { icon: <GitPullRequestIcon className="w-5 h-5" />, label: Page.UpdateSistem },
            { icon: <SettingsIcon className="w-5 h-5" />, label: Page.Tetapan },
            { icon: <TvIcon className="w-5 h-5" />, label: Page.InfoScreen },
        ],
    }
  ];

  const getActiveGroup = (page: Page) => navGroups.find(g => g.items.some(i => i.label === page))?.title;

  const [openGroups, setOpenGroups] = useState<string[]>([getActiveGroup(activePage) || '']);

  useEffect(() => {
    const activeGroupName = getActiveGroup(activePage);
    if (activeGroupName && !openGroups.includes(activeGroupName)) {
        setOpenGroups(prev => [...prev, activeGroupName]);
    }
  }, [activePage]);

  const toggleGroup = (title: string) => {
    setOpenGroups(prev => prev.includes(title) ? prev.filter(g => g !== title) : [...prev, title]);
  };
  

  return (
    <div className="w-64 bg-white text-dark flex flex-col shadow-lg h-full print-hidden">
      <div className="flex items-center justify-center p-6 border-b border-gray-200">
         <DynamicLogo className="w-12 h-12 text-primary object-contain" />
        <div className="ml-3 text-left">
            <h1 className="text-lg font-bold text-dark">Surau Salman</h1>
            <p className="text-xs text-gray-500">Al-Farisi</p>
        </div>
      </div>
      <nav className="flex-1 p-3">
          {navGroups.map((group) => (
             <NavGroup 
                key={group.title}
                title={group.title}
                icon={group.icon}
                isOpen={openGroups.includes(group.title)}
                onToggle={() => toggleGroup(group.title)}
             >
                {group.items.map((item) => (
                    <NavItem
                        key={item.label}
                        icon={item.icon}
                        label={item.label}
                        activePage={activePage}
                        onClick={() => setActivePage(item.label)}
                    />
                ))}
             </NavGroup>
          ))}
      </nav>
      <div className="p-4 border-t border-gray-200">
        <button
          onClick={() => setViewMode('Public')}
          className="w-full flex items-center justify-center p-3 my-2 rounded-lg transition-colors text-gray-700 hover:bg-primary/10 hover:text-dark border border-gray-200"
        >
          <GlobeIcon className="w-5 h-5" />
          <span className="ml-3 font-medium text-sm">Lihat Laman Awam</span>
        </button>
        <p className="text-center text-xs text-gray-500 mt-4 mb-3">Ikuti kami di media sosial:</p>
        <div className="flex justify-center space-x-4">
          <a href="#" className="text-gray-500 hover:text-blue-600"><FacebookIcon className="w-6 h-6" /></a>
          <a href="#" className="text-gray-500 hover:text-black"><TiktokIcon className="w-6 h-6" /></a>
        </div>
        <p className="text-center text-xs text-gray-400 mt-4">© 2024 Jawatankuasa Penaja</p>
      </div>
    </div>
  );
};

export default Sidebar;