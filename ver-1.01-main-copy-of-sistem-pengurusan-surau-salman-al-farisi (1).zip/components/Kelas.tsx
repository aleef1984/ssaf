import React, { useState, useEffect, useMemo } from 'react';
import { useToast } from '../App';
import { getClassSessions, saveClassSessions, getSpeakers, saveSpeakers, getTransactions, saveTransactions } from '../services/dataService';
import { ClassSession, Speaker, Transaction } from '../types';
import Spinner from './Spinner';
import { PlusIcon, PencilIcon, TrashIcon, CloseIcon, DollarSignIcon, BookOpenIcon, UsersIcon, CalendarIcon, ClockIcon } from './icons';

type ActiveTab = 'jadual' | 'penceramah';

// Stat Card Component
const StatCard: React.FC<{ icon: React.ReactNode; title: string; value: string; color: string }> = ({ icon, title, value, color }) => (
    <div className={`bg-white p-5 rounded-xl shadow-md flex items-center space-x-4 border-l-4 ${color}`}>
        <div className="p-3 bg-gray-100 rounded-full">{icon}</div>
        <div>
            <p className="text-sm text-gray-500 font-medium">{title}</p>
            <p className="text-2xl font-bold text-dark">{value}</p>
        </div>
    </div>
);

// Reusable Confirmation Modal
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan" }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{title}</h2></div>
            <div className="p-6"><p className="text-gray-700">{message}</p></div>
            <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Padam</button>
            </div>
        </div>
    </div>
);

// Speaker Form Modal
const SpeakerFormModal: React.FC<{
    onClose: () => void;
    onSave: (speakerData: Omit<Speaker, 'id'>) => void;
    speakerToEdit: Speaker | null;
}> = ({ onClose, onSave, speakerToEdit }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [expertise, setExpertise] = useState('');

    useEffect(() => {
        if (speakerToEdit) {
            setName(speakerToEdit.name);
            setPhone(speakerToEdit.phone || '');
            setExpertise(speakerToEdit.expertise || '');
        }
    }, [speakerToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name) { addToast('Sila masukkan nama penceramah.', 'error'); return; }
        onSave({ name, phone, expertise });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{speakerToEdit ? 'Kemaskini Penceramah' : 'Tambah Penceramah Baru'}</h2></div>
                <div className="p-6 space-y-4">
                    <div><label>Nama Penceramah*</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full mt-1 p-2 border rounded-md" required /></div>
                    <div><label>No. Telefon</label><input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full mt-1 p-2 border rounded-md" /></div>
                    <div><label>Bidang Kepakaran</label><input type="text" value={expertise} onChange={e => setExpertise(e.target.value)} className="w-full mt-1 p-2 border rounded-md" /></div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                    <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">{speakerToEdit ? 'Simpan' : 'Tambah'}</button>
                </div>
            </form>
        </div>
    );
};

// Session Form Modal
const SessionFormModal: React.FC<{
    onClose: () => void;
    onSave: (sessionData: Omit<ClassSession, 'id' | 'paymentStatus'>) => void;
    sessionToEdit: ClassSession | null;
    speakers: Speaker[];
}> = ({ onClose, onSave, sessionToEdit, speakers }) => {
    const { addToast } = useToast();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [speakerId, setSpeakerId] = useState<number | ''>('');
    const [isRecurring, setIsRecurring] = useState(true);
    const [day, setDay] = useState<'Isnin' | 'Selasa' | 'Rabu' | 'Khamis' | 'Jumaat' | 'Sabtu' | 'Ahad' | ''>('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [honorarium, setHonorarium] = useState<number | ''>('');

    useEffect(() => {
        if (sessionToEdit) {
            setTitle(sessionToEdit.title);
            setDescription(sessionToEdit.description || '');
            setSpeakerId(sessionToEdit.speakerId);
            setIsRecurring(sessionToEdit.isRecurring);
            setDay(sessionToEdit.day || '');
            setDate(sessionToEdit.date || '');
            setTime(sessionToEdit.time);
            setHonorarium(sessionToEdit.honorarium);
        }
    }, [sessionToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !speakerId || !time || honorarium === '' || (isRecurring && !day) || (!isRecurring && !date)) {
            addToast('Sila isi semua medan yang diperlukan.', 'error'); return;
        }
        onSave({ title, description, speakerId, isRecurring, day: (isRecurring && day) ? day : undefined, date: !isRecurring ? date : undefined, time, honorarium: Number(honorarium) });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <div className="p-6 border-b flex justify-between items-center"><h2 className="text-xl font-bold text-dark">{sessionToEdit ? 'Kemaskini Kelas/Kuliah' : 'Tambah Kelas/Kuliah Baru'}</h2><button type="button" onClick={onClose}><CloseIcon className="w-6 h-6"/></button></div>
                <div className="p-6 space-y-4 overflow-y-auto">
                    <div><label>Tajuk*</label><input type="text" value={title} onChange={e => setTitle(e.target.value)} className="w-full mt-1 p-2 border rounded-md" required /></div>
                    <div><label>Keterangan Ringkas</label><textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full mt-1 p-2 border rounded-md" placeholder="Terangkan sedikit tentang kuliah ini..."/></div>
                    <div><label>Penceramah*</label><select value={speakerId} onChange={e => setSpeakerId(Number(e.target.value))} className="w-full mt-1 p-2 border rounded-md" required><option value="" disabled>Pilih penceramah</option>{speakers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
                    <div><label className="flex items-center"><input type="checkbox" checked={isRecurring} onChange={e => setIsRecurring(e.target.checked)} className="h-4 w-4 rounded-md" /><span className="ml-2">Kelas Berulang</span></label></div>
                    {isRecurring ? (
                        <div><label>Hari*</label><select value={day} onChange={e => setDay(e.target.value as any)} className="w-full mt-1 p-2 border rounded-md" required><option value="" disabled>Pilih hari</option>{['Isnin', 'Selasa', 'Rabu', 'Khamis', 'Jumaat', 'Sabtu', 'Ahad'].map(d => <option key={d} value={d}>{d}</option>)}</select></div>
                    ) : (
                        <div><label>Tarikh*</label><input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full mt-1 p-2 border rounded-md" required /></div>
                    )}
                    <div className="grid grid-cols-2 gap-4">
                        <div><label>Masa*</label><input type="text" value={time} onChange={e => setTime(e.target.value)} placeholder="cth: Selepas Maghrib, 9:00 PM" className="w-full mt-1 p-2 border rounded-md" required /></div>
                        <div><label>Honorarium (RM)*</label><input type="number" value={honorarium} onChange={e => setHonorarium(e.target.value === '' ? '' : Number(e.target.value))} className="w-full mt-1 p-2 border rounded-md" required /></div>
                    </div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end space-x-3 mt-auto">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                    <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">{sessionToEdit ? 'Simpan' : 'Tambah'}</button>
                </div>
            </form>
        </div>
    );
};


const Kelas: React.FC = () => {
    const [activeTab, setActiveTab] = useState<ActiveTab>('jadual');
    const [sessions, setSessions] = useState<ClassSession[]>([]);
    const [speakers, setSpeakers] = useState<Speaker[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { addToast } = useToast();

    // Modal states
    const [isSessionFormOpen, setIsSessionFormOpen] = useState(false);
    const [sessionToEdit, setSessionToEdit] = useState<ClassSession | null>(null);
    const [isSpeakerFormOpen, setIsSpeakerFormOpen] = useState(false);
    const [speakerToEdit, setSpeakerToEdit] = useState<Speaker | null>(null);
    const [itemToDelete, setItemToDelete] = useState<{ type: 'session' | 'speaker', id: number, name: string } | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [sessionsData, speakersData] = await Promise.all([getClassSessions(), getSpeakers()]);
                setSessions(sessionsData);
                setSpeakers(speakersData);
            } catch (err) {
                setError("Gagal memuatkan data kelas & kuliah.");
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const speakerMap = useMemo(() => new Map(speakers.map(s => [s.id, s.name])), [speakers]);

    const handleSaveSession = async (data: Omit<ClassSession, 'id' | 'paymentStatus'>) => {
        let updatedSessions: ClassSession[];
        if (sessionToEdit) {
            updatedSessions = sessions.map(s => s.id === sessionToEdit.id ? { ...sessionToEdit, ...data } : s);
        } else {
            updatedSessions = [{ ...data, id: Date.now(), paymentStatus: 'Belum Dibayar' }, ...sessions];
        }
        try {
            await saveClassSessions(updatedSessions);
            setSessions(updatedSessions);
            addToast(`Jadual kuliah "${data.title}" telah disimpan.`);
        } catch { addToast("Gagal menyimpan jadual kuliah.", "error"); }
        finally { setIsSessionFormOpen(false); }
    };

    const handleSaveSpeaker = async (data: Omit<Speaker, 'id'>) => {
        let updatedSpeakers: Speaker[];
        if (speakerToEdit) {
            updatedSpeakers = speakers.map(s => s.id === speakerToEdit.id ? { ...speakerToEdit, ...data } : s);
        } else {
            updatedSpeakers = [{ id: Date.now(), ...data }, ...speakers];
        }
        try {
            await saveSpeakers(updatedSpeakers);
            setSpeakers(updatedSpeakers);
            addToast(`Penceramah "${data.name}" telah disimpan.`);
        } catch { addToast("Gagal menyimpan penceramah.", "error"); }
        finally { setIsSpeakerFormOpen(false); }
    };
    
    const handleConfirmDelete = async () => {
        if (!itemToDelete) return;
        if (itemToDelete.type === 'session') {
            const updated = sessions.filter(s => s.id !== itemToDelete.id);
            try { await saveClassSessions(updated); setSessions(updated); addToast("Jadual kuliah telah dipadam."); }
            catch { addToast("Gagal memadam jadual kuliah.", "error"); }
        } else {
            const updated = speakers.filter(s => s.id !== itemToDelete.id);
            try { await saveSpeakers(updated); setSpeakers(updated); addToast("Penceramah telah dipadam."); }
            catch { addToast("Gagal memadam penceramah.", "error"); }
        }
        setItemToDelete(null);
    };

    const handleMarkAsPaid = async (session: ClassSession) => {
        const updatedSessions = sessions.map(s => s.id === session.id ? { ...s, paymentStatus: 'Sudah Dibayar' as const } : s);
        
        const newTransaction: Transaction = {
            id: `TXN-HON-${Date.now()}`,
            date: new Date().toISOString(),
            description: `Bayaran honorarium untuk ${session.title} oleh ${speakerMap.get(session.speakerId)}`,
            type: 'Perbelanjaan',
            amount: -session.honorarium,
            category: 'Honorarium Penceramah',
        };

        try {
            const currentTransactions = await getTransactions();
            const updatedTransactions = [newTransaction, ...currentTransactions];
            await Promise.all([
                saveClassSessions(updatedSessions),
                saveTransactions(updatedTransactions)
            ]);
            setSessions(updatedSessions);
            addToast(`Honorarium untuk ${session.title} telah dibayar.`);
        } catch {
            addToast("Gagal merekodkan pembayaran.", "error");
        }
    };
    
    const { upcomingClasses, pendingHonorarium } = useMemo(() => {
        const today = new Date();
        today.setHours(0,0,0,0);
        const upcoming = sessions.filter(s => s.date ? new Date(s.date) >= today : true).length;
        const pending = sessions.filter(s => s.paymentStatus === 'Belum Dibayar').reduce((sum, s) => sum + s.honorarium, 0);
        return { upcomingClasses: upcoming, pendingHonorarium: pending };
    }, [sessions]);


    const TabButton: React.FC<{ name: string; icon: React.ReactNode; current: string; target: string; onClick: () => void }> = ({ name, icon, current, target, onClick }) => (
         <button onClick={onClick} className={`whitespace-nowrap py-4 px-3 border-b-2 font-medium text-sm flex items-center gap-2 ${current === target ? 'border-primary text-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
            {icon} {name}
        </button>
    );

    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    return (
        <div className="space-y-8">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 <StatCard icon={<BookOpenIcon className="w-7 h-7 text-primary"/>} title="Kuliah Akan Datang" value={upcomingClasses.toString()} color="border-primary" />
                 <StatCard icon={<DollarSignIcon className="w-7 h-7 text-secondary"/>} title="Honorarium Tertunggak" value={`RM ${pendingHonorarium.toFixed(2)}`} color="border-secondary" />
                 <StatCard icon={<UsersIcon className="w-7 h-7 text-blue-600"/>} title="Jumlah Penceramah" value={speakers.length.toString()} color="border-blue-600" />
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 gap-4">
                    <div className="border-b border-gray-200 w-full md:w-auto md:border-b-0">
                        <nav className="-mb-px flex space-x-6">
                            <TabButton name="Jadual Kuliah" icon={<CalendarIcon className="w-5 h-5"/>} current={activeTab} target="jadual" onClick={() => setActiveTab('jadual')} />
                            <TabButton name="Senarai Penceramah" icon={<UsersIcon className="w-5 h-5"/>} current={activeTab} target="penceramah" onClick={() => setActiveTab('penceramah')} />
                        </nav>
                    </div>
                    <div>
                        {activeTab === 'jadual' ? (
                            <button onClick={() => { setSessionToEdit(null); setIsSessionFormOpen(true); }} className="w-full md:w-auto flex items-center justify-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark"><PlusIcon className="w-5 h-5 mr-2" /> Tambah Jadual</button>
                        ) : (
                            <button onClick={() => { setSpeakerToEdit(null); setIsSpeakerFormOpen(true); }} className="w-full md:w-auto flex items-center justify-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark"><PlusIcon className="w-5 h-5 mr-2" /> Tambah Penceramah</button>
                        )}
                    </div>
                </div>

                {activeTab === 'jadual' ? (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {sessions.map(s => (
                            <div key={s.id} className="bg-light p-5 rounded-lg border border-gray-200 shadow-sm flex flex-col">
                                <div className="flex-grow">
                                    <div className="flex justify-between items-start">
                                        <h3 className="text-lg font-bold text-dark">{s.title}</h3>
                                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${s.paymentStatus === 'Sudah Dibayar' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{s.paymentStatus}</span>
                                    </div>
                                    <p className="text-sm text-primary font-medium mt-1">{speakerMap.get(s.speakerId) || 'N/A'}</p>
                                    <p className="text-xs text-gray-500 mt-2">{s.description}</p>
                                    <div className="flex items-center text-sm text-gray-600 mt-3 border-t pt-3">
                                        <CalendarIcon className="w-4 h-4 mr-2" />
                                        <span>{s.isRecurring ? s.day : new Date(s.date!).toLocaleDateString('ms-MY')}</span>
                                        <ClockIcon className="w-4 h-4 ml-4 mr-2" />
                                        <span>{s.time}</span>
                                    </div>
                                </div>
                                <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200">
                                    <p className="text-lg font-bold text-dark">RM {s.honorarium.toFixed(2)}</p>
                                    <div className="flex items-center space-x-1">
                                        {s.paymentStatus === 'Belum Dibayar' && <button onClick={() => handleMarkAsPaid(s)} className="p-2 text-green-600 hover:bg-green-100 rounded-full" title="Bayar Honorarium"><DollarSignIcon className="w-5 h-5"/></button>}
                                        <button onClick={() => { setSessionToEdit(s); setIsSessionFormOpen(true); }} className="p-2 text-secondary hover:bg-yellow-100 rounded-full" title="Kemaskini"><PencilIcon className="w-5 h-5"/></button>
                                        <button onClick={() => setItemToDelete({type: 'session', id: s.id, name: s.title})} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="Padam"><TrashIcon className="w-5 h-5"/></button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {speakers.map(s => {
                             const classCount = sessions.filter(cs => cs.speakerId === s.id).length;
                             return (
                                <div key={s.id} className="bg-light p-5 rounded-lg border border-gray-200 shadow-sm text-center">
                                    <div className="w-16 h-16 rounded-full bg-primary text-white flex items-center justify-center text-2xl font-bold mx-auto mb-3">{s.name.charAt(0)}</div>
                                    <h3 className="font-bold text-lg text-dark">{s.name}</h3>
                                    <p className="text-sm text-gray-600">{s.expertise}</p>
                                    <p className="text-sm text-gray-500">{s.phone}</p>
                                    <div className="mt-3 text-xs text-blue-700 bg-blue-100 px-2 py-1 rounded-full inline-block">{classCount} kuliah dijadualkan</div>
                                    <div className="flex items-center justify-center space-x-1 mt-4 pt-4 border-t">
                                        <button onClick={() => { setSpeakerToEdit(s); setIsSpeakerFormOpen(true); }} className="p-2 text-secondary hover:bg-yellow-100 rounded-full" title="Kemaskini"><PencilIcon className="w-5 h-5"/></button>
                                        <button onClick={() => setItemToDelete({type: 'speaker', id: s.id, name: s.name})} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="Padam"><TrashIcon className="w-5 h-5"/></button>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                )}
            </div>

            {isSessionFormOpen && <SessionFormModal onClose={() => setIsSessionFormOpen(false)} onSave={handleSaveSession} sessionToEdit={sessionToEdit} speakers={speakers} />}
            {isSpeakerFormOpen && <SpeakerFormModal onClose={() => setIsSpeakerFormOpen(false)} onSave={handleSaveSpeaker} speakerToEdit={speakerToEdit} />}
            {itemToDelete && <ConfirmationModal onClose={() => setItemToDelete(null)} onConfirm={handleConfirmDelete} message={`Anda pasti ingin memadam "${itemToDelete.name}"?`} />}
        </div>
    );
};

export default Kelas;