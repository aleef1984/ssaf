import React, { useState } from 'react';
import { useToast } from '../App';
import { analyzeFeedback } from '../services/geminiService';
import { FeedbackAnalysis } from '../types';
import Spinner from './Spinner';
import { ArrowUpCircleIcon, GitPullRequestIcon, SparklesIcon, LightbulbIcon, CheckCircleIcon } from './icons';

const UpdateSistem: React.FC = () => {
    const { addToast } = useToast();
    const [currentVersion] = useState('Ver 1.01');
    const [newVersionInfo, setNewVersionInfo] = useState<{ version: string; releaseNotes: string[] } | null>(null);
    const [isChecking, setIsChecking] = useState(false);
    const [isUpdating, setIsUpdating] = useState(false);
    const [updateComplete, setUpdateComplete] = useState(false);
    
    const [feedbackText, setFeedbackText] = useState('');
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysisResult, setAnalysisResult] = useState<FeedbackAnalysis | null>(null);

    const handleCheckForUpdate = () => {
        setIsChecking(true);
        setNewVersionInfo(null);
        setTimeout(() => {
            setNewVersionInfo({
                version: 'Ver 1.02',
                releaseNotes: [
                    'Modul "Update Sistem" ditambah untuk pemeriksaan versi dan maklum balas.',
                    'Penambahbaikan prestasi pada modul Ahli Kariah.',
                    'Pembetulan pepijat kecil pada borang tempahan fasiliti.',
                    'Ikon baru ditambah untuk navigasi yang lebih jelas.',
                ],
            });
            setIsChecking(false);
            addToast('Kemas kini baru ditemui!', 'info');
        }, 2000);
    };

    const handleUpdateNow = () => {
        setIsUpdating(true);
        setTimeout(() => {
            setIsUpdating(false);
            setUpdateComplete(true);
            addToast('Sistem berjaya dikemaskini ke versi terbaru!', 'success');
        }, 3000);
    };

    const handleAnalyzeFeedback = async () => {
        if (!feedbackText.trim()) {
            addToast('Sila masukkan maklum balas untuk dianalisis.', 'error');
            return;
        }
        setIsAnalyzing(true);
        setAnalysisResult(null);
        try {
            const result = await analyzeFeedback(feedbackText);
            if (typeof result === 'string') {
                addToast(result, 'error');
            } else {
                setAnalysisResult(result);
                addToast('Analisis maklum balas selesai.', 'success');
            }
        } catch (error) {
            addToast('Gagal menganalisis maklum balas.', 'error');
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <div className="space-y-8">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* System Update Column */}
                <div className="space-y-8">
                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-xl font-bold text-dark flex items-center mb-4"><GitPullRequestIcon className="w-6 h-6 mr-3 text-primary"/>Status Sistem</h3>
                        <div className="flex justify-between items-center p-4 bg-light rounded-lg">
                            <div>
                                <p className="text-sm text-gray-500">Versi Semasa</p>
                                <p className="text-2xl font-bold text-dark">{updateComplete ? newVersionInfo?.version : currentVersion}</p>
                            </div>
                            <button onClick={handleCheckForUpdate} disabled={isChecking || updateComplete} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark disabled:bg-gray-400 flex items-center justify-center min-w-[150px]">
                                {isChecking ? <Spinner/> : 'Semak Kemas Kini'}
                            </button>
                        </div>
                         {updateComplete && (
                            <div className="mt-4 p-4 bg-green-50 text-green-800 rounded-lg flex items-center gap-3 border border-green-200">
                                <CheckCircleIcon className="w-6 h-6"/>
                                <div>
                                    <p className="font-bold">Sistem terkini!</p>
                                    <p className="text-sm">Anda sedang menggunakan versi terbaru.</p>
                                </div>
                            </div>
                        )}
                    </div>
                    {newVersionInfo && !updateComplete && (
                         <div className="bg-white p-6 rounded-xl shadow-md animate-fade-in">
                            <h3 className="text-xl font-bold text-dark flex items-center mb-4"><ArrowUpCircleIcon className="w-6 h-6 mr-3 text-secondary"/>Kemas Kini Tersedia: {newVersionInfo.version}</h3>
                            <div className="p-4 bg-light rounded-lg space-y-3">
                                <h4 className="font-semibold text-dark">Nota Keluaran:</h4>
                                <ul className="list-disc list-inside text-gray-700 text-sm space-y-1">
                                    {newVersionInfo.releaseNotes.map((note, index) => <li key={index}>{note}</li>)}
                                </ul>
                                <button onClick={handleUpdateNow} disabled={isUpdating} className="w-full mt-4 bg-secondary text-white px-4 py-3 rounded-lg hover:bg-yellow-800 disabled:bg-gray-400 flex justify-center items-center font-bold">
                                    {isUpdating ? <Spinner/> : 'Pasang Kemas Kini Sekarang'}
                                </button>
                            </div>
                        </div>
                    )}
                </div>
                 {/* Feedback Column */}
                <div className="bg-white p-6 rounded-xl shadow-md">
                     <h3 className="text-xl font-bold text-dark flex items-center mb-4"><LightbulbIcon className="w-6 h-6 mr-3 text-primary"/>Pusat Maklum Balas & Cadangan</h3>
                    <textarea 
                        value={feedbackText}
                        onChange={(e) => setFeedbackText(e.target.value)}
                        rows={6}
                        className="w-full p-3 border border-gray-300 rounded-lg text-sm"
                        placeholder="Tuliskan sebarang cadangan penambahbaikan atau laporan pepijat di sini..."
                    />
                    <button onClick={handleAnalyzeFeedback} disabled={isAnalyzing || !feedbackText.trim()} className="w-full mt-3 bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark disabled:bg-gray-400 flex justify-center items-center min-h-[40px]">
                        {isAnalyzing ? <Spinner/> : <><SparklesIcon className="w-5 h-5 mr-2"/>Analisis Maklum Balas (AI)</>}
                    </button>
                    {analysisResult && (
                        <div className="mt-4 p-4 bg-light rounded-lg border animate-fade-in space-y-4">
                            <div>
                                <h4 className="font-bold text-primary">Ringkasan Analisis</h4>
                                <p className="text-sm text-gray-800 italic">"{analysisResult.summary}"</p>
                            </div>
                             <div>
                                <h4 className="font-bold text-primary">Item Cadangan</h4>
                                <ul className="space-y-2 mt-2">
                                    {analysisResult.suggestions.map((s, i) => (
                                        <li key={i} className="p-3 bg-white border-l-4 border-secondary rounded-r-md shadow-sm">
                                            <span className="font-semibold text-xs text-dark bg-secondary/20 px-2 py-0.5 rounded-full">{s.category}</span>
                                            <p className="text-sm mt-1 text-gray-700">{s.details}</p>
                                        </li>
                                    ))}
                                     {analysisResult.suggestions.length === 0 && <p className="text-sm text-gray-500">Tiada item cadangan khusus ditemui.</p>}
                                </ul>
                            </div>
                        </div>
                    )}
                </div>
             </div>
        </div>
    );
};

export default UpdateSistem;
