import React, { useState, useEffect, useMemo } from 'react';
import { getQurbanSessions, saveQurbanSessions, getQurbanParticipants, saveQurbanParticipants } from '../services/dataService';
import { QurbanSession, QurbanParticipant } from '../types';
import { useToast } from '../App';
import Spinner from './Spinner';
import { CloseIcon, PlusIcon, PencilIcon, TrashIcon } from './icons';

// Confirmation Modal
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan" }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{title}</h2></div>
            <div className="p-6"><p className="text-gray-700">{message}</p></div>
            <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Padam</button>
            </div>
        </div>
    </div>
);


// Session Form Modal
const SessionFormModal: React.FC<{
    onClose: () => void;
    onSave: (session: Omit<QurbanSession, 'id'>) => void;
    sessionToEdit: QurbanSession | null;
}> = ({ onClose, onSave, sessionToEdit }) => {
    const { addToast } = useToast();
    const [title, setTitle] = useState('');
    const [year, setYear] = useState(new Date().getFullYear());
    const [pricePerPart, setPricePerPart] = useState<number | ''>('');
    const [totalParts, setTotalParts] = useState<number | ''>('');
    const [status, setStatus] = useState<'Buka' | 'Tutup'>('Buka');

    useEffect(() => {
        if (sessionToEdit) {
            setTitle(sessionToEdit.title);
            setYear(sessionToEdit.year);
            setPricePerPart(sessionToEdit.pricePerPart);
            setTotalParts(sessionToEdit.totalParts);
            setStatus(sessionToEdit.status);
        }
    }, [sessionToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || pricePerPart === '' || totalParts === '') {
            addToast('Sila isi semua medan yang diperlukan.', 'error'); return;
        }
        onSave({ year, title, pricePerPart, totalParts, status });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-lg">
                <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{sessionToEdit ? 'Kemaskini Sesi' : 'Tambah Sesi Korban Baru'}</h2></div>
                <div className="p-6 space-y-4">
                    <div><label>Tajuk Sesi</label><input type="text" value={title} onChange={e => setTitle(e.target.value)} className="w-full mt-1 p-2 border rounded" required /></div>
                    <div className="grid grid-cols-2 gap-4">
                        <div><label>Tahun</label><input type="number" value={year} onChange={e => setYear(Number(e.target.value))} className="w-full mt-1 p-2 border rounded" required /></div>
                        <div><label>Status</label><select value={status} onChange={e => setStatus(e.target.value as any)} className="w-full mt-1 p-2 border rounded"><option value="Buka">Buka</option><option value="Tutup">Tutup</option></select></div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div><label>Harga 1 Bahagian (RM)</label><input type="number" value={pricePerPart} onChange={e => setPricePerPart(Number(e.target.value))} className="w-full mt-1 p-2 border rounded" required /></div>
                        <div><label>Jumlah Kuota Bahagian</label><input type="number" value={totalParts} onChange={e => setTotalParts(Number(e.target.value))} className="w-full mt-1 p-2 border rounded" required /></div>
                    </div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                    <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">{sessionToEdit ? 'Simpan' : 'Tambah'}</button>
                </div>
            </form>
        </div>
    );
};


const Korban: React.FC = () => {
    const [sessions, setSessions] = useState<QurbanSession[]>([]);
    const [participants, setParticipants] = useState<QurbanParticipant[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [sessionToEdit, setSessionToEdit] = useState<QurbanSession | null>(null);
    const [sessionToDelete, setSessionToDelete] = useState<QurbanSession | null>(null);
    const { addToast } = useToast();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [sessionsData, participantsData] = await Promise.all([getQurbanSessions(), getQurbanParticipants()]);
                setSessions(sessionsData);
                setParticipants(participantsData);
            } catch (err) {
                setError("Gagal memuatkan data korban."); console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleSaveSession = async (data: Omit<QurbanSession, 'id'>) => {
        let updatedSessions: QurbanSession[];
        if (sessionToEdit) {
            updatedSessions = sessions.map(s => s.id === sessionToEdit.id ? { ...sessionToEdit, ...data } : s);
        } else {
            updatedSessions = [{ id: Date.now(), ...data }, ...sessions];
        }
        try {
            await saveQurbanSessions(updatedSessions);
            setSessions(updatedSessions);
            addToast(`Sesi "${data.title}" telah disimpan.`);
        } catch (err) {
            addToast("Gagal menyimpan sesi.", "error");
        } finally {
            setIsFormModalOpen(false);
        }
    };
    
    const handleConfirmDelete = async () => {
        if (!sessionToDelete) return;
        const updatedSessions = sessions.filter(s => s.id !== sessionToDelete.id);
        const updatedParticipants = participants.filter(p => p.sessionId !== sessionToDelete.id); // Also delete participants of the session
        try {
            await saveQurbanSessions(updatedSessions);
            await saveQurbanParticipants(updatedParticipants);
            setSessions(updatedSessions);
            setParticipants(updatedParticipants);
            addToast(`Sesi "${sessionToDelete.title}" telah dipadam.`);
        } catch (err) {
            addToast("Gagal memadam sesi.", "error");
        } finally {
            setSessionToDelete(null);
        }
    };

    const sessionStats = useMemo(() => {
        return sessions.map(session => {
            const sessionParticipants = participants.filter(p => p.sessionId === session.id);
            const partsSold = sessionParticipants.reduce((sum, p) => sum + p.parts, 0);
            const totalCollection = sessionParticipants.filter(p => p.paymentStatus === 'Lunas').reduce((sum, p) => sum + p.totalAmount, 0);
            return { ...session, partsSold, totalCollection };
        });
    }, [sessions, participants]);

    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-dark">Pengurusan Korban & Aqiqah</h2>
                <button onClick={() => { setSessionToEdit(null); setIsFormModalOpen(true); }} className="flex items-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">
                    <PlusIcon className="w-5 h-5 mr-2" /> Cipta Sesi Baru
                </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-bold text-dark mb-4">Sesi Program Korban</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-100"><tr>
                            <th className="p-3">Sesi</th><th className="p-3">Harga/Bahagian (RM)</th>
                            <th className="p-3">Bahagian Terjual</th><th className="p-3">Jumlah Kutipan (RM)</th>
                            <th className="p-3">Status</th><th className="p-3 text-center">Tindakan</th></tr></thead>
                        <tbody>
                            {sessionStats.map(stat => (
                                <tr key={stat.id} className="border-b hover:bg-gray-50">
                                    <td className="p-3 font-semibold text-dark">{stat.title}</td>
                                    <td className="p-3">{stat.pricePerPart.toFixed(2)}</td>
                                    <td className="p-3">{stat.partsSold} / {stat.totalParts}</td>
                                    <td className="p-3 font-medium text-green-700">{stat.totalCollection.toFixed(2)}</td>
                                    <td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${stat.status === 'Buka' ? 'bg-green-100 text-green-800' : 'bg-gray-200 text-gray-700'}`}>{stat.status}</span></td>
                                    <td className="p-3">
                                        <div className="flex items-center justify-center space-x-2">
                                            <button onClick={() => { setSessionToEdit(stat); setIsFormModalOpen(true); }} className="p-2 text-secondary hover:bg-yellow-100 rounded-full" title="Kemaskini"><PencilIcon className="w-5 h-5"/></button>
                                            <button onClick={() => setSessionToDelete(stat)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="Padam"><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {sessions.length === 0 && <div className="text-center py-10 text-gray-500"><p>Tiada sesi korban direkodkan.</p></div>}
                </div>
            </div>

             <div className="bg-white p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-bold text-dark mb-4">Senarai Peserta (Semua Sesi)</h3>
                 <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-100"><tr>
                            <th className="p-3">Nama Peserta</th><th className="p-3">Telefon</th><th className="p-3">Bahagian</th>
                            <th className="p-3">Jumlah (RM)</th><th className="p-3">Status Bayaran</th><th className="p-3">Sesi</th></tr></thead>
                        <tbody>
                             {participants.sort((a,b)=>b.id-a.id).map(p => (
                                <tr key={p.id} className="border-b hover:bg-gray-50">
                                    <td className="p-3 font-semibold text-dark">{p.name}</td>
                                    <td className="p-3">{p.phone}</td>
                                    <td className="p-3">{p.parts}</td>
                                    <td className="p-3">{p.totalAmount.toFixed(2)}</td>
                                    <td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${p.paymentStatus === 'Lunas' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{p.paymentStatus}</span></td>
                                    <td className="p-3 text-xs text-gray-600">{sessions.find(s=>s.id === p.sessionId)?.title}</td>
                                </tr>
                             ))}
                        </tbody>
                    </table>
                    {participants.length === 0 && <div className="text-center py-10 text-gray-500"><p>Tiada peserta direkodkan.</p></div>}
                </div>
             </div>


            {isFormModalOpen && <SessionFormModal onClose={() => setIsFormModalOpen(false)} onSave={handleSaveSession} sessionToEdit={sessionToEdit} />}
            {sessionToDelete && <ConfirmationModal onClose={() => setSessionToDelete(null)} onConfirm={handleConfirmDelete} message={`Anda pasti ingin memadam sesi "${sessionToDelete.title}" dan semua pesertanya?`} />}
        </div>
    );
};

export default Korban;