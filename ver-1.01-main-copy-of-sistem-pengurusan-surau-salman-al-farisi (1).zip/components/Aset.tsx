import React, { useState, useEffect, useRef } from 'react';
import { Asset } from '../types';
import { getAssets, saveAssets } from '../services/dataService';
import { CloseIcon, PencilIcon, TrashIcon, PlusIcon, ImageIcon } from './icons';
import { useToast } from '../App';
import Spinner from './Spinner';

// Confirmation Modal
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
    title?: string;
}> = ({ onClose, onConfirm, message, title = "Pengesahan" }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{title}</h2></div>
            <div className="p-6"><p className="text-gray-700">{message}</p></div>
            <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Padam</button>
            </div>
        </div>
    </div>
);

// Asset Form Modal
export const AssetFormModal: React.FC<{
    onClose: () => void;
    onSave: (assetData: Omit<Asset, 'id'>) => void;
    assetToEdit: Partial<Asset> | null;
}> = ({ onClose, onSave, assetToEdit }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [category, setCategory] = useState('');
    const [location, setLocation] = useState('');
    const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
    const [purchaseValue, setPurchaseValue] = useState<number | ''>('');
    const [condition, setCondition] = useState<'Baik' | 'Perlu Penyelenggaraan' | 'Rosak'>('Baik');
    const [imageUrl, setImageUrl] = useState<string | undefined>();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const assetCategories = ['Elektronik', 'Perabot', 'Peralatan Pejabat', 'Peralatan Kebersihan', 'Hiasan', 'Lain-lain'];

    useEffect(() => {
        if (assetToEdit) {
            setName(assetToEdit.name || '');
            setCategory(assetToEdit.category || '');
            setLocation(assetToEdit.location || '');
            setPurchaseDate(assetToEdit.purchaseDate || new Date().toISOString().split('T')[0]);
            setPurchaseValue(assetToEdit.purchaseValue || '');
            setCondition(assetToEdit.condition || 'Baik');
            setImageUrl(assetToEdit.imageUrl);
        }
    }, [assetToEdit]);

    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            if (file.size > 512 * 1024) { // 512KB limit
                addToast("Saiz gambar tidak boleh melebihi 512KB.", "error");
                return;
            }
            const reader = new FileReader();
            reader.onloadend = () => setImageUrl(reader.result as string);
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !category || !location || purchaseValue === '') {
            addToast('Sila isi semua medan yang diperlukan.', 'error');
            return;
        }
        onSave({ name, category, location, purchaseDate, purchaseValue: Number(purchaseValue), condition, imageUrl });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <form onSubmit={handleSubmit} className="flex flex-col h-full">
                    <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">{assetToEdit && assetToEdit.id ? 'Kemaskini Aset' : 'Tambah Aset Baru'}</h2></div>
                    <div className="p-6 overflow-y-auto space-y-4">
                        <div className="flex items-center space-x-6">
                            <div className="w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border">
                                {imageUrl ? <img src={imageUrl} className="w-full h-full object-cover" /> : <ImageIcon className="w-12 h-12 text-gray-400" />}
                            </div>
                            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageUpload} className="hidden"/>
                            <button type="button" onClick={() => fileInputRef.current?.click()} className="bg-secondary text-white px-4 py-2 rounded-lg text-sm hover:bg-yellow-800">Tukar Gambar</button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><label>Nama Aset*</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" required /></div>
                            <div>
                                <label>Kategori Aset*</label>
                                <select value={category} onChange={e => setCategory(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" required>
                                    <option value="" disabled>Pilih Kategori</option>
                                    {assetCategories.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                            </div>
                            <div><label>Lokasi*</label><input type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="cth: Dewan Solat Utama" className="mt-1 block w-full p-2 border rounded-md" required /></div>
                            <div>
                                <label>Status Keadaan*</label>
                                <select value={condition} onChange={e => setCondition(e.target.value as any)} className="mt-1 block w-full p-2 border rounded-md" required>
                                    <option value="Baik">Baik</option>
                                    <option value="Perlu Penyelenggaraan">Perlu Penyelenggaraan</option>
                                    <option value="Rosak">Rosak</option>
                                </select>
                            </div>
                            <div><label>Tarikh Diperoleh*</label><input type="date" value={purchaseDate} onChange={e => setPurchaseDate(e.target.value)} className="mt-1 block w-full p-2 border rounded-md" required/></div>
                            <div><label>Nilai Perolehan (RM)*</label><input type="number" step="0.01" value={purchaseValue} onChange={e => setPurchaseValue(e.target.value === '' ? '' : parseFloat(e.target.value))} className="mt-1 block w-full p-2 border rounded-md" required /></div>
                        </div>
                    </div>
                    <div className="p-6 bg-gray-50 flex justify-end space-x-3 mt-auto">
                        <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">{assetToEdit && assetToEdit.id ? 'Simpan Perubahan' : 'Tambah Aset'}</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

// Main Asset Component
const Aset: React.FC = () => {
    const [assets, setAssets] = useState<Asset[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [assetToEdit, setAssetToEdit] = useState<Asset | null>(null);
    const [assetToDelete, setAssetToDelete] = useState<Asset | null>(null);
    const { addToast } = useToast();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const data = await getAssets();
                setAssets(data);
            } catch (err) {
                setError("Gagal memuatkan data aset.");
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleOpenAddModal = () => {
        setAssetToEdit(null);
        setIsFormModalOpen(true);
    };

    const handleOpenEditModal = (asset: Asset) => {
        setAssetToEdit(asset);
        setIsFormModalOpen(true);
    };

    const handleSaveAsset = async (assetData: Omit<Asset, 'id'>) => {
        let updatedAssets: Asset[];
        let successMessage = "";
        if (assetToEdit) {
            updatedAssets = assets.map(a => a.id === assetToEdit.id ? { ...assetToEdit, ...assetData } : a);
            successMessage = `Maklumat aset "${assetData.name}" telah dikemaskini.`;
        } else {
            const newAsset: Asset = { id: Date.now(), ...assetData };
            updatedAssets = [newAsset, ...assets];
            successMessage = `Aset "${assetData.name}" telah berjaya direkodkan.`;
        }
        try {
            await saveAssets(updatedAssets);
            setAssets(updatedAssets);
            addToast(successMessage);
        } catch (err) {
            addToast("Gagal menyimpan data aset.", "error");
        } finally {
            setIsFormModalOpen(false);
        }
    };

    const handleDelete = (asset: Asset) => {
        setAssetToDelete(asset);
    };

    const handleConfirmDelete = async () => {
        if (!assetToDelete) return;
        const updatedAssets = assets.filter(a => a.id !== assetToDelete.id);
        try {
            await saveAssets(updatedAssets);
            setAssets(updatedAssets);
            addToast(`Aset "${assetToDelete.name}" telah dipadam.`);
        } catch (err) {
            addToast("Gagal memadam aset.", "error");
        } finally {
            setAssetToDelete(null);
        }
    };

    const filteredAssets = assets.filter(asset =>
        asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.location.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const getConditionClass = (condition: Asset['condition']) => {
        switch (condition) {
            case 'Baik': return 'bg-green-100 text-green-800';
            case 'Perlu Penyelenggaraan': return 'bg-yellow-100 text-yellow-800';
            case 'Rosak': return 'bg-red-100 text-red-800';
        }
    };

    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <h2 className="text-2xl font-bold text-dark">Pengurusan Aset & Inventori</h2>
                 <input
                    type="text"
                    placeholder="Cari aset (nama, kategori, lokasi)..."
                    className="w-full md:w-1/3 p-2 border border-gray-300 rounded-lg"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <button onClick={handleOpenAddModal} className="flex items-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark w-full md:w-auto justify-center">
                    <PlusIcon className="w-5 h-5 mr-2" /> Tambah Aset Baru
                </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="p-3">Nama Aset</th>
                                <th className="p-3">Kategori</th>
                                <th className="p-3">Lokasi</th>
                                <th className="p-3">Tarikh Perolehan</th>
                                <th className="p-3">Nilai (RM)</th>
                                <th className="p-3">Status</th>
                                <th className="p-3 text-center">Tindakan</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredAssets.map(asset => (
                                <tr key={asset.id} className="border-b hover:bg-gray-50">
                                    <td className="p-3 font-semibold text-dark">{asset.name}</td>
                                    <td className="p-3">{asset.category}</td>
                                    <td className="p-3">{asset.location}</td>
                                    <td className="p-3">{new Date(asset.purchaseDate).toLocaleDateString('ms-MY')}</td>
                                    <td className="p-3">{asset.purchaseValue.toFixed(2)}</td>
                                    <td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-medium ${getConditionClass(asset.condition)}`}>{asset.condition}</span></td>
                                    <td className="p-3">
                                        <div className="flex items-center justify-center space-x-2">
                                            <button onClick={() => handleOpenEditModal(asset)} className="p-2 text-secondary hover:bg-yellow-100 rounded-full" title="Kemaskini"><PencilIcon className="w-5 h-5"/></button>
                                            <button onClick={() => handleDelete(asset)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="Padam"><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                     {filteredAssets.length === 0 && (
                        <div className="text-center py-10 text-gray-500">
                            <p>Tiada aset ditemui.</p>
                        </div>
                    )}
                </div>
            </div>
            {isFormModalOpen && <AssetFormModal onClose={() => setIsFormModalOpen(false)} onSave={handleSaveAsset} assetToEdit={assetToEdit} />}
            {assetToDelete && <ConfirmationModal onClose={() => setAssetToDelete(null)} onConfirm={handleConfirmDelete} message={`Anda pasti ingin memadam aset "${assetToDelete.name}"?`} />}
        </div>
    );
};

export default Aset;