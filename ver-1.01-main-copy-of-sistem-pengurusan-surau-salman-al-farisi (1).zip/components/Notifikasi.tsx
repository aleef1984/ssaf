import React, { useState, useEffect } from 'react';
import { useToast } from '../App';
import { getNotificationTemplates, saveNotificationTemplates, getMembers } from '../services/dataService';
import { NotificationTemplate, Member } from '../types';
import Spinner from './Spinner';
import { PlusIcon, PencilIcon, TrashIcon, CloseIcon, MailIcon, WhatsAppIcon, InfoIcon } from './icons';

// Confirmation Modal
const ConfirmationModal: React.FC<{
    onClose: () => void;
    onConfirm: () => void;
    message: string;
}> = ({ onClose, onConfirm, message }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6 border-b"><h2 className="text-xl font-bold text-dark">Pengesahan</h2></div>
            <div className="p-6"><p className="text-gray-700">{message}</p></div>
            <div className="p-6 bg-gray-50 flex justify-end rounded-b-lg border-t space-x-3">
                <button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400">Batal</button>
                <button type="button" onClick={onConfirm} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Padam</button>
            </div>
        </div>
    </div>
);

// Template Form Modal
const TemplateFormModal: React.FC<{
    onClose: () => void;
    onSave: (template: Omit<NotificationTemplate, 'id'>) => void;
    templateToEdit: NotificationTemplate | null;
}> = ({ onClose, onSave, templateToEdit }) => {
    const { addToast } = useToast();
    const [name, setName] = useState('');
    const [type, setType] = useState<'Email' | 'WhatsApp'>('Email');
    const [subject, setSubject] = useState('');
    const [content, setContent] = useState('');

    useEffect(() => {
        if (templateToEdit) {
            setName(templateToEdit.name);
            setType(templateToEdit.type);
            setSubject(templateToEdit.subject || '');
            setContent(templateToEdit.content);
        }
    }, [templateToEdit]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !content || (type === 'Email' && !subject)) {
            addToast('Sila isi semua medan yang diperlukan.', 'error'); return;
        }
        onSave({ name, type, subject, content });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
                <div className="p-6 border-b flex justify-between items-center"><h2 className="text-xl font-bold text-dark">{templateToEdit ? 'Kemaskini Templat' : 'Tambah Templat Baru'}</h2><button type="button" onClick={onClose}><CloseIcon/></button></div>
                <div className="p-6 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div><label>Nama Templat</label><input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full mt-1 p-2 border rounded" required /></div>
                        <div><label>Jenis</label><select value={type} onChange={e => setType(e.target.value as any)} className="w-full mt-1 p-2 border rounded"><option value="Email">Email</option><option value="WhatsApp">WhatsApp</option></select></div>
                    </div>
                    {type === 'Email' && <div><label>Subjek Emel</label><input type="text" value={subject} onChange={e => setSubject(e.target.value)} className="w-full mt-1 p-2 border rounded" required={type === 'Email'} /></div>}
                    <div><label>Kandungan Mesej</label><textarea value={content} onChange={e => setContent(e.target.value)} rows={8} className="w-full mt-1 p-2 border rounded font-mono text-sm" required /></div>
                     <div className="text-xs text-gray-500 p-2 bg-gray-50 rounded-md">
                        Gunakan pembolehubah seperti <strong>[Nama Ahli]</strong> atau <strong>[Jawatan]</strong> untuk memasukkan data secara dinamik.
                    </div>
                </div>
                <div className="p-6 bg-gray-50 flex justify-end space-x-3"><button type="button" onClick={onClose} className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg">Batal</button><button type="submit" className="bg-primary text-white px-4 py-2 rounded-lg">{templateToEdit ? 'Simpan' : 'Tambah'}</button></div>
            </form>
        </div>
    );
};

const Notifikasi: React.FC = () => {
    const [templates, setTemplates] = useState<NotificationTemplate[]>([]);
    const [members, setMembers] = useState<Member[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [templateToEdit, setTemplateToEdit] = useState<NotificationTemplate | null>(null);
    const [templateToDelete, setTemplateToDelete] = useState<NotificationTemplate | null>(null);
    
    const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
    const [isSending, setIsSending] = useState(false);

    const { addToast } = useToast();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const [templatesData, membersData] = await Promise.all([getNotificationTemplates(), getMembers()]);
                setTemplates(templatesData);
                setMembers(membersData.filter(m => m.status === 'Aktif'));
            } catch (err) {
                setError("Gagal memuatkan data notifikasi."); console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleSaveTemplate = async (data: Omit<NotificationTemplate, 'id'>) => {
        let updatedTemplates: NotificationTemplate[];
        if (templateToEdit) {
            updatedTemplates = templates.map(t => t.id === templateToEdit.id ? { ...templateToEdit, ...data } : t);
        } else {
            updatedTemplates = [{ id: Date.now(), ...data }, ...templates];
        }
        try {
            await saveNotificationTemplates(updatedTemplates);
            setTemplates(updatedTemplates);
            addToast(`Templat "${data.name}" telah disimpan.`);
        } catch (err) {
            addToast("Gagal menyimpan templat.", "error");
        } finally {
            setIsFormModalOpen(false);
        }
    };
    
    const handleConfirmDelete = async () => {
        if (!templateToDelete) return;
        const updatedTemplates = templates.filter(t => t.id !== templateToDelete.id);
        try {
            await saveNotificationTemplates(updatedTemplates);
            setTemplates(updatedTemplates);
            addToast(`Templat "${templateToDelete.name}" telah dipadam.`);
        } catch (err) {
            addToast("Gagal memadam templat.", "error");
        } finally {
            setTemplateToDelete(null);
        }
    };

    const handleSendBroadcast = () => {
        const template = templates.find(t => t.id === Number(selectedTemplateId));
        if (!template) {
            addToast("Sila pilih templat yang sah.", "error");
            return;
        }
        setIsSending(true);
        addToast(`Memulakan hebahan "${template.name}" kepada ${members.length} ahli...`, "info");
        // Simulate sending
        setTimeout(() => {
            console.log(`BROADCASTING:`);
            console.log(`Template: ${template.name}`);
            console.log(`Content: ${template.content}`);
            console.log(`Recipients: ${members.length}`);
            setIsSending(false);
            addToast("Hebahan selesai disimulasikan. Semak konsol untuk butiran.", "success");
        }, 2000);
    };

    if (isLoading) return <Spinner />;
    if (error) return <div className="text-center p-10 text-red-600">{error}</div>;

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-dark">Notifikasi & Templat</h2>

             {/* Broadcast Section */}
             <div className="bg-white p-6 rounded-xl shadow-md">
                 <h3 className="text-xl font-bold text-dark mb-4">Hebahan Kepada Semua Ahli Aktif</h3>
                 <div className="flex flex-col md:flex-row items-end gap-4">
                    <div className="flex-grow w-full">
                        <label className="text-sm font-medium">Pilih Templat</label>
                        <select 
                            value={selectedTemplateId} 
                            onChange={e => setSelectedTemplateId(e.target.value)}
                            className="w-full mt-1 p-2 border rounded-md bg-white"
                        >
                            <option value="" disabled>Pilih satu templat...</option>
                            {templates.map(t => <option key={t.id} value={t.id}>{t.name} ({t.type})</option>)}
                        </select>
                    </div>
                     <button 
                        onClick={handleSendBroadcast} 
                        disabled={!selectedTemplateId || isSending}
                        className="w-full md:w-auto bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                    >
                        {isSending ? 'Menghantar...' : `Hantar kepada ${members.length} Ahli`}
                    </button>
                 </div>
                 <div className="text-xs text-gray-500 p-3 bg-blue-50 border border-blue-200 rounded-md mt-4 flex items-start gap-2">
                    <InfoIcon className="w-4 h-4 mt-0.5 flex-shrink-0 text-blue-600"/>
                    <span>Ciri ini akan menghantar mesej kepada semua ahli kariah yang berstatus 'Aktif'. Dalam persekitaran sebenar, ini akan menggunakan API Emel/WhatsApp yang telah ditetapkan di modul Tetapan.</span>
                </div>
            </div>

            {/* Template Management Section */}
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-dark">Pengurusan Templat Mesej</h3>
                    <button onClick={() => { setTemplateToEdit(null); setIsFormModalOpen(true); }} className="flex items-center bg-primary text-white px-4 py-2 rounded-lg hover:bg-dark">
                        <PlusIcon className="w-5 h-5 mr-2" /> Tambah Templat
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-100"><tr>
                            <th className="p-3">Nama Templat</th><th className="p-3">Jenis</th><th className="p-3">Subjek/Kandungan</th>
                            <th className="p-3 text-center">Tindakan</th></tr></thead>
                        <tbody>
                            {templates.map(template => (
                                <tr key={template.id} className="border-b hover:bg-gray-50">
                                    <td className="p-3 font-semibold text-dark">{template.name}</td>
                                    <td className="p-3">
                                        <span className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${template.type === 'Email' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>
                                            {template.type === 'Email' ? <MailIcon className="w-3 h-3"/> : <WhatsAppIcon className="w-3 h-3"/>}
                                            {template.type}
                                        </span>
                                    </td>
                                    <td className="p-3 text-gray-600 text-xs max-w-sm truncate">
                                        {template.type === 'Email' && <strong className="block">{template.subject}</strong>}
                                        <span className="opacity-70">{template.content}</span>
                                    </td>
                                    <td className="p-3">
                                        <div className="flex items-center justify-center space-x-2">
                                            <button onClick={() => { setTemplateToEdit(template); setIsFormModalOpen(true); }} className="p-2 text-secondary hover:bg-yellow-100 rounded-full" title="Kemaskini"><PencilIcon className="w-5 h-5"/></button>
                                            <button onClick={() => setTemplateToDelete(template)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="Padam"><TrashIcon className="w-5 h-5"/></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {templates.length === 0 && <div className="text-center py-10 text-gray-500"><p>Tiada templat direkodkan.</p></div>}
                </div>
            </div>

            {isFormModalOpen && <TemplateFormModal onClose={() => setIsFormModalOpen(false)} onSave={handleSaveTemplate} templateToEdit={templateToEdit} />}
            {templateToDelete && <ConfirmationModal onClose={() => setTemplateToDelete(null)} onConfirm={handleConfirmDelete} message={`Anda pasti ingin memadam templat "${templateToDelete.name}"?`} />}
        </div>
    );
};

export default Notifikasi;